/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /tracks                          ->  index
 * POST    /tracks/filter                   ->  filter
 * GET     /tracks/:id                      ->  show
 * GET     /tracks/:id/mp3/summary-stream   ->  streamSummary
 */

'use strict';

import * as envConfig from "../../config/local.env";
import * as knox from 'knox';
import * as trackDAO from './track.model.es';

function streamResource(path, req, res) {
  var s3Client = knox.createClient(envConfig.S3_BUCKET_TRACKS);

  s3Client.get(path)
    .on('response', function (s3res) {
      res.setHeader('Content-Length', s3res.headers['content-length']);
      res.setHeader('Content-Type', s3res.headers['content-type']);

      if (req.fresh) {
        res.statusCode = 304;
        res.end();
        return;
      }

      if (req.method === 'HEAD') {
        res.statusCode = 200;
        res.end();
        return;
      }

      s3res.pipe(res);
    }
  ).end();
}

export function filter(req, res) {
  var skip = parseInt(req.query.skip);
  if (isNaN(skip)) {
    skip = 0;
  }
  var userType = "E";
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
    userType = "P";
  }
  var promise = trackDAO.search(req.body, skip, userType);
  if (promise) {
    promise.then(function (result) {
      res.status(200).json({searchId: req.body.id, result: result})
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(204);
  }
};

// Get list of tracks
export function metrics(req, res) {
  var userType = "E";
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
    userType = "P";
  }
  var promise = trackDAO.metrics(req.body,userType);
  if (promise) {
    promise.then(function (result) {
      res.status(200).json({searchId: req.body.id, result: result})
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(204);
  }
};

// Get a single track
export function show(req, res) {
  var promise = trackDAO.findByIdNoFiles(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      return res.status(200).json(result);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(404);
  }
};

export function summaryStream(req, res) {
  var promise = trackDAO.findById(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var track = result.hits.hits[0]._source;
      if (track.audio_summary_filename) {
        streamResource(track.audio_summary_filename.substring(19), req, res);
      } else {
        return res.send(404);
      }
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

export function fullStream(req, res) {
  var promise = trackDAO.findById(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var track = result.hits.hits[0]._source;
      if (track.audio_transcode_filename) {
        streamResource(track.audio_transcode_filename.substring(19), req, res);
      } else {
        return res.send(404);
      }
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

export function thumbnailLarge(req, res) {
  var promise = trackDAO.findById(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var track = result.hits.hits[0]._source;
      if (track.thumbnail_large_filename) {
        streamResource(track.thumbnail_large_filename.substring(19), req, res);
      } else {
        return res.send(404);
      }
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

export function searchByTitle(req, res) {
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
    //not employee
    req.body.filters.rights[0].value = "Y";
    req.body.filters.rights[4].value = "N";
  }
  var promise = trackDAO.searchByTitle(req.query.title);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(204);
      }
      return res.status(200).json(result);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

export function findSuggestions(req, res) {
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
    //not employee
    req.body.filters.rights[0].value = "Y";
    req.body.filters.rights[4].value = "N";
  }
  var promise = trackDAO.findSuggestionsByTitle(req.body);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(204);
      }
      return res.status(200).json(result);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

function handleError(res, err) {
  return res.send(500, err);
}
