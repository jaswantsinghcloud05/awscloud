/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /tracks                          ->  index
 * POST    /tracks/filter                   ->  filter
 * GET     /tracks/:id                      ->  show
 * GET     /tracks/:id/mp3/summary-stream   ->  streamSummary
 */

'use strict';

import * as envConfig from "../../config/local.env";
import * as trackDAO from './track.model.es';

function handleError(res, err) {
  console.error(err.stack());
  return res.send(500, err);
}

function buildTrack(hit){
  return {
    "metadata": {
      "display_artist_name": hit._source.artist_name,
      "title": hit._source.resource_title,
      "version_title": hit._source.version_title,
      "formatted_title": hit._source.formatted_title,
      "release_date": hit._source.release_date,
      "length": hit._source.length,
      "pc_notice": {
        "year": hit._source.pc_notice_year,
        "company_id": hit._source.pc_notice_company_id,
        "company_name": hit._source.pc_notice_company_name,
        "formatted": hit._source.formatted_pc_notice
      },
      "canopus": {
        "canopus_artist_id": hit._source.canopus_id,
        "canopus_resource_rollup_id": hit._source.resource_rollup_id,
        "canopus_resource_id": hit._source.resource_id
      },
      "r2": {
        "talent_id": hit._source.p_id,
        "r2_account_id": hit._source.r2_account_id,
        "r2_resource_id": hit._source.r2_resource_id,
        "country_origin": {
          "country_id": hit._source.country_id,
          "country_name": hit._source.country_name
        },
        "genre_desc": hit._source.genre_desc
      },
      "cdl": {
        "company_id": hit._source.company_id,
        "company_name": hit._source.company_name,
        "division_id": hit._source.division_id,
        "division_name": hit._source.division_name,
        "label_id": hit._source.label_id,
        "label_name": hit._source.label_name,
        "family_id": hit._source.family_id,
        "family_name": hit._source.family_name
      }
    },
    "audio": {
      "audio_url": hit._source.audio_transcode_filename,
      "audiowaveform_url": hit._source.audiowaveform_filename
    },
    "clip": {
      "part_count": hit._source.part_count,
      "duration": hit._source.duration,
      "segments": hit._source.segments,
      "clip_url": hit._source.audio_summary_filename
    },
    "artwork": {
      "filename": hit._source.artwork_filename,
      "thumbnail": hit._source.thumbnail
    },
    "creative_metadata": {
      "rhythm": {
        "rhythm_meter": hit._source.rhythm_meter,
        "rhythm_speed_a": hit._source.rhythm_speed_a,
        "rhythm_speed_b": hit._source.rhythm_speed_b,
        "rhythm_bpm_mean": hit._source.rhythm_bpm_mean,
        "rhythm_percussivity": hit._source.rhythm_percussivity,
        "rhythm_bpm_std": hit._source.rhythm_bpm_std,
        "rhythm_periodicity": hit._source.rhythm_periodicity,
        "rhythm_complexity": hit._source.rhythm_complexity
      },
      "average_loudness": hit._source.average_loudness,
      "dynamic_complexity": hit._source.dynamic_complexity,
      "timbre_bright": hit._source.timbre_bright,
      "tonality_tonal": hit._source.tonality_tonal,
      "harmonic_key": hit._source.harmonic_key,
      "harmonic_mode": hit._source.harmonic_mode,
      "instrumental": hit._source.instrumental,
      "genre": {
        "rnb": hit._source.genre_rnb,
        "jazz": hit._source.genre_jazz,
        "pop_rock": hit._source.genre_pop_rock,
        "latin": hit._source.genre_latin,
        "hiphop": hit._source.genre_hiphop,
        "metal": hit._source.genre_metal,
        "blues": hit._source.genre_blues,
        "reggae": hit._source.genre_reggae,
        "classical": hit._source.genre_classical,
        "alternative_pop": hit._source.genre_alternative_pop,
        "alternative_rock": hit._source.genre_alternative_rock,
        "brazilian": hit._source.genre_brazilian,
        "classic_pop": hit._source.genre_classic_pop,
        "classic_rock": hit._source.genre_classic_rock,
        "country": hit._source.genre_country,
        "dance": hit._source.genre_dance,
        "folk": hit._source.genre_folk,
        "gospel": hit._source.genre_gospel,
        "modern_pop": hit._source.genre_modern_pop,
        "spoken": hit._source.genre_spoken
      },
      "arrangement": {
        "a_capella": hit._source.arrangement_a_capella,
        "instrumental": hit._source.arrangement_instrumental,
        "voice_music": hit._source.arrangement_voice_music
      },
      "emotion": {
        "aggressive": hit._source.emotion_aggressive,
        "easy_going": hit._source.emotion_easy_going,
        "happy": hit._source.emotion_happy,
        "romantic": hit._source.emotion_romantic,
        "sad": hit._source.emotion_sad,
        "sentimental": hit._source.emotion_sentimental,
        "suspenseful": hit._source.emotion_suspenseful,
        "uplifting": hit._source.emotion_uplifting
      },
      "intensity": {
        "calm": hit._source.intensity_calm,
        "driving": hit._source.intensity_driving,
        "groovy": hit._source.intensity_groovy,
        "laidback": hit._source.intensity_laidback,
        "powerful": hit._source.intensity_powerful
      },
      "tempo" : {
        "fast": hit._source.tempo_fast,
        "medium": hit._source.tempo_medium,
        "slow": hit._source.tempo_slow
      },
      "instrumentation": {
        "electric_guitar": hit._source.instrumentation_electric_guitar,
        "jazz_country_soul_drumkit": hit._source.instrumentation_jazz_country_soul_drumkit,
        "light_pop_rock_drumkit": hit._source.instrumentation_light_pop_rock_drumkit,
        "acoustic_guitar": hit._source.instrumentation_acoustic_guitar,
        "acoustic": hit._source.instrumentation_acoustic,
        "strings_orchestra": hit._source.instrumentation_strings_orchestra,
        "electronic_drumkit": hit._source.instrumentation_electronic_drumkit,
        "heavy_rock_metal_drumkit": hit._source.instrumentation_heavy_rock_metal_drumkit,
        "piano": hit._source.instrumentation_piano,
        "brass": hit._source.instrumentation_brass,
        "electronic": hit._source.instrumentation_electronic
      },
      "ensemble_timbres": [
        {"acoustic": hit._source.ensemble_timbre_acoustic},
        {"electric": hit._source.ensemble_timbre_electric},
        {"electronic": hit._source.ensemble_timbre_electronic},
      ],
      "ensemble_types": [
        {"electronic": hit._source.ensemble_type_electronic},
        {"folk_band": hit._source.ensemble_type_folk_band},
        {"large_jazz_band": hit._source.ensemble_type_large_jazz_band},
        {"orchestra": hit._source.ensemble_type_orchestra},
        {"pop_band": hit._source.pop_band},
        {"rock_band": hit._source.ensemble_type_rock_band},
        {"small": hit._source.ensemble_type_small},
        {"small_jazz_band": hit._source.ensemble_type_small_jazz_band},
        {"solo": hit._source.ensemble_type_solo},
        {"voice_accompaniment": hit._source.ensemble_type_voice_accompaniment}
      ],
      "vocal_registers": [
        {"high": hit._source.vocal_register_female},
        {"low": hit._source.vocal_register_male},
      ],
      "structure": hit._source.structure,
      "ircam_xml_filename": hit._source.ircam_xml_filename,
      "level": {
        "level": hit._source.level_peak,
        "rms": hit._source.level_rms
      }
    },
    "albums": hit._source.albums,
    "publishing_rights":{
      "us": {
        "original_release_year": hit._source.uspub_orig_release_year,
        "article_description": hit._source.uspub_description,
        "song_title": hit._source.uspub_song_title,
        "main_artist": hit._source.uspub_main_artist,
        "song_writer": hit._source.uspub_song_write,
        "publishers": hit._source.uspub_publishers,
      },
      "non_us": {
        "pips": hit._source.pips,
        "iswc": hit._source.iswc,
        "song_title": hit._source.nouspub_song_title,
        "song_writers": hit._source.nouspub_song_writer,
        "main_artist": hit._source.nouspub_main_artist,
        "country_rights": hit._source.nouspub_rights
      }
    },
    "recording_rights": {
      "lost_rights": hit._source.lost_rights,
      "territorial_rights": hit._source.territorial_right,
      "digital_rights": hit._source.digital_rights,
      "download_restrict": hit._source.download_restrict,
      "stream_restrict": hit._source.stream_restrict,
      "comps": hit._source.comps,
      "sync": hit._source.sync,
      "greatest_hits": hit._source.greatest_hits,
      "country_list": hit._source.country_list
    }
  }

}


function buildAsset(hit){
  var asset = {
    "asset_type": "resource",
    "resource_type": hit._source.resource_type,
    "isrc": hit._source.isrc
  }
  asset.description = buildTrack(hit)
  return asset;
}
// Get a single track
export function findByIsrc(req, res) {
  var promise = trackDAO.findByAttribute("isrc.keyword", req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var hits = result.hits.hits;
      var asset = {
        "asset_type": "resource",
        "resource_type": hits[0]._source.resource_type,
        "isrc": hits[0]._source.isrc,
        "description": []
      }
      hits.forEach(function (hit) {
        asset.description.push(buildTrack(hit))
      })
      return res.status(200).json(asset);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(403);
  }
};


export function findByPips(req, res) {
  var promise = trackDAO.findByAttribute("pips", req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var assets = [];
      result.hits.hits.forEach(function(hit) {
        assets.push(buildAsset(hit))
      })
      return res.status(200).json(assets);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(403);
  }
};

export function findByIswc(req, res) {
  var promise = trackDAO.findByAttribute("iswc.keyword", req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      var assets = [];
      result.hits.hits.forEach(function(hit) {
        assets.push(buildAsset(hit))
      })
      return res.status(200).json(assets);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(403);
  }
};
