'use strict';

import * as elasticsearch from 'elasticsearch';
import * as config from '../../config/environment';
var log = require('../../config/logger.js').log;

var elasticClient = new elasticsearch.Client({
  protocol: 'http',
  host: config.es.uri,
  log: config.es.LOG_LEVEL

});

var indexName = config.es.TRACKS_IDX;
const IRCAM_CONF_LEVEL = 0.3;

export function findById(r2_resource_id){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "ids": {
          "values": [r2_resource_id]
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findByAttribute(name, value){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "bool":  {
          "filter": {
            "term": {[name]: value}
          }
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findByIdNoFiles(r2_resource_id){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "_source":{
        "excludes": ["*_filename"]
      },
      "version": true,
      "query": {
        "ids": {
          "values": [r2_resource_id]
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function search(filterBody, skip, userRole) {

  var filters = filterBody.filters;
  var ranges = filterBody.ranges;
  var matches = filterBody.match;
  var sorting = filterBody.sorting;
  var query = filterBody.query;
  var search = filterBody.search;

  var esFilter = {
    index: indexName,
    body: {
      "size": filterBody.pageSize,
      "from" : skip,
      "version": true,
      // "_source":{TODO temporarily replaced exclude with include because I need the files info saved into the playlist when the user adds a track
      //   "exclude": ["*_filename"]
      // },
      "query": {
        "bool": {
          "filter": [],
          "must_not": [],
          "must": [{"exists" : {"field" : "length"}}]
        }
      },
      "sort": []
    }
  };
//TODO sorting for artist/track title needs to be reviewed https://www.elastic.co/guide/en/elasticsearch/guide/current/sorting-collations.html
  var conditionAdded = applyFilters(esFilter, filterBody, userRole);

  if (conditionAdded) {
    if (query && !(matches.canopus_id || matches.resource_rollup_id) || search.labels && search.labels.length>0 || search.countries && search.countries.length>0){
      esFilter.body.sort.unshift({
        "_score": {
        "order": "desc"
      }})
    }
    if (sorting && sorting.length > 0) {
      esFilter.body.sort.unshift(...sorting.map(function (obj) {
        //TODO review the protocol to avoid getOwnPropertyNames
        var sortName = Object.getOwnPropertyNames(obj)
        return {[sortName]: obj[sortName] === 1 ? {"order": "asc"} : {"order": "desc"}};
      }));
    }
    //sort by multiple columns
    //TODO better way but doens't work in old nodes
    // if (sorting && sorting.length > 0){
    //   sorting.forEach(function(item) {
    //     var sortName = Object.getOwnPropertyNames(item)
    //     var order = sorting[sortName] === 1 ? {"order": "asc"} : {"order": "desc"}
    //     esFilter.body.sort.push({[sortName]: order});
    //   })
    // }
    var promise = elasticClient.search(esFilter);
    promise.then(null,handleError);
    return promise;

  }

}

export function metrics(filterBody, userRole) {

  var esFilter = {
    index: indexName,
    body: {
      "size": 0,
      "query": {
        "bool": {
          "filter": [],
          "must_not": [],
          "must": [{"exists": {"field": "length"}}]
        }
      },
      "aggs": {}
    }
  };

  //TODO Security issue: is not secure to build the query using information coming straight from the client
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.genres, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.intensities, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.instrumentations, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.emotions, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.ensemble_timbres, 0.6);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.ensemble_types, 0.6);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.arrangements, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.tempos, IRCAM_CONF_LEVEL);
  addAggregationCondition(esFilter.body.aggs, filterBody.filters.vocalGenders, IRCAM_CONF_LEVEL);

  var conditionAdded = applyFilters(esFilter, filterBody, userRole);

  if (conditionAdded) {
    var promise = elasticClient.search(esFilter);
    promise.then(null,handleError);
    return promise;
  }else{
    return null;
  }

}

export function searchByTitle(title){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      size: 10,
      "query": {
        "bool": {
          "should": [
            {
              "match": {
                "formatted_title.keyword_lowercase": {
                  "query": title.toLowerCase(),
                  "boost": 3
                }
              }
            },
            {
              "match": {
                "formatted_title": title
              }
            },
            {
              "match_phrase_prefix": {
                "formatted_title.keyword_lowercase": {
                  "query": title.toLowerCase(),
                  "max_expansions": 10,
                  "boost": 2
                }
              }
            }
          ],
          "minimum_number_should_match": 1
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findSuggestionsByTitle(filterBody){
  var esFilter = {
    index: indexName,
    body: {
      size: 10,
      "query": {
        "bool": {
          "filter": [],
          "must_not": [],
          "must": [{"exists" : {"field" : "length"}}],
          "should": [
            {
              "match": {
                "formatted_title.keyword_lowercase": {
                  "query": filterBody.query.toLowerCase(),
                  "boost": 3
                }
              }
            },
            {
              "match": {
                "formatted_title": filterBody.query
              }
            },
            {
              "match_phrase_prefix": {
                "formatted_title.keyword_lowercase": {
                  "query": filterBody.query.toLowerCase(),
                  "max_expansions": 10,
                  "boost": 2
                }
              }
            }
          ],
          "minimum_number_should_match": 1
        }
      }
    }
  };

  var conditionAdded = applyFilters(esFilter, filterBody);

  var promise = elasticClient.search(esFilter);
  promise.then(null,handleError);
  return promise;

}


function addRangeCondition(query, filterArray, confidenceLevel){
  var added = false;
  filterArray.forEach(function(item){
    if(item.value === 'Y'){
      query.body.query.bool.filter.push({"range":{[item.id] : {"gte": confidenceLevel}}});
      var sort = query.body.sort;
      if(sort) {//check if is a metric or a search
        if (sort.length == 0) {
          sort.push({
            "_script": {
              "type": "number",
              "script": {
                "lang": "painless",
                "inline": ""
              },
              "order": "desc"
            }
          })
        } else {
          sort[0]._script.script.inline += " * "
        }
        sort[0]._script.script.inline += "doc['" + [item.id] + "'].value";
      }
      added = true;
    }else if (item.value === 'N'){
      query.body.query.bool.filter.push({"range":{[item.id] : {"lt": confidenceLevel}}});
      added = true;
    }
  });
  return added;
};

function addAggregationCondition(aggregator, filterArray, confidenceLevel){
  filterArray.forEach(function(item){
    aggregator[item.id] = {
      "filter": {
        "range": {[item.id]: {"gt": confidenceLevel}}
      }
    }
  });
};

var applyFilters = function (esFilter, filterBody, userRole) {
  var filters = filterBody.filters;
  var ranges = filterBody.ranges;
  var matches = filterBody.match;
  var query = filterBody.query;
  var search = filterBody.search;

  var conditionAdded = false;

  if (userRole === "P"){
    esFilter.body.query.bool.must_not.push(config.partnerLabels);
  }


  if (matches.country){
    esFilter.body.query.bool.filter.push({"term":{"country": matches.country}});
    conditionAdded = true;
  }
  if (matches.resource_rollup_id){
    esFilter.body.query.bool.filter.push({"term":{"resource_rollup_id": matches.resource_rollup_id}});
    conditionAdded = true;
  } else if (matches.canopus_id) {
    esFilter.body.query.bool.minimum_number_should_match = 1;
    esFilter.body.query.bool.should = [
      {"term": {"canopus_id": matches.canopus_id}},
      {
        "nested": {
          "path": "featured",
          "query": {
            "bool": {
              "must": [
                {
                  "term": {
                    "featured.canopus_id": matches.canopus_id
                  }
                }
              ]
            }
          }
        }
      }
    ]
    conditionAdded = true;
  } else if (matches.upc) {
    esFilter.body.query.bool.filter.push({"nested": {
      "path": "albums",
      "query": {
        "bool": {
          "must": [
            {
              "term": {
                "albums.upc": matches.upc
              }
            }
          ]
        }
      }
    }})
    conditionAdded = true;
  } else if (query) {
    conditionAdded = true;
    if (filterBody.boolean) {
      //esFilter.body.min_score= 10;
      esFilter.body.query.bool.must.push({"query_string" : {
        "fields": [
          "artist_name^3",
          "formatted_title^5",
          "track_genre^7",
          "country_name^6",
          "pc_notice_year^4",
          "company_name",
          "label_name",
          "isrc",
          "upc",
          "tags_cloud^7"],
        "query": query,
        "use_dis_max" : true,
        "split_on_whitespace": true,
        "quote_field_suffix": ".keyword_lowercase",
        "lenient": true,
        //"minimum_should_match": "2<50%",
        "allow_leading_wildcard": false,
        "default_operator": "AND"
      }})

      // esFilter.body.query.bool.must.push({"multi_match" : {
      //   "fields": [
      //     "artist_name.keyword_lowercase^3",
      //     "formatted_title^2",
      //     "pc_notice_year",
      //     "company_name",
      //     "country_name.keyword_lowercase^3",
      //     "genre_desc.keyword_lowercase^3",
      //     "label_name"],
      //   "query": query,
      //   "use_dis_max" : false,
      //   "lenient": true,
      //   "type": "most_fields",
      //   "operator": "AND"
      // }})
    } else {
      esFilter.body.query.bool.minimum_number_should_match = 1
      esFilter.body.query.bool.should = [
        {
          "term": {
            "formatted_title.keyword_lowercase": {
              "value": query.toLowerCase(),
              "boost": 3
            }
          }
        },
        {
          "match": {
            "formatted_title": query
          }
        },
        {
          "match_phrase_prefix": {
            "formatted_title.keyword_lowercase": {
              "query": query.toLowerCase(),
              "max_expansions": 10,
              "boost": 2
            }
          }
        }
      ]
    }
  }
  if (filterBody.excludeLiveTracks) {
    esFilter.body.query.bool.must_not.push({
      "term": {
        "version_title": "live"
      }
    });
    conditionAdded = true;
  }

  conditionAdded |= addRangeCondition(esFilter, filters.genres, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.intensities, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.instrumentations, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.emotions, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.ensemble_timbres, 0.6);
  conditionAdded |= addRangeCondition(esFilter, filters.ensemble_types, 0.6);
  conditionAdded |= addRangeCondition(esFilter, filters.arrangements, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.tempos, IRCAM_CONF_LEVEL);
  conditionAdded |= addRangeCondition(esFilter, filters.vocalGenders, IRCAM_CONF_LEVEL);

  //if (ranges.decades.min > 1900) {
  //  find.where("release_date").gte(new Date(ranges.decades.min+"-1-1"));
  //  conditionAdded = true;
  //}
  //if (ranges.decades.max < new Date().getFullYear()){
  //  find.where("release_date").lte(new Date(ranges.decades.max+"-12-31"));
  //  conditionAdded = true;
  //}
  if (ranges.bpm.min > 0) {
    esFilter.body.query.bool.filter.push({"range": {"rhythm_bpm_mean" :{ "gt": ranges.bpm.min}}})
    conditionAdded = true;
  }
  if (ranges.bpm.max < 250) {
    esFilter.body.query.bool.filter.push({"range": {"rhythm_bpm_mean" :{ "lte": ranges.bpm.max}}})
    conditionAdded = true;
  }

  if (filters.rights[0].value == "Y" || userRole === "P") {
    esFilter.body.query.bool.filter.push({"term": {"sync" : true}})
    if(userRole !== "P") {
      conditionAdded = true;
    }
  }
  if (filters.rights[1].value == "Y") {
    esFilter.body.query.bool.filter.push({"term": {"stream_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[2].value == "Y") {
    esFilter.body.query.bool.filter.push({"term": {"download_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[3].value == "Y") {
    esFilter.body.query.bool.filter.push({"term": {"comps" : true}})
    conditionAdded = true;
  }
  if (filters.rights[4].value == "Y" && userRole !== "P") {
    esFilter.body.query.bool.filter.push({"term": {"lost_rights" : true}})
    conditionAdded = true;
  } else {
    esFilter.body.query.bool.filter.push(
      {"bool": {
        "should": [
          {
            "bool": {
              "must_not": [
                {
                  "exists": {
                    "field": "lost_rights"
                  }
                }
              ]
            }
          },
          {
            "term": {
              "lost_rights": false
            }
          }
        ]
      }
      })
  }
  if (filters.rights[5].value == "Y") {
    esFilter.body.query.bool.must_not.push({"term": {"unionized" : true}})
    conditionAdded = true;
  }
  if (filters.publishing[0].value == "Y") {
    esFilter.body.query.bool.filter.push({"term": {"uspub_publ_domain" : true}})
    conditionAdded = true;
  }
  if (matches.publishing_rights_country) {
    conditionAdded = true;
    if (matches.publishing_rights_country == "US") {
      esFilter.body.query.bool.filter.push({"range": {"uspub_umpg_shares": {"gte": ranges.minUMPGShares.min}}})
    } else {
      esFilter.body.query.bool.filter.push({"nested": {
        "path": "nouspub_rights",
        "query": {
          "bool": {
            "must": [
              {
                "term": {
                  "nouspub_rights.country_code.keyword": matches.publishing_rights_country
                }
              },
              {
                "range": {
                  "nouspub_rights.mechanicals": {
                    "gte": ranges.minUMPGShares.min
                  }
                }
              }
            ]
          }
        }
      }})
    }
  }
  if (search.labels && search.labels.length > 0) {
    conditionAdded = true;
    esFilter.body.query.bool.must.push({
      "query_string": {
        "fields": ["label_name",
          "company_name",
          "division_name"],
        "query": search.labels.join(" ") + " ~1",
        "use_dis_max": false
      }
    })
  }
  if (search.countries && search.countries.length > 0) {
    conditionAdded = true;
    esFilter.body.query.bool.must.push({
      "match": {
        "country_id": {
          "query": search.countries.join(" "),
          "operator": "or"
        }
      }
    })
  }
  if (search.umgGenres && search.umgGenres.length > 0) {
    conditionAdded = true;

    var shouldClause = [];
    search.umgGenres.forEach((item) => {
      shouldClause.push({"term": {"track_genre.keyword": item}})
    })
    esFilter.body.query.bool.filter.push(
      {
        "bool": {
          "should": shouldClause
        }
      }
    )
  }
  return conditionAdded;
};

function handleError(error) {
  if (error) {
    log.error(error);
  }
}


