'use strict';

import * as express from 'express';
import * as trackController from './track.controller';
import * as assetController from './asset.controller';
import * as config from '../../config/environment';
import auth from '../../auth/auth.service';

var router = express.Router();

//router.get('/tracks/', trackController.index);
router.get('/:id', auth.isAuthenticated(),  trackController.show);
router.get('/:id/audio/summary-stream', trackController.summaryStream);
router.get('/:id/audio/full-stream', auth.isAuthenticated(), trackController.fullStream);
router.get('/:id/assets/thumbnail-large', auth.isAuthenticated(), trackController.thumbnailLarge);
router.post('/suggestions/filter', auth.isAuthenticated(), trackController.findSuggestions);
//router.get('/tracks/:id/similar', trackController.findSimilarTracks);
router.post('/filter', auth.isAuthenticated(), trackController.filter);
router.post('/metrics/filter', auth.isAuthenticated(), trackController.metrics);
router.get('/?', auth.isAuthenticated(), trackController.searchByTitle);


module.exports = router;
