'use strict';

var crypto = require('crypto');

 /**
  * Authenticate - check if the passwords are the same
  *
  * @param {String} plainText
  * @return {Boolean}
  * @api public
  */
 export function authenticate(plainText) {
   return plainText === "kindofwife";
 }

 export function findById(id){
      return {_id:id, userName: id, role: "whatever"}
 }
