/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /artists              ->  index
 * POST    /artists              ->  create
 * GET     /artists/:id          ->  show
 * PUT     /artists/:id          ->  update
 * DELETE  /artists/:id          ->  destroy
 */

'use strict';

import * as albumDao from './album.model.es';
import * as envConfig from "../../config/local.env";
const bot = require('nodemw');
import * as knox from 'knox';
var log = require('../../config/logger.js').log;

// Get list of artists
// exports.index = function(req, res) {
//   Artist.find(function (err, artists) {
//     if(err) { return handleError(res, err); }
//     return res.json(200, artists);
//   });
// };

// Get a single artist
export function show(req, res) {
  var promise = albumDao.findById(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      res.status(200).json({searchId: req.body.id, result: result.hits.hits[0]._source})
    }, function (err) {
      return handleError(res, err)
    })
  } else {
    return res.send(400);
  }
}

export function streamResource(req, res) {
  var s3Client = knox.createClient(envConfig.S3_BUCKET_TRACKS);
  var path = req.query.file;
  s3Client.get(path)
    .on('response', function (s3res) {
        res.setHeader('Content-Length', s3res.headers['content-length']);
        res.setHeader('Content-Type', s3res.headers['content-type']);

        if (req.fresh) {
          res.statusCode = 304;
          res.end();
          return;
        }

        if (req.method === 'HEAD') {
          res.statusCode = 200;
          res.end();
          return;
        }

        s3res.pipe(res);
      }
    ).end();
}


export function loadAlbumWiki(req, res){

   var client = new bot({
      server: 'en.wikipedia.org',
      path: '/w',
      debug: true
    })

    let params = {
      action: 'query',
      prop: 'extracts',
      redirects: '',
      titles: req.params.pageId,
      exintro: '',
      explaintext:  ''
    };

    client.api.call(params, function(err, data) {
      if (err) {
        return res.status(err.status).json(err);
      }

      if (data.pages['-1'] == undefined) {
        res.status(200).send((data.pages[Object.keys(data.pages)[0]].extract));
      }else{
        res.status(400);
      }
    });
}

export function searchByAttribute(req, res) {
  var promise;
  if (req.query.title) {
    promise = albumDao.searchByTitle(req.query.title);
  }else if (req.query.canopus_id) {
    promise = albumDao.findByCanopusId(req.query.canopus_id);
  }else {
    promise = albumDao.findByAttributes(req.query);
  }
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(204);
      }
      return res.status(200).json(result);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

function handleError(res, err) {
  return res.send(500, err);
}

