'use strict';

import * as elasticsearch from 'elasticsearch';
import * as config from '../../config/environment';
var log = require('../../config/logger.js').log;

var elasticClient = new elasticsearch.Client({
  protocol: 'http',
  host: config.es.uri,
  log: config.es.LOG_LEVEL

});

var indexName = config.es.ALBUMS_IDX;

export function findById(upc){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "bool":  {
          "filter": {
            "term": {upc: upc}
          }
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findByAttributes(attributes){
  var body = {
    "size": 1000,
    "version": true,
    "query": {
      "bool": {
        "filter": []
      }
    },
    "sort": {
      "p_notice_year.keyword":{
        "order": "desc"
      }
    }
  }
  Object.keys(attributes).forEach((name) => {
    body.query.bool.filter.push({"term": {[name]: attributes[name]}})
  })
  var promise = elasticClient.search({
    index: indexName,
    body: body
  });
  promise.then(null,handleError);
  return promise;

}

export function searchByTitle(title){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      size: 10,
      "query": {
        "bool": {
          "should": [
            {
              "match": {
                "formatted_title.keyword_lowercase": {
                  "query": title.toLowerCase(),
                  "boost": 3
                }
              }
            },
            {
              "match": {
                "formatted_title": title
              }
            },
            {
              "match_phrase_prefix": {
                "formatted_title.keyword_lowercase": {
                  "query": title.toLowerCase(),
                  "max_expansions": 10,
                  "boost": 2
                }
              }
            }
          ],
          "minimum_number_should_match": 1,
          "must": {
            "match": {
              "upc_default": true
            }
          }
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}
export function findByCanopusId(canopusId){
  var body = {
    "size": 1000,
    "version": true,
    "query": {
      "bool": {
        "should": [
          {"term": {"canopus_id": canopusId}},
          {
            "nested": {
              "path": "featured",
              "query": {
                "bool": {
                  "must": [
                    {
                      "term": {
                        "featured.canopus_id": canopusId
                      }
                    }
                  ]
                }
              }
            }
          }
        ]
      }
    },
    "sort": {
      "p_notice_year.keyword":{
        "order": "desc"
      }
    }
  }

  var promise = elasticClient.search({
    index: indexName,
    body: body
  });
  promise.then(null,handleError);
  return promise;

}

function handleError(error) {
  if (error) {
    log.error(error);
  }
}
