'use strict';

import * as express from 'express';
import * as controller from './album.controller';

var router = express.Router();

router.get('/:id', controller.show);
router.get('/:id/stream?', controller.streamResource);//TODO why is not working ?
router.get('/?', controller.searchByAttribute);

// router.get('/:id/wiki/:pageId', controller.loadArtistWiki);

module.exports = router;
