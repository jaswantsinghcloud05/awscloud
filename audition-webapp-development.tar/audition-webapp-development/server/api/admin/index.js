'use strict';

import * as express from 'express';
import * as controller from './admin.controller';

var router = express.Router();

router.get('/system-info', controller.show);

module.exports = router;
