/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /system-info          ->  show
 */

'use strict';
import * as config from '../../config/environment';


// Get a single
export function show(req, res) {
    res.status(200).json({
      buildNumber: config.buildNumber,
      node: process.versions
    })
};

