// Initialize SDK
import * as envConfig from "../../config/local.env";
const log = require('../../config/logger.js').log;
//TODO use redis instead of map
var store = new Map();

export function setPlaylistUpdateStatus(playlistId, status) {
  store.set(playlistId,status);
}

export function getPlaylistUpdateStatus(playlistId) {
  return store.get(playlistId);
}

export function getMap() {
  //TODO for development only
  return store
}
