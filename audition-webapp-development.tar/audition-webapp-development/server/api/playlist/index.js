'use strict';

import * as express from 'express';
import * as playlistController from './playlist.controller';
import auth from '../../auth/auth.service';
var log = require('../../config/logger.js').log;

//var multer from 'multer');
import config from '../../config/environment';

var router = express.Router();

//router.get('/:id', controller.show);
//router.post('/:id/csv', [ multer({dest: config.UPLOAD_DIR}).single('file'), controller.csvUpload]);
router.get('/:id/box/status', auth.hasRole('playlist'), playlistController.getCopyToBoxStatus);
router.get('/:id', playlistController.show);
router.get('/?', auth.hasRole('playlist'),playlistController.searchByName);
router.put('/:id', auth.hasRole('playlist'), playlistController.update);
router.put('/:id?', auth.hasRole('playlist'), playlistController.update);
router.post('/', auth.hasRole('playlist'), playlistController.create);
router.post('/:id/box', auth.hasRole('playlist'), playlistController.savePlaylistToBox);
router.post('/filter', playlistController.filter);
router.post('/metrics/filter', playlistController.metrics);//TODO better using filter/metrics
router.post('/:id/email', playlistController.sendPlaylistEmail);
router.delete('/:id', auth.hasRole('playlist'),playlistController.delete);
//router.post('/:id/csv', [ require('multer')({dest: config.UPLOAD_DIR}).single('file'), playlistController.csvUpload]);


//we could update the whole track but until we have proper testing in place
//better limit the updates to the playlist field only


module.exports = router;
