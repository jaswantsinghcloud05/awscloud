'use strict';

import * as elasticsearch from 'elasticsearch';
import * as config from '../../config/environment';

var log = require('../../config/logger.js').log;
var elasticClient = new elasticsearch.Client({
  protocol: 'http',
  host: config.es.uri,
  log: config.es.LOG_LEVEL
});

var indexName = config.es.PLAYLISTS_IDX;
const IRCAM_CONF_LEVEL = 0.3;

export function findById(internalId){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "terms": {
          "_id": [internalId]
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findByAllAttributes(attributes){
  var query = {
    index: indexName,
    body: {
      "version": true,
      "query": {
        "bool": {
          "must": []
        }
      }
    }
  };
  attributes.forEach((item)=>{
    if (item.name){
      query.body.query.bool.must.push({match_phrase: item});
    }else{
      query.body.query.bool.must.push({match: item});
    }
  })
  var promise = elasticClient.search(query);
  promise.then(null,handleError);
  return promise;

}

export function findByIdNoFiles(r2_resource_id){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "_source":{
        "exclude": ["*_filename"]
      },
      "version": true,
      "query": {
        "ids": {
          "values": [r2_resource_id]
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function createPlaylist(document) {
  document.createdDate = Date.now();
  document.modifiedDate = Date.now();
  var promise = elasticClient.index({
    index: indexName,
    type: "playlist",
    refresh: true,
    body: document
  });
  promise.then(null,handleError);
  return promise;

}

export function updatePlaylist(id,version,document) {
  document.modifiedDate = Date.now();
  var promise = elasticClient.index({
    index: indexName,
    type: "playlist",
    refresh: true,
    version: version,
    id: id,
    body: document
  });
  promise.then(null,handleError);
  return promise;

}

export function addTrack(playlistId, track) {
  var promise = elasticClient.update({
    index: indexName,
    type: 'playlist',
    id: playlistId,
    body: {
      script: 'ctx._source.tracks += track',
      params: { track: track }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function searchByName(name) {
  var filter = {
    "index": indexName,
    "body": {
      "size": 30,
      "version": true,
      "query": {
        "bool": {
          "should": [
            {
              "match": {
                "name": name
              }
            },
            {
              "match_phrase_prefix": {
                "name.keyword_lowercase": {
                  "query": name.toLowerCase(),
                  "max_expansions": 10,
                  "boost": 2
                }
              }
            },
            {
              "match": {
                "name.keyword_lowercase": {
                  "query": name.toLowerCase(),
                  "boost": 3
                }
              }
            }
          ],
          "minimum_number_should_match": 1
        }
      },
      "sort": [
        {"_score": {"order": "desc"}}
      ]
    }
  }
  var promise = elasticClient.search(filter);
  promise.then(null,handleError);
  return promise;

}

export function searchByNameOwner(name, owner) {
  var filter = {
    "index": indexName,
    "body": {
      "size": 30,
      "version": true,
      "query": {
        "bool": {
          "should": [
            {
              "match": {
                "name": name
              }
            },
            {
              "match_phrase_prefix": {
                "name.keyword_lowercase": {
                  "query": name.toLowerCase(),
                  "max_expansions": 10,
                  "boost": 2
                }
              }
            },
            {
              "match": {
                "name.keyword_lowercase": {
                  "query": name.toLowerCase(),
                  "boost": 3
                }
              }
            }
          ],
          "must": [
            {
              "term": {
                "createdBy.keyword": owner
              }
            }
          ],
          "minimum_number_should_match": 1
        }
      },
      "sort": [
        {"_score": {"order": "desc"}}
      ]
    }
  }
  var promise = elasticClient.search(filter);
  promise.then(null,handleError);
  return promise;

}

export function deletePlaylist(id) {
  var promise = elasticClient.delete({
    index: indexName,
    type: "playlist",
    id: id
  });
  promise.then(null,handleError);
  return promise;

}

export function search(filterBody, skip) {

  var filters = filterBody.filters;
  var ranges = filterBody.ranges;
  var matches = filterBody.match;
  var sorting = filterBody.sorting;
  var query = filterBody.query;
  var search = filterBody.search;

  var esFilter = {
    index: indexName,
    body: {
      "size": filterBody.pageSize,
      "from" : skip,
      "version": true,
      // "_source":{TODO temporarily replaced exclude with include because I need the files info saved into the playlist when the user adds a track
      //   "exclude": ["*_filename"]
      // },
      "query": {
        "nested": {
          "path": "tracks",
          "query": {
            "bool": {
              "filter": [],
              "must_not": [],
              "must": []
            }
          }
        }
      },
      "sort": []
    }
  };
//TODO sorting for artist/track title needs to be reviewed https://www.elastic.co/guide/en/elasticsearch/guide/current/sorting-collations.html

  var conditionAdded = false;

  if (matches.resource_rollup_id) {
    esFilter.body.query.nested.query.bool.filter.push({"term": {"tracks.resource_rollup_id": matches.resource_rollup_id}});
    conditionAdded = true;
  }else if (matches.canopus_id){
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.canopus_id": matches.canopus_id}});
    conditionAdded = true;
  }else if(query) {
    conditionAdded = true;
    if (filterBody.boolean) {
      esFilter.body.query.nested.query.bool.must.push({
        "query_string": {
          "fields": ["tracks.artist_name^2",
            "tracks.formatted_title^2",
            "tracks.pc_notice_year",
            "tracks.company_name",
            "tracks.country_name",
            "tracks.genre_desc^2",
            "tracks.label_name"],
          "query": query,
          "use_dis_max": false,
          "lenient": true,
          "default_operator": "AND"
        }
      })
    } else {
      esFilter.body.query.nested.query.bool.minimum_number_should_match = 1
      esFilter.body.query.nested.query.bool.should = [
        {
          "match": {
            "tracks.formatted_title.keyword_lowercase": {
              "query": query.toLowerCase(),
              "boost": 3
            }
          }
        },
        {
          "match": {
            "tracks.formatted_title": query
          }
        },
        {
          "match_phrase_prefix": {
            "tracks.formatted_title.keyword_lowercase": {
              "query": query.toLowerCase(),
              "max_expansions": 10,
              "boost": 2
            }
          }
        }
      ]
      conditionAdded = true;
    }
  }
  if (filterBody.excludeLiveTracks) {
    esFilter.body.query.nested.query.bool.must_not.push({
      "term": {
        "tracks.version_title": "live"
      }
    });
    conditionAdded = true;
  }
  //TODO Security issue: is not secure to build the query using information coming straight from the client
  conditionAdded |= addRangeCondition(esFilter,filters.genres);
  conditionAdded |= addRangeCondition(esFilter,filters.intensities);
  conditionAdded |= addRangeCondition(esFilter,filters.instrumentations);
  conditionAdded |= addRangeCondition(esFilter,filters.emotions);
  conditionAdded |= addRangeCondition(esFilter,filters.arrangements);
  conditionAdded |= addRangeCondition(esFilter,filters.tempos);

  //if (filters.decades.min > 1900) {
  //  find.where("release_date").gte(new Date(filters.decades.min+"-1-1"));
  //  conditionAdded = true;
  //}
  //if (filters.decades.max < new Date().getFullYear()){
  //  find.where("release_date").lte(new Date(filters.decades.max+"-12-31"));
  //  conditionAdded = true;
  //}
  if (ranges.bpm.min > 0) {
    esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.rhythm_bpm_mean" :{ "gt": ranges.bpm.min}}})
    conditionAdded = true;
  }
  if (ranges.bpm.max < 250) {
    esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.rhythm_bpm_mean" :{ "lte": ranges.bpm.max}}})
    conditionAdded = true;
  }
  if (filters.rights[0].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.sync" : true}})
    conditionAdded = true;
  }
  if (filters.rights[1].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.stream_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[2].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.download_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[3].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.comps" : true}})
    conditionAdded = true;
  }
  if (filters.rights[4].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.lost_rights" : true}})
    conditionAdded = true;
  }else {
    esFilter.body.query.nested.query.bool.filter.push(
      {"bool": {
        "should": [
          {
            "bool": {
              "must_not": [
                {
                  "exists": {
                    "field": "tracks.lost_rights"
                  }
                }
              ]
            }
          },
          {
            "term": {
              "tracks.lost_rights": false
            }
          }
        ]
      }
      })
  }
  if (filters.publishing[0].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.uspub_publ_domain" : true}})
    conditionAdded = true;
  }
  if (matches.publishing_rights_country) {
    conditionAdded = true;
    if (matches.publishing_rights_country == "US") {
      esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.uspub_umpg_shares": {"gte": ranges.minUMPGShares.min}}})
    } else {
      esFilter.body.query.nested.query.bool.filter.push({"nested": {
        "path": "tracks.nouspub_rights",
        "query": {
          "bool": {
            "must": [
              {
                "term": {
                  "tracks.nouspub_rights.country_code.keyword": matches.publishing_rights_country
                }
              },
              {
                "range": {
                  "tracks.nouspub_rights.mechanicals": {
                    "gte": ranges.minUMPGShares.min
                  }
                }
              }
            ]
          }
        }
      }})
    }
  }
  if(search.labels && search.labels.length >0){
    conditionAdded = true;
    esFilter.body.query.nested.query.bool.must.push({"query_string" : {
      "fields": ["tracks.label_name",
        "tracks.company_name",
        "tracks.division_name"],
      "query": search.labels.join(" ") + " ~1",
      "use_dis_max": false
    }})
  }
  if(search.countries && search.countries.length >0) {
    conditionAdded = true;
    esFilter.body.query.nested.query.bool.must.push({
      "match": {
        "tracks.country_id": {
          "query": search.countries.join(" "),
          "operator": "or"
        }
      }
    })
  }

  //if (ranges.popularity.min > 0) {
  //  find.where("popularity").gte(ranges.popularity.min+10);//+10 is temporary have to fix the values in the table
  //  conditionAdded = true;
  //}
  //if (ranges.popularity.max < 90) {
  //  find.where("popularity").lte(ranges.popularity.max+10);
  //  conditionAdded = true;
  //}

  if (conditionAdded) {
    if (sorting && sorting.length > 0) {
      if (query && !(matches.canopus_id || matches.resource_rollup_id) || search.labels && search.labels.length>0 || search.countries && search.countries.length>0){
        esFilter.body.sort.push({
          "_score": {
            "order": "desc"
          }})
      }
      // esFilter.body.sort.push(...sorting.map(function (obj) {
      //   //TODO review the protocol to avoid getOwnPropertyNames
      //   var sortName = Object.getOwnPropertyNames(obj)
      //   return {[sortName]: obj[sortName] === 1 ? {"order": "asc"} : {"order": "desc"}};
      // }));
    }
    //sort by multiple columns
    //TODO better way but doens't work in old nodes
    // if (sorting && sorting.length > 0){
    //   sorting.forEach(function(item) {
    //     var sortName = Object.getOwnPropertyNames(item)
    //     var order = sorting[sortName] === 1 ? {"order": "asc"} : {"order": "desc"}
    //     esFilter.body.sort.push({[sortName]: order});
    //   })
    // }
    var promise = elasticClient.search(esFilter);
    promise.then(null,handleError);
    return promise;

  }

}

export function metrics(filterBody, skip) {

  var filters = filterBody.filters;
  var ranges = filterBody.ranges;
  var matches = filterBody.match;
  var query= filterBody.query;
  var search = filterBody.search;

  var esFilter = {
    index: indexName,
    body: {
      "size": 0,
      "query": {
        "nested": {
          "path": "tracks",
          "query": {
            "bool": {
              "filter": [],
              "must_not": [],
              "must": []
            }
          }
        }
      },
      "aggs": {
        "tracks" : {
          "nested" : {
            "path" : "tracks"
          },
          "aggs": {}
        }
      }
    }
  };

  //TODO Security issue: is not secure to build the query using information coming straight from the client
  addAggregationCondition(esFilter.body.aggs.tracks.aggs,filters.genres);
  addAggregationCondition(esFilter.body.aggs.tracks.aggs,filters.intensities);
  addAggregationCondition(esFilter.body.aggs.tracks.aggs,filters.instrumentations);
  addAggregationCondition(esFilter.body.aggs.tracks.aggs,filters.emotions);

  var conditionAdded = false;

  if (matches.resource_rollup_id) {
    esFilter.body.query.nested.query.bool.filter.push({"term": {"tracks.resource_rollup_id": matches.resource_rollup_id}});
    conditionAdded = true;
  }else if (matches.canopus_id){
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.canopus_id": matches.canopus_id}});
    conditionAdded = true;
  }else if(query) {
    conditionAdded = true;
    if (filterBody.boolean) {
      esFilter.body.query.nested.query.bool.must.push({
        "query_string": {
          "fields": ["tracks.artist_name^2",
            "tracks.formatted_title^2",
            "tracks.pc_notice_year",
            "tracks.company_name",
            "tracks.country_name",
            "tracks.genre_desc^2",
            "tracks.label_name"],
          "query": query,
          "use_dis_max": false,
          "lenient": true,
          "default_operator": "AND"
        }
      })
    } else {
      esFilter.body.query.nested.query.bool.minimum_number_should_match = 1
      esFilter.body.query.nested.query.bool.should = [
        {
          "match": {
            "tracks.formatted_title.keyword_lowercase": {
              "query": query.toLowerCase(),
              "boost": 3
            }
          }
        },
        {
          "match": {
            "tracks.formatted_title": query
          }
        },
        {
          "match_phrase_prefix": {
            "tracks.formatted_title.keyword_lowercase": {
              "query": query.toLowerCase(),
              "max_expansions": 10,
              "boost": 2
            }
          }
        }
      ]
      conditionAdded = true;
    }
  }
  if (filterBody.excludeLiveTracks) {
    esFilter.body.query.nested.query.bool.must_not.push({
      "term": {
        "tracks.version_title": "live"
      }
    });
    conditionAdded = true;
  }

  conditionAdded |= addRangeCondition(esFilter,filters.genres);
  conditionAdded |= addRangeCondition(esFilter,filters.intensities);
  conditionAdded |= addRangeCondition(esFilter,filters.instrumentations);
  conditionAdded |= addRangeCondition(esFilter,filters.emotions);
  conditionAdded |= addRangeCondition(esFilter,filters.arrangements);
  conditionAdded |= addRangeCondition(esFilter,filters.tempos);

  //if (ranges.decades.min > 1900) {
  //  find.where("release_date").gte(new Date(ranges.decades.min+"-1-1"));
  //  conditionAdded = true;
  //}
  //if (ranges.decades.max < new Date().getFullYear()){
  //  find.where("release_date").lte(new Date(ranges.decades.max+"-12-31"));
  //  conditionAdded = true;
  //}
  if (ranges.bpm.min > 0) {
    esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.rhythm_bpm_mean" :{ "gt": ranges.bpm.min}}})
    conditionAdded = true;
  }
  if (ranges.bpm.max < 250) {
    esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.rhythm_bpm_mean" :{ "lte": ranges.bpm.max}}})
    conditionAdded = true;
  }
  if (filters.rights[0].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.sync" : true}})
    conditionAdded = true;
  }
  if (filters.rights[1].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.stream_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[2].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.download_restrict" : false}})
    conditionAdded = true;
  }
  if (filters.rights[3].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.comps" : true}})
    conditionAdded = true;
  }
  if (filters.rights[4].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.lost_rights" : true}})
    conditionAdded = true;
  }else {
    esFilter.body.query.nested.query.bool.filter.push(
      {"bool": {
        "should": [
          {
            "bool": {
              "must_not": [
                {
                  "exists": {
                    "field": "tracks.lost_rights"
                  }
                }
              ]
            }
          },
          {
            "term": {
              "tracks.lost_rights": false
            }
          }
        ]
      }
      })
  }
  if (filters.publishing[0].value=="Y") {
    esFilter.body.query.nested.query.bool.filter.push({"term":{"tracks.uspub_publ_domain" : true}})
    conditionAdded = true;
  }

  if (matches.publishing_rights_country) {
    conditionAdded = true;
    if (matches.publishing_rights_country == "US") {
      esFilter.body.query.nested.query.bool.filter.push({"range": {"tracks.uspub_umpg_shares": {"gte": ranges.minUMPGShares.min}}})
    } else {
      esFilter.body.query.nested.query.bool.filter.push({"nested": {
        "path": "tracks.nouspub_rights",
        "query": {
          "bool": {
            "must": [
              {
                "term": {
                  "tracks.nouspub_rights.country_code.keyword": matches.publishing_rights_country
                }
              },
              {
                "range": {
                  "tracks.nouspub_rights.mechanicals": {
                    "gte": ranges.minUMPGShares.min
                  }
                }
              }
            ]
          }
        }
      }})
    }
  }
  if(search.labels && search.labels.length >0){
    conditionAdded = true;
    esFilter.body.query.nested.query.bool.must.push({"query_string" : {
      "fields": ["label_name",
        "company_name",
        "division_name"],
      "query": search.labels.join(" ") + " ~1",
      "use_dis_max": false
    }})
  }
  if(search.countries && search.countries.length >0){
    conditionAdded = true;
    esFilter.body.query.nested.query.bool.must.push({"match" : {
      "country_id": {
        "query": search.countries.join(" "),
        "operator": "or"
      }
    }})
  }

  //if (ranges.popularity.min > 0) {
  //  find.where("popularity").gte(ranges.popularity.min+10);//+10 is temporary have to fix the values in the table
  //  conditionAdded = true;
  //}
  //if (ranges.popularity.max < 90) {
  //  find.where("popularity").lte(ranges.popularity.max+10);
  //  conditionAdded = true;
  //}

 if (conditionAdded) {
    var promise = elasticClient.search(esFilter);
    promise.then(null,handleError);
    return promise;
  }else{
    return null;
  }

}


function addRangeCondition(query, filterArray){
  var added = false;
  filterArray.forEach(function(item){
    var nestedName = "tracks." + item.id
    if(item.value === 'Y'){
      query.body.query.nested.query.bool.filter.push({"range":{[nestedName] : {"gt": IRCAM_CONF_LEVEL}}});
      added = true;
    }else if (item.value === 'N'){
      query.body.query.nested.query.bool.filter.push({"term":{[nestedName] : 0}});
      added = true;
    }
  });
  return added;
};

function addAggregationCondition(aggregator, filterArray){
  filterArray.forEach(function(item){
    var aggName = "tracks."+ item.id
    aggregator[item.id] = {
      "filter": {
        "range": {[aggName]: {"gt": IRCAM_CONF_LEVEL}}
      }
    }
  });
};

function handleError(error) {
  if (error) {
    log.error(error);
  }
}
