/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /artists              ->  index
 * POST    /artists              ->  create
 * GET     /artists/:id          ->  show
 * PUT     /artists/:id          ->  update
 * DELETE  /artists/:id          ->  destroy
 */

'use strict';

var fs = require('fs');
import * as playlistEsDAO from './playlist.model.es';
import * as playlistBoxDAO from './playlist.model.box';
import * as playlistRedisDAO from './playlist.model.redis';
import * as envConfig from "../../config/local.env";
import * as email from "../../components/utils/email";

// Get a single playlist
exports.show = function (req, res) {
  var promise = playlistEsDAO.findById(req.params.id);
  if (promise) {
    promise.then((result) => {
      res.status(200).json({result: result})
    }, function (error) {
      return handlerDAOError(res, error)
    });
  } else {
    return res.send(500);
  }
};

exports.create = function (req, res) {
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID) {
    req.body.createdBy = req.user.preferred_username;
  }else{
    req.body.createdBy = req.user.sub;
  }
  var findPromise = playlistEsDAO.findByAllAttributes([{createdBy: req.body.createdBy}, {"name.keyword_lowercase": req.body.name.toLowerCase()}]);
  if (findPromise) {
    findPromise.then((findResult) => {
      if (findResult.hits.hits.length > 0) {
        return res.send(400);
      } else {
        var promise = playlistEsDAO.createPlaylist(req.body);
        if (promise) {
          promise.then((result) => {
            playlistEsDAO.findById(result._id)
              .then((result1) => {
                res.status(200).json({result: result1})
              })
          }, function (err) {
            return handlerDAOError(res, err)
          });
        } else {
          return res.send(500);
        }
      }
    }, function (err) {
      return handlerDAOError(res, err)
    });
  } else {
    return res.send(500);
  }

};

exports.update = function (req, res) {
  var findPromise = playlistEsDAO.findById(req.params.id);
  if (findPromise) {
    findPromise.then((result) => {
      if (result.hits.hits.length > 0){
        var tracks = req.body.tracks;
        if (req.user.aud !== envConfig.OKTA.OAUTH2_CLIENTID && result.hits.hits[0]._source.createdBy == req.user.sub
            || req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID && result.hits.hits[0]._source.createdBy == req.user.preferred_username) {
          for (var i=0; tracks && i<tracks.length; i++){
            for (var x=i+1; x<tracks.length; x++){
              if(tracks[i].r2_resource_id == tracks[x].r2_resource_id){
                return res.status(422).json({error: "Duplicate entry in playlist"});
              }
            }
          }
          var promise = playlistEsDAO.updatePlaylist(req.params.id, req.query.ver, req.body);
          if (promise) {
            promise.then((result) => {
              playlistEsDAO.findById(result._id)
                .then((result1) => {
                  res.status(200).json({result: result1})
                })
            }, function (err) {
              return handlerDAOError(res, err)
            });
          }
        } else {
          return res.status(403).json({error: "Only the playlist owner can update it"});
        }
      }
    }, function (err) {
        return handlerDAOError(res, err)
      });
  } else {
    return res.send(500);
  }

};

exports.searchByName = function (req, res) {
  var promise;
  if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
    promise = playlistEsDAO.searchByNameOwner(req.query.name,req.user.preferred_username);
  }else{
    promise = playlistEsDAO.searchByName(req.query.name);
  }
  if (promise) {
    promise.then((result) => {
      res.status(200).json({result: result})
    }, function (error) {
      return handlerDAOError(res, error)
    });
  } else {
    return res.send(500);
  }

};

exports.savePlaylistToBox = function (req, res) {
  var promise = playlistEsDAO.findById(req.params.id);
  if (promise) {
    promise.then((result) => {
      var boxPromise;
      if(req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID){
        boxPromise = playlistBoxDAO.savePlaylist(result.hits.hits[0], req.user.preferred_username, req.user.umgSponsorEmail);
      }else{
        boxPromise = playlistBoxDAO.savePlaylist(result.hits.hits[0], req.user.sub);
      }
      boxPromise.then((result) => {
          res.status(200).json(result)
        }, function (err) {
          err.source = "box.com";
          return handlerDAOError(res, err)
        })
    }, function (err) {
      return handlerDAOError(res, err)
    });
  } else {
    return res.send(500);
  }

}

exports.getCopyToBoxStatus = function (req, res) {
  var status = playlistRedisDAO.getPlaylistUpdateStatus(req.params.id)
  if (status) {
    res.status(200).json({result: status})
  } else {
    res.send(404);
  }
}

exports.delete = function (req, res) {
  var promise = playlistEsDAO.findById(req.params.id);
  if (promise) {
    promise.then((result) => {
      var playlist = result.hits.hits[0];
      if (req.user.aud !== envConfig.OKTA.OAUTH2_CLIENTID && playlist._source.createdBy == req.user.sub
        || req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID && playlist._source.createdBy == req.user.preferred_username) {
        if(req.query.removeFiles == "true"){
          playlistBoxDAO.deletePlaylist(playlist,req.user.aud === envConfig.OKTA.OAUTH2_CLIENTID? req.user.preferred_username:req.user.sub).then(
            (boxResult)=>{
              return deleteFromEs(req, res);
          },(err)=>{
              err.source = "box.com";
              return handlerDAOError(res, err);
          })
        }else{
          return deleteFromEs(req, res)
        }
      } else {
        return res.status(403).json({error: "Only the playlist owner can delete it"});
      }
    }, function (error) {
      return handlerDAOError(res, error)
    });
  } else {
    return res.send(500);
  }
};

function deleteFromEs(req, res){
  var deletePromise = playlistEsDAO.deletePlaylist(req.params.id);
  if (deletePromise) {
    deletePromise.then((result) => {
      return res.status(200).json({result: result});
    }, function (error) {
      return handlerDAOError(res, error);
    });
  } else {
    return res.send(500);
  }
}

export function filter(req, res) {
  var skip = parseInt(req.query.skip);
  if (isNaN(skip)) {
    skip = 0;
  }
  var promise = playlistEsDAO.search(req.body, skip);
  if (promise) {
    promise.then(function (result) {
      res.status(200).json({searchId: req.body.id, result: result})
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
}

// Get list of tracks
export function metrics(req, res) {
  var promise = playlistEsDAO.metrics(req.body);
  if (promise) {
    promise.then(function (result) {
      res.status(200).json({searchId: req.body.id, result: result})
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(400);
  }
};

// Get list of tracks
export function sendPlaylistEmail(req, res) {
  var promise = playlistEsDAO.findById(req.params.id);
  if (promise) {
    promise.then((result) => {
      if (result.hits.hits[0]){
        const playlist = result.hits.hits[0]._source
        var content = String.fromCharCode(13) + String.fromCharCode(13) + "The playlist " + playlist.name + " is available at " + playlist.box_public_url
        content += String.fromCharCode(13) + "List of tracks" + String.fromCharCode(13) + String.fromCharCode(13);
        for (var i=0; i<playlist.tracks.length;i++){
          var item = playlist.tracks[i];
          content += (i+1) + ". " + item.formatted_title + " by " + item.artist_name + String.fromCharCode(13);
        }
        email.sendEmail(req.user.email,req.user.umgSponsorEmail,playlist.name,content);
        return res.status(200).send("Submitted");
      }else{
        return res.status(404).json({result: result})
      }
    }, function (error) {
      return handlerDAOError(res, error)
    });
  } else {
    return res.send(500);
  }
};


function handleGeneralError(res, err) {
  return res.send(500, err);
}

function handlerDAOError(res, error) {
  if(error && error.source){
    res.status(error.status).json({source: error.source, result: error})
  }else{
    res.status(error.status || 400).json({result: error})
  }
}
