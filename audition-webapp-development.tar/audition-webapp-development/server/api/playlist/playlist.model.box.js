// Initialize SDK
import * as boxService from '../../auth/box/box.service';
import * as redisDao from './playlist.model.redis';
import * as playlistEsDAO from './playlist.model.es';

import * as knox from 'knox';
import * as localConfig from "../../config/local.env";
import * as config from '../../config/environment';
const fs = require('fs');
const log = require('../../config/logger.js').log;
var BoxSDK = require('box-node-sdk');
//TODO handle multiple umg teams by passing "umeaudio@umusic.com" as a parameter to the function
var umeBoxSDK = BoxSDK.getPreconfiguredInstance(localConfig.BOX.serviceAccount);

var s3Client = knox.createClient(localConfig.S3_BUCKET_TRACKS);//TODO box API don't handle s3 streams from offical aws-sdk
var AWS = require('aws-sdk');
AWS.config.loadFromPath(config.AWS_CONFIG);
AWS.config.logger = process.stdout
var s3 = new AWS.S3({apiVersion: '2006-03-01'});

export function deletePlaylist(playlistEs, userToken) {
  var playlist = playlistEs._source;
  return new Promise(function (resolve, reject) {
    var client = boxService.getBoxClient(userToken);
    if (!client) {
      reject({status: 401, message: "box login required"});
    } else {
      findBoxFolder(playlist.createdBy.toLowerCase(), client)
        .then((userFolder) => {
          if (userFolder) {
            //Drill in the user folder
            findBoxFolder(playlist.name.toLowerCase(), client, userFolder.id)
              .then((data) => {
                if (data) {
                  client.folders.delete(data.id, {recursive: true}, function (err, data) {
                    if (err) {
                      log.error(err);
                      reject({status: 500, message: "Unable to delete playlist folder " + data.id, error: err});
                    } else {
                      resolve({status: 200});
                    }
                  })
                } else {
                  resolve({status: 200});
                }
              }, (error) => {
                log.console(error);
                reject({status: 500, error: "Unable to connect to Box"});
              })
          } else {
            resolve({status: 200});
          }
        })
    }
  })
}


export function savePlaylist(playlistEs, userName, umgSponsorEmail) {//TODO remove usertoken as param
  // Create a basic API client
  return new Promise(function (resolve, reject) {
    var client;
    if (umgSponsorEmail){
      client = umeBoxSDK.getAppAuthClient("enterprise","348690");//TODO will use umgContactEmail
    }else{
      //TODO handle multiple umg teams by passing "umeaudio@umusic.com" as a parameter to the function
      client = boxService.getBoxClient(userName);
    }
    var playlist = playlistEs._source;
    if (client) {
      /*
       *   FIND OR CREATE CURRENT USER AND CURRENT PLAYLIST FOLDERS
       */
      //TODO use recursion to create folders
      //Search in root folder
      var userFolder;
      var playlistFolder;
      findBoxFolder(playlist.createdBy.toLowerCase(), client)
        .then((userFolder) =>{
          if (userFolder) {
          //Drill in the user folder
            findBoxFolder(playlist.name.toLowerCase(), client, userFolder.id)
              .then((playlistFolder) => {
                if (playlistFolder) {
                  redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:200, progress: 2, message:"Cleaning existing folder"});
                  resolve({status: 200, result: {sharedLink: playlist.box_public_url}});
                  client.folders.getItems(
                    playlistFolder.id,
                    {
                      fields: 'name',
                      offset: 0,
                      limit: 1000
                    },
                    function (err, data, reject) {
                      if (err) {
                        log.error(err);
                        redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Error listing box folder " + playlist.createdBy})
                      } else {
                        uploadToExistingPlaylistFolder(data.entries, 0, playlistFolder, playlistEs, client)
                      }
                    })
                }else{
                  uploadToNewPlaylistFolder(userFolder.id, playlist.name.replace(/[/\\]/g, ''), playlistEs, client, reject,resolve)
                }
              },(error) =>{
                redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Error connecting to box"})
                reject({status: 500, message: "Error connecting to box " + playlist.name, error: error});
              })
        } else {
          //Create the user folder and playlist folder
          client.folders.create('0', playlist.createdBy.replace(/[/\\]/g, ''), function (err, folder) {
            if (err) {
              log.error(err);
              redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Unable to create box folder " + playlist.createdBy})
              reject({status: 500, message: "Unable to create folder " + playlist.name, error: err});
            } else {
              userFolder = folder;
              uploadToNewPlaylistFolder(userFolder.id, playlist.name.replace(/[/\\]/g, ''), playlistEs, client, reject,resolve)
            }
          });
        }
      }
    ,(error, data) =>{
      redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Error connecting to box"})
      console.log("***Error " + error);
      reject({status: 500, message: "unable to create folder " + playlist.name, error: err});
      })
      // **********************************
    } else {
      reject({status: 401, message: "box login required"});
    }
  });
}


function uploadToExistingPlaylistFolder(files, index, playlistFolder, playlistEs, client) {
  if (files.length>0){
    client.files.delete(files[index].id, function(err, data){
      if (err) {
        log.error(err);
        redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Unable to delete file " + files[index].name})
      } else {
        redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:200, progress: index+3, message:"Deleted files " + (index+1) + " of " + files.length})
        if(index<files.length-1) {
          uploadToExistingPlaylistFolder(files, ++index, playlistFolder, playlistEs, client);
        }else{
          uploadTracksToBox(playlistEs, playlistEs._source.tracks.length-1, playlistFolder, client);
        }
      }
    })
  }else{
    uploadTracksToBox(playlistEs, playlistEs._source.tracks.length-1, playlistFolder, client);
  }
}

function uploadToNewPlaylistFolder(parentFolder, playlistFolder, playlistEs, client, reject,resolve) {
  var playlist = playlistEs._source;
  client.folders.create(parentFolder, playlistFolder, function (err, data) {
    if (err) {
      log.error(err);
      redisDao.setPlaylistUpdateStatus(playlistEs._id, {
        status: 500,
        progress: 100,
        message: "Unable to create box folder " + playlist.name
      })
      reject({status: 500, message: "unable to create folder " + playlist.name, error: err});
    } else {
      playlistFolder = data;
      client.put("/folders/" + playlistFolder.id, {body: {"shared_link": {"access": "open"}}},
        function (err, response) {
          handleSharedLinkAndUploadTracks(err, response, playlistEs, playlistFolder, client, reject, resolve);
        });
    }
  })
}

function handleSharedLinkAndUploadTracks(err, response, playlistEs, playlistFolder, client, reject,resolve){
  var playlist = playlistEs._source;
  if (err) {
    redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Unable to create a shared link for folder " + playlist.name})
    reject({
      status: 500,
      message: "unable to share the folder" + playlist.name,
      error: err
    });
    log.error(err);
  } else {
    redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:200, progress: 4, message:"Created shared link " + response.body.shared_link.url})
    playlist.box_public_url = response.body.shared_link.url;
    playlistEsDAO.updatePlaylist(playlistEs._id, playlistEs._version, playlist)
      .then((result) => {
        uploadTracksToBox(playlistEs, playlist.tracks.length-1, playlistFolder, client)
        resolve({status: 200, result: {sharedLink: response.body.shared_link.url}});
      },function (error) {
        log.error(error);
        if (error && error.status==409){
          var newVersion = playlistEsDAO.findById(playlistEs._id)//TODO hopefully we wont get another 409
          newVersion._source.box_public_url = response.body.shared_link.url;
          playlistEsDAO.updatePlaylist(newVersion._id, newVersion.version, newVersion._source);
          redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"The current playlist has been updated outside of this session, please reload it and try again"})
          reject({status: 500, message: "The current playlist has been updated outside of this session, please reload it and try again" + playlist.name, error: err});
        }else{
          redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Unable to save box's shared link. Please un-share the folder form your box account and try again"})
          reject({status: 500, message: "Unable to save box's shared link. Please un-share the folder form your box account and try again" + playlist.name, error: err});
        }
      });
  }

}

function uploadTracksToBox(playlistEs, position, playlistFolder, boxClient) {
  var tracks = playlistEs._source.tracks;
  var track = tracks[position];
  var params = {Bucket: localConfig.S3_BUCKET_TRACKS.bucket, Key: track.audio_transcode_filename.substring(20)};
  s3.headObject(params, function(err, data) {
    if (err){
      redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:500, progress: 100, message:"Track " + track.formatted_title + " not found on S3"})
      log.error(err.stack);
      log.error(localConfig.S3_BUCKET_TRACKS.bucket + " " + track.audio_transcode_filename.substring(20));
    }else {
      var fileSize = data.ContentLength;
      s3Client.get(track.audio_transcode_filename.substring(19))
        .on('response', function (res) {
          makeRequest(playlistEs, position, playlistFolder, boxClient, res, parseInt(fileSize));
        })
        .on('error', function(err) {
          log.error(err)
        })
        .end();
    }
  });
}

function makeRequest(playlistEs, position, playlistFolder, boxClient, stream, fileSize, retries) {
  var tracks = playlistEs._source.tracks;
  var track = tracks[position];
  var progress = (tracks.length-position)/(tracks.length+1)*100
  var sanitizedName  = (position+1) + "." + (track.formatted_title + " by " + track.artist_name ).trim().replace(/[/\\]/g, '') + ".mp3"
  if(retries){
    redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:200, progress: progress, message:"Connection to Box interrupted during the copy. " +
    String.fromCharCode(13)+ "Trying again file " + sanitizedName + ". " +
    String.fromCharCode(13)+ "Attempt number " + retries})
  }else{
    redisDao.setPlaylistUpdateStatus(playlistEs._id,{status:200, progress: progress, message:"Uploading file " + sanitizedName + " to box ..."})
  }
  if(fileSize > 50000000){
    log.warn("***NEW UPLOAD, file size:" + fileSize + ",name: " + sanitizedName);
    boxClient.files.getChunkedUploader(playlistFolder.id, fileSize, sanitizedName, stream, null, function (err, uploader) {
      if (!handleFailedUpload(err,playlistEs, position, playlistFolder, boxClient, stream, fileSize, retries)) {
        uploader.on('uploadComplete', function (file) {
          if (position > 0) {
            uploadTracksToBox(playlistEs, position - 1, playlistFolder, boxClient)
          } else {
            redisDao.setPlaylistUpdateStatus(playlistEs._id, {
              status: 201,
              progress: 100,
              message: "Copy completed with success"
            })
          }
        });
        uploader.on('error', function (err) {
          handleFailedUpload(err)
        });
        uploader.start();
      }
    });
  }else{
    boxClient.files.uploadFile(playlistFolder.id, sanitizedName, stream, function (err, data) {
      if (!handleFailedUpload(err, playlistEs, position, playlistFolder, boxClient, stream, fileSize, retries)) {
        if (position > 0) {
          uploadTracksToBox(playlistEs, position - 1, playlistFolder, boxClient)
        } else {
          redisDao.setPlaylistUpdateStatus(playlistEs._id, {
            status: 201,
            progress: 100,
            message: "Copy completed with success"
          })
        }
      }
    })
  }
}

function handleFailedUpload(err,playlistEs, position, playlistFolder, boxClient, stream, fileSize, retries) {

  var foundError = false;
  var track = playlistEs._source.tracks[position];
  if (err) {
    if (err.code == "ETIMEDOUT" || err.code == "ECONNRESET") {
      //connection timeout let's try again
      retries = retries || 0;
      if (retries <= 5) {
        //try to re-download the file and re-upload it
        makeRequest(playlistEs, position, playlistFolder, boxClient, stream, fileSize, ++retries);
      } else {
        //tried 5 times, giving up
        var sanitizedName = (position+1) + "." + (track.formatted_title + " by " + track.artist_name ).trim().replace(/[/\\]/g, '') + ".mp3"
        redisDao.setPlaylistUpdateStatus(playlistEs._id, {
          status: 500,
          progress: 100,
          message: "Giving up trying copying file " + sanitizedName + " after 5 attempts."
        })
        var error = {
          status: 500,
          message: "Giving up trying to upload the file " + sanitizedName,
          error: err
        };
        log.error(error);
        foundError = true;
      }
    } else {
      var sanitizedName = (position+1) + "." + (track.formatted_title + " by " + track.artist_name ).trim().replace(/[/\\]/g, '') + ".mp3"
      redisDao.setPlaylistUpdateStatus(playlistEs._id, {
        status: 500,
        progress: 100,
        message: "Unable to copy file " + sanitizedName + " to Box."
      })
      var error = {
        status: 500,
        message: "Unable to upload file" + sanitizedName,
        error: err
      };
      log.error(error);
      foundError = true;
    }
  }
  return foundError;
}


function findBoxFolder(folder, client, parentFolderId, offset) {
  var limit = 1000;
  var boxFolder;
  offset = offset || 0;
  return new Promise(function (resolve, reject) {
    client.folders.getItems(
      parentFolderId || '0',
      {
        fields: 'name',
        offset: offset,
        limit: limit
      },
      function (err, data) {
        if (err) {
          log.error(err);
          reject(err);
        } else {
          var total_count = data.total_count;
          offset += limit;
          data.entries.some(function (item) {
            if (item.name.toLowerCase() == folder) {
              boxFolder = item;
              return true;
            } else {
              return false;
            }
          })
          if (boxFolder) {
            resolve(boxFolder)
          } else if (total_count > offset) {
            var promise = findBoxFolder(folder, client, parentFolderId, offset)
              .then(function (data) {
                resolve(data);
              }, function (error) {
                log.error(error);
                reject(error);
              })
          }else{
            resolve(null);
          }
        }
      })
  })
}



