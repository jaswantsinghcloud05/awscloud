'use strict';

import * as elasticsearch from 'elasticsearch';
import * as config from '../../config/environment';
var log = require('../../config/logger.js').log;

var elasticClient = new elasticsearch.Client({
  protocol: 'http',
  host: config.es.uri,
  log: config.es.LOG_LEVEL

});

var indexName = config.es.ARTISTS_IDX;

export function findById(canopusId){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "ids": {
          "values": [canopusId]
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function findByAttribute(name, value){
  var promise = elasticClient.search({
    index: indexName,
    body: {
      "version": true,
      "query": {
        "bool":  {
          "filter": {
            "term": {[name]: value}
          }
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

export function searchByAlias(alias){
  var promise = elasticClient.search({
    index: indexName,
    "body": {
      "size": 10,
      "query": {
        "nested": {
          "path": "aliases",
          "query": {
            "bool": {
              "should": [
                {
                  "match": {
                    "aliases.name": alias
                  }
                },
                {
                  "match_phrase_prefix": {
                    "aliases.name.keyword_lowercase": {
                      "query": alias.toLowerCase(),
                      "max_expansions": 10,
                      "boost": 2
                    }
                  }
                },
                {
                  "match": {
                    "aliases.name.keyword_lowercase": {
                      "query": alias.toLowerCase(),
                      "boost": 3
                    }
                  }
                }
              ],
              "minimum_number_should_match": 1
            }
          }
        }
      }
    }
  });
  promise.then(null,handleError);
  return promise;

}

function handleError(error) {
  if (error) {
    log.error(error);
  }
}
