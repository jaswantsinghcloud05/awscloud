/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /artists              ->  index
 * POST    /artists              ->  create
 * GET     /artists/:id          ->  show
 * PUT     /artists/:id          ->  update
 * DELETE  /artists/:id          ->  destroy
 */

'use strict';

import * as artistDao from './artist.model.es';
const bot = require('nodemw');
const url = require('url');

// Get list of artists
// exports.index = function(req, res) {
//   Artist.find(function (err, artists) {
//     if(err) { return handleError(res, err); }
//     return res.json(200, artists);
//   });
// };

// Get a single artist
export function show(req, res) {
  var promise = artistDao.findById(req.params.id);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(404);
      }
      res.status(200).json({searchId: req.body.id, result: result.hits.hits[0]._source})
    }, function (err) {
      return handleError(res, err)
    })
  } else {
    return res.send(403);
  }
};

export function searchByAlias(req, res) {
  var promise = artistDao.searchByAlias(req.query.alias);
  if (promise) {
    promise.then(function (result) {
      if (result.hits.total == 0) {
        return res.send(204);
      }
      return res.status(200).json(result);
    }, function (err) {
      return handleError(res, err)
    });
  } else {
    return res.send(403);
  }
}

export function loadArtistWiki(req, res){

   var client = new bot({
      server: 'en.wikipedia.org',
      path: '/w',
      debug: true
    })

    let params = {
      action: 'query',
      prop: 'extracts',
      redirects: '',
      titles: req.params.pageId,
      exintro: '',
      explaintext:  ''
    };

    client.api.call(params, function(err, data) {
      if (err) {
        return res.status(err.status).json(err);
      }

      if (data.pages['-1'] == undefined) {
        res.status(200).send((data.pages[Object.keys(data.pages)[0]].extract));
      }else{
        res.status(404);
      }
    });
}

export function proxyUrl(client_req, client_res){
  var request = require('request');
  var r = request.get(client_req.query.url, function (err, res, body) {

    const util = require('util')
    console.log("RES" + util.inspect(res, {depth: null}));
    console.log("RES" + res.statusCode);
    console.log("HEa" + res.headers[hasHeader('location', res.headers)]);
    client_res.writeHead(200, res.headers);
    client_res.write(res.body);
    client_res.end();
  });
}

function handleError(res, err) {
  return res.send(500, err);
}

function hasHeader(header, headers) {
  var headers = Object.keys(headers || this.headers)
    , lheaders = headers.map(function (h) {return h.toLowerCase()})
    ;
  header = header.toLowerCase()
  for (var i=0;i<lheaders.length;i++) {
    if (lheaders[i] === header) return headers[i]
  }
  return false
}
