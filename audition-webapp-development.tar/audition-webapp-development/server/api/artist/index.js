'use strict';

import * as express from 'express';
import * as controller from './artist.controller';

var router = express.Router();

router.get('/:id', controller.show);
router.get('/:id/wiki/:pageId', controller.loadArtistWiki);
router.get('/external?', controller.proxyUrl);
router.get('/?', controller.searchByAlias);

module.exports = router;
