'use strict';
const nodemailer = require('nodemailer');
const config = require('../../config/local.env');

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
  host: 'usaws17wviis002.global.umusic.net',//usaws17wviis003.global.umusic.net
  port: 25,
  secure: false, // true for 465, false for other ports
});


export function sendEmail(receiver, copy, subject, body, bodyHtml){

  // setup email data with unicode symbols
  let mailOptions = {
    from: '"UMG Audition" <' + copy + '>', // sender address
    to: receiver, // list of receivers
    bcc: copy,
    subject: subject, // Subject line
    text: body, // plain text body
    html: bodyHtml // html body
  };

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.log(error);
    }
  });
}
