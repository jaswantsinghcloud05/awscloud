'use strict';

var config = require('../../config/environment');
var log = require('../../config/logger.js').log;

exports.handleLoginCallback = function (req, res) {
  //log.error("callback " + JSON.stringify(req));
  if(req.query.error){
    log.error(JSON.stringify(req.query.error));
    return res.send(403);
  }else if (req.originalUrl.indexOf("state=%2F")>-1) {
    var stateStart = req.originalUrl.indexOf("state=%2F") + 6;
    log.info("*******" + config.BASE_URL + decodeURIComponent(decodeURIComponent(req.originalUrl.substring(stateStart))));
    return res.send(`<!DOCTYPE html>
                      <html>
                          <head>
                              <title>Audition</title>
                              <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                              <script src="/bower_components/angular/angular.js"></script>
                              <script type="text/javascript">
                              function redirectClient() {
                                localStorage.setItem('audition-oktaAccessToken','`+ req.user.accessToken +`');
                                localStorage.setItem('audition-oktaRefreshToken','`+ req.user.refreshToken +`');
                                localStorage.setItem('audition-profile','`+ JSON.stringify({name: req.user.profile.name, userName: req.user.profile.preferred_username, type:"P"}) +`');
                                var now = new Date();
                                var time = now.getTime();
                                time += 600*24*60*60*1000;
                                now.setTime(time);
                                document.cookie = "UT=P; expires=" + now.toUTCString();//temporary cookie expires in 10 mins
                                window.location = "` + config.BASE_URL + decodeURIComponent(req.originalUrl.substring(stateStart)) + `";
                              }
                              window.onload = setTimeout(redirectClient, 2000);
                              </script>
                          </head>
                          <body>
                          </body>
                      </html>`);

    // at_hash: "xVe4Es-ylRgv_u2qHy56og"
    // aud: "0oackxqxf8KNID3Um0h7"
    // auth_time: 1510844028
    // exp: 1510856854
    // group: "playlist"
    // iat: 1510853254
    // idp: "00ocdz0enxugNJ1hi0h7"
    // iss: "https://dev-406218.oktapreview.com/oauth2/default"
    // jti: "ID.jGcV42Cee6LDtWMl8k-W0IMemWhsoLRmOK40HQenzoE"
    // name: "Oye Oye"
    // preferred_username: "oyedotun2002@yahoo.co.uk"
    // sub: "00ucdz0eqjzPbRFmz0h7"
    // umg_contact_email: "umeaudio@umusic.com"
    // userType: "P"
    // ver: 1
  }else if (req.originalUrl.indexOf("state=NA4")>0) {
    return res.send(`<!DOCTYPE html>
                      <html>
                          <head>
                              <title>Audition</title>
                              <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                              <script src="/bower_components/angular/angular.js"></script>
                              <script type="text/javascript">
                              function redirectClient() {
                                localStorage.setItem('audition-oktaAccessToken','`+ req.user.accessToken +`');
                                localStorage.setItem('audition-oktaRefreshToken','`+ req.user.refreshToken +`');
                                localStorage.setItem('audition-profile','`+ JSON.stringify({name: req.user.profile.name, userName: req.user.profile.preferred_username, type:"P"}) +`');
                                var now = new Date();
                                var time = now.getTime();
                                time += 600*24*60*60*1000;
                                now.setTime(time);
                                document.cookie = "UT=P; expires=" + now.toUTCString();//temporary cookie expires in 10 mins
                                window.location.href="` + config.BASE_URL + "/tracks-filters" + `";
                              }
                              window.onload = setTimeout(redirectClient, 2000);
                              </script>
                          </head>
                          <body>
                          </body>
                      </html>`);
  }else{
      return res.send(`<!DOCTYPE html>
                      <html>
                          <head>
                              <title>Audition</title>
                              <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                              <script src="/bower_components/angular/angular.js"></script>
                              <script type="text/javascript">
                              function callAngularAndClose() {
                                localStorage.setItem('audition-oktaAccessToken','`+ req.user.accessToken +`');
                                localStorage.setItem('audition-oktaRefreshToken','`+ req.user.refreshToken +`');
                                localStorage.setItem('audition-profile','`+ JSON.stringify({name: req.user.profile.name, userName: req.user.profile.preferred_username, type:"P"}) +`');
                                var now = new Date();
                                var time = now.getTime();
                                time += 600*24*60*60*1000;
                                now.setTime(time);
                                document.cookie = "UT=P; expires=" + now.toUTCString();//temporary cookie expires in 10 mins
                                window.opener.document.getElementsByClassName("full-dark-overlay")[0].style.display = "none";
                                self.close ();
                              }
                              window.onload = setTimeout(callAngularAndClose, 2000);
                              </script>
                          </head>
                          <body>
                          </body>
                      </html>`);

  }



  // }
};
