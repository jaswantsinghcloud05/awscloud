var util = require('util')
  , uid = require('uid')
  , log = require('../../config/logger.js').log
  , querystring= require('querystring')
  , OAuth2Strategy = require('passport-oauth').OAuth2Strategy
  , InternalOAuthError = require('passport-oauth').InternalOAuthError
  , url = require('url')
  , util = require('util')
  , utils = require('../utils')
  , AuthorizationError = require('../authorizationerror');


function Strategy(option, verify) {
  option = option || {};
  option.authorizationURL = option.audience + "/oauth2/default/v1/authorize";
  option.tokenURL = option.audience + "/oauth2/default/v1/token";
  option.userInfoUrl = option.audience + "/oauth2/default/v1/userinfo";
  option.state = true;

  OAuth2Strategy.call(this, option, verify);

  this.name = 'okta';
  this._userInfoUrl = option.userInfoUrl;
}

/**
 * Inherit from `OAuth2Strategy`.
 */
util.inherits(Strategy, OAuth2Strategy);


/**
 * Authenticate request by delegating to a service provider using OAuth 2.0.
 *
 * @param {Object} req
 * @api protected
 */
Strategy.prototype.authenticate = function(req, options) {
  options = options || {};

  var self = this;

  if (req.query && req.query.error) {
    if (req.query.error == 'access_denied') {
      return this.fail({ message: req.query.error_description });
    } else {
      return this.error(new AuthorizationError(req.query.error_description, req.query.error, req.query.error_uri));
    }
  }

  var callbackURL = options.callbackURL || this._callbackURL;
  if (callbackURL) {
    var parsed = url.parse(callbackURL);
    if (!parsed.protocol) {
      // The callback URL is relative, resolve a fully qualified URL from the
      // URL of the originating request.
      callbackURL = url.resolve(utils.originalURL(req, { proxy: this._trustProxy }), callbackURL);
    }
  }

  var meta = {
    authorizationURL: this._oauth2._authorizeUrl,
    tokenURL: this._oauth2._accessTokenUrl,
    clientID: this._oauth2._clientId
  }

  if (req.query && req.query.code) {
    function loaded(err, ok, state) {
      if (err) { return self.error(err); }
      if (!ok) {
        return self.fail(state, 403);
      }

      var code = req.query.code;

      var params = self.tokenParams(options);
      params.grant_type = 'authorization_code';
      if (callbackURL) { params.redirect_uri = callbackURL; }

      self._oauth2.getOAuthAccessToken(code, params,
        function(err, accessToken, refreshToken, params) {
          if (err) { return self.error(self._createOAuthError('Failed to obtain access token', err)); }
          log.debug("AC-TOKEN " + accessToken)
          log.debug("ID-TOKEN" + accessToken)

          self._loadUserProfile(accessToken, function(err, profile) {
            if (err) { return self.error(err); }

            function verified(err, user, info) {
              if (err) { return self.error(err); }
              if (!user) { return self.fail(info); }

              info = info || {};
              if (state) { info.state = state; }
              self.success(user, info);
            }

            try {
              if (self._passReqToCallback) {
                var arity = self._verify.length;
                if (arity == 6) {
                  self._verify(req, accessToken, refreshToken, params, profile, verified);
                } else { // arity == 5
                  self._verify(req, accessToken, refreshToken, profile, verified);
                }
              } else {
                log.debug("PARAMS" + JSON.stringify(params))
                var arity = self._verify.length;
                if (arity == 5) {
                  self._verify(accessToken, refreshToken, params, profile, verified);
                } else { // arity == 4
                  self._verify(accessToken, refreshToken, params, verified);
                }
              }
            } catch (ex) {
              return self.error(ex);
            }
          });
        }
      );
    }

    var state = req.query.state;
    loaded(null, true);
  } else {
    var params = this.authorizationParams(options);
    params.response_type = 'code';
    if (callbackURL) { params.redirect_uri = callbackURL; }
    var scope = options.scope || this._scope;
    if (scope) {
      if (Array.isArray(scope)) { scope = scope.join(this._scopeSeparator); }
      params.scope = scope;
    }

    var state = options.state;
    if (state) {
      params.state = state;
      var parsed = url.parse(this._oauth2._authorizeUrl, true);
      utils.merge(parsed.query, params);
      parsed.query['client_id'] = this._oauth2._clientId;
      delete parsed.search;
      var location = url.format(parsed);
      this.redirect(location);
    } else {
      function stored(err, state) {
        if (err) { return self.error(err); }

        if (state) { params.state = state; }
        var parsed = url.parse(self._oauth2._authorizeUrl, true);
        utils.merge(parsed.query, params);
        parsed.query['client_id'] = self._oauth2._clientId;
        delete parsed.search;
        var location = url.format(parsed);
        self.redirect(location);
      }

      if(req.originalUrl.indexOf("?action=")>-1){
        state = req.originalUrl.substr(req.originalUrl.indexOf("?action=") + 8)
      }else{
        state = "NA4" + uid(24);
      }
      stored(null, state);
    }
  }
};

/**
 * Retrieve user profile from Okta.
 * Further References at http://developer.okta.com/docs/api/resources/oidc.html#get-user-information
 *
 * This function constructs a normalized profile, with the following properties:
 *
 *   - `provider`         always set to `okta`
 *   - `id`
 *   - `username`
 *   - `displayName`
 *
 * @param {String} accessToken
 * @param {Function} done
 * @api protected
 */

Strategy.prototype.userProfile = function(accessToken, done) {
  var post_headers = { 'Authorization': 'Bearer ' + accessToken };

  this._oauth2._request('POST', this._userInfoUrl, post_headers, "", null, function(err, body, res){
    if (err) { return done(new InternalOAuthError('failed to fetch user profile', err)); }

    try {
      var json = JSON.parse(body);
      log.info("******USERINFO*****" + body);

      var profile = { provider: 'okta' };
      profile.id = json.sub;
      profile.displayName = json.name;
      profile.username = json.preferred_username;
      profile.name = {
        fullName: json.name,
        familyName: json.family_name,
        givenName: json.given_name
      };
      profile.emails = [{ value: json.email }];

      profile._raw = body;
      profile._json = json;

      done(null, profile);
    } catch(e) {
      done(e);
    }

  });
}

/**
 * Return extra Okta-specific parameters to be included in the authorization
 * request.
 *
 * @param {Object} option
 * @return {Object}
 * @api protected
 */
// Strategy.prototype.authorizationParams = function(option) {
//   var params = {};
//   if(this._idp) {
//     params["idp"] = this._idp;
//   }
//   return params;
// }

/**
 * Expose `Strategy`.
 */
module.exports = Strategy;
