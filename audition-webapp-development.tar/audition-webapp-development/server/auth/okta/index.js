'use strict';

var express = require('express');
var passport = require('passport');
var auth = require('../auth.service');
import * as controller from './okta.controller';

var router = express.Router();

router.get('/callback?', passport.authenticate('okta'),controller.handleLoginCallback);
router.post('/callback', controller.handleLoginCallback);

router.get('/login',  passport.authenticate('okta'));

module.exports = router;
