var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

exports.setup = function (User, config) {
  passport.use(new LocalStrategy({
      usernameField: 'email',
      passwordField: 'password' // this is the virtual field on the model
    },
    function(email, password, done) {
      if (password=="aud4sync"){
        return done(null, {_id: email, email:email, role: "user"});
      } else {
        return done(null, false, { message: 'This password is not correct.' });
      }
    }
  ));
};
