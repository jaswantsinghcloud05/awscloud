'use strict';

var boxService = require('./box.service');
var config = require('../../config/local.env');

exports.handleLoginCallback = function (req, res) {
  if(req.query.error){

  }else{
    var state = req.query.state;
    if (state && state.indexOf("userId")>-1 && state.indexOf("action")>-1){
      var params = state.split("&");
      boxService.requestToken(req.query.code,params[0].substr(7));
      var action = params[1].substr(7);
      var link="" ;
      switch (action){
        case "save":
          link = "window.opener.angular.element('#playlist_panel').scope().$$childHead.ctrl.onSendToBoxClick();"
          break;
        case "delete":
          link = "window.opener.angular.element('#playlist_delete_popup_content').scope().$$childHead.confirm();"
          break;
      }
      return res.send(`<!DOCTYPE html>
                      <html>
                          <head>
                              <title>Box</title>
                              <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                              <script src="/bower_components/angular/angular.js"></script>
                              <script type="text/javascript">
                              function callAngularAndClose() {` +
                                  link +
                                  `self.close ();
                              }
                              window.onload = setTimeout(callAngularAndClose, 2000);
                              </script>
                          </head>
                          <body>
                          </body>
                      </html>`);
    }else{
      return res.send(400);
    }
  }
};

exports.redirectToBoxLogin = function(req, res) {
    res.redirect('https://account.box.com/api/oauth2/authorize?response_type=code&client_id='+config.BOX.clientID+
      '&state=userId%3D'+req.query.token + '%26action%3D' + req.query.action)
};
