'use strict';

import * as express from 'express';
import * as controller from './box.controller';
import * as boxService from './box.service';
import * as config from '../../config/local.env';

var router = express.Router();

router.get('/?', controller.handleLoginCallback);
router.get('/login?', controller.redirectToBoxLogin);

module.exports = router;
