// Initialize SDK
var BoxSDK = require('box-node-sdk');
var TokenStore = require('./box.memory-token-store');
var config = require('../../config/local.env');

//GET https://account.box.com/api/oauth2/authorize?response_type=code&client_id=bh78thtvlv2ukinunwzpavkyig2g70i7&state=security_token%3DKnhMJatFipTAnM0nHlZA
//TODO this map will be stored in elasticsearch Users idx
var userBoxClients = new Map();

var sdk = new BoxSDK({
  clientID: config.BOX.clientID,
  clientSecret: config.BOX.clientSecret
});

export function getBoxClient(userToken){
  return userBoxClients.get(userToken)
}

export function requestToken(authCode, userToken) {
  sdk.getTokensAuthorizationCodeGrant(authCode, null, function(err, tokenInfo) {

    if (err) {
      if (err.statusCode==400){

      }else {
        userBoxClients.set(userToken, undefined);
      }
    }else {
      var tokenStore = new TokenStore(userToken);
      tokenStore.write(tokenInfo, function (storeErr) {
        if (storeErr) {
          // handle token write error
        }
        var client = sdk.getPersistentClient(tokenInfo, tokenStore);
        userBoxClients.set(userToken,client);
      });
    }
  });

}
