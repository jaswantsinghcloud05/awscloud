'use strict';

const express = require('express');
const fs = require('fs');
// var passport = require('passport');
var User = require('../api/user/user.model');

var router = express.Router();

router.use('/adfs', require('./adfs'));
router.use('/box', require('./box'));
router.use('/okta', require('./okta'));

module.exports = router;
