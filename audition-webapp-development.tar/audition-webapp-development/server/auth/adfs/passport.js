var passport = require('passport');
var ADFSOAuth2Strategy = require('./adfs-oauth2-strategy');
var refresh = require('passport-oauth2-refresh');
var jwt = require('jsonwebtoken');
var log = require('../../config/logger.js').log;

exports.setup = function (config) {
  var strategy = new ADFSOAuth2Strategy({
      authorizationURL: config.ADFS.AUTH_URL,
      tokenURL: config.ADFS.TOKEN_URL,
      clientID: config.ADFS.OAUTH2_CLIENTID,
      clientSecret: 'shhh-its-a-secret', // This is ignored but required by the OAuth2Strategy
      callbackURL: config.ADFS.CALLBACK_URL
    },
    function(accessToken, refreshToken, profile, done){
      var user = jwt.decode(profile);
      var profile = {userId: user.sub, groups: (!user.group || user.group.constructor == Array)?user.group : [user.group], userType: "E"};
      log.info(JSON.stringify(profile))
      done(null, {accessToken: accessToken, refreshToken:refreshToken, profile: profile});
    });

  strategy.authorizationParams = function(options) {
    return {
      resource: config.ADFS.OAUTH2_CLIENTID // An identifier corresponding to the RPT
    };
  };
  strategy.userProfile = function(accessToken, done) {
    done(null, accessToken);
  };
  passport.use('adfs', strategy);
  refresh.use('adfs',strategy);

  passport.serializeUser(function(user, done) {
    done(null, user);
  });
  passport.deserializeUser(function(user, done) {
    done(null, user);
  })


};
