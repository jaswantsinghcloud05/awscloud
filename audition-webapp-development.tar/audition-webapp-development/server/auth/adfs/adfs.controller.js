'use strict';

var boxService = require('./adfs.service');
var config = require('../../config/environment');
var log = require('../../config/logger.js').log;

exports.handleLoginCallback = function (req, res) {

  if(!req.query.error) {
    var queryIdx = req.originalUrl.indexOf("state=/");
    if (queryIdx>-1 || req.originalUrl.indexOf("state=NA")> -1) {
      var query = ""
      if(queryIdx>-1){
        query = decodeURIComponent(req.originalUrl.substring(queryIdx + 6))
      }
      return res.send(`<!DOCTYPE html>
                        <html>
                            <head>
                                <title>Audition</title>
                                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                <script src="/bower_components/angular/angular.js"></script>
                                <script type="text/javascript">
                                function redirectClient() {
                                  localStorage.setItem('audition-adfsAccessToken','` + req.user.accessToken + `');
                                  localStorage.setItem('audition-adfsRefreshToken','` + req.user.refreshToken + `');
                                  localStorage.setItem('audition-profile','` + JSON.stringify({userName:req.user.profile.userId, name:req.user.profile.userId,type:"E", groups:req.user.profile.groups}) + `');
                                  var now = new Date();
                                  var time = now.getTime();
                                  time += 600*24*60*60*1000;
                                  now.setTime(time);
                                  document.cookie = "UT=E; expires=" + now.toUTCString();//temporary cookie expires in 10 mins
                                  window.location.href="` + config.BASE_URL + query + `";
                                }
                                window.onload = setTimeout(redirectClient, 1000);
                                </script>
                            </head>
                            <body>
                            </body>
                        </html>`);
    } else {
      return res.send(`<!DOCTYPE html>
                      <html>
                          <head>
                              <title>Audition</title>
                              <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                              <script src="/bower_components/angular/angular.js"></script>
                              <script type="text/javascript">
                              function callAngularAndClose() {
                                localStorage.setItem('audition-adfsAccessToken','` + req.user.accessToken + `');
                                localStorage.setItem('audition-adfsRefreshToken','` + req.user.refreshToken + `');
                                localStorage.setItem('audition-profile','` + JSON.stringify({userName:req.user.profile.userId, name:req.user.profile.userId,type:"E", groups:req.user.profile.groups}) + `');
                                var now = new Date();
                                var time = now.getTime();
                                time += 600*24*60*60*1000;
                                now.setTime(time);
                                document.cookie = "UT=E; expires=" + now.toUTCString();//temporary cookie expires in 10 mins
                                window.opener.document.getElementsByClassName("full-dark-overlay")[0].style.display = "none";
                                self.close ();
                              }
                              window.onload = setTimeout(callAngularAndClose, 1000);
                              </script>
                          </head>
                          <body>
                          </body>
                      </html>`);

    }
  }else{
    return res.status(403);
  }
};
//   var state = req.query.state;
//   if (state && state.indexOf("userId")>-1 && state.indexOf("action")>-1){
//     var params = state.split("&");
//     boxService.requestToken(req.query.code,params[0].substr(7));
//     var action = params[1].substr(7);
//     var link="" ;
//     switch (action){
//       case "save":
//         link = "window.opener.angular.element('#playlist_panel').scope().$$childHead.ctrl.onSendToBoxClick();"
//         break;
//       case "delete":
//         link = "window.opener.angular.element('#playlist_delete_popup_content').scope().$$childHead.confirm();"
//         break;
//     }
//   var link = "window.opener.angular.element('#playlist_panel').scope().$$childHead.ctrl.onSendToBoxClick();"
