'use strict';

var express = require('express');
var passport = require('passport');
var auth = require('../auth.service');
import * as controller from './adfs.controller';

var router = express.Router();

router.get('/?', passport.authenticate('adfs'),controller.handleLoginCallback);

router.get('/login?',  passport.authenticate('adfs'));

module.exports = router;
