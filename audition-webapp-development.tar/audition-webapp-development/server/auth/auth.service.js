'use strict';

var passport = require('passport');
var config = require('../config/local.env');
var expressJwt = require('express-jwt');
var compose = require('composable-middleware');
var User = require('../api/user/user.model.es');
var fs = require('fs');
var validateInternal = expressJwt({ secret: fs.readFileSync(config.ADFS.UMG_KEY)});
var validateExternal = expressJwt({ secret: fs.readFileSync(config.OKTA.UMG_KEY)});
var refresh = require('passport-oauth2-refresh');
var log = require('../config/logger.js').log;


function tokenRefreshed(refreshError, accessToken, refreshToken, req, res, next, strategy) {
  if(refreshError){
    // if(refreshError.statusCode == 400 && refreshError.data.error == "invalid_grant"){
    //   res.status(401).("refresh token expired");
    // }else{
    log.error(refreshError, "*** ERROR REFRESHING TOKEN ***");
    res.status(401).send("Invalid Token");
    // }
  }else{
    if (accessToken){
      res.setHeader('adfsAccessToken',  accessToken + "");
      req.headers.authorization = 'Bearer ' + accessToken;
    }
    if (refreshToken) res.setHeader(`${strategy}RefreshToken`,  refreshToken + "");
    next();
  }
}

/**
 * Attaches the user object to the request if authenticated
 * Otherwise returns 403
 */
function isAuthenticated() {
  return compose()
    // Validate jwt
    .use(function(req, res, next) {
      if (req.header("adfsRefreshToken")){
        validateInternal(req, res, next);
      }else{
        validateExternal(req, res, next);
      }
    })
    .use(function (err, req, res, next) {
      //TODO temporary until token validation works
      if (err){
        if (err.message == "jwt expired") {
          if (req.header("adfsRefreshToken")) {
            refresh.requestNewAccessToken('adfs', req.header('adfsRefreshToken'),
              function (refreshError, accessToken, refreshToken){
                tokenRefreshed(refreshError, accessToken, refreshToken, req, res, next, "adfs");
              })
          }else {
            refresh.requestNewAccessToken('okta', req.header('oktaRefreshToken'),
              function (refreshError, accessToken, refreshToken){
                tokenRefreshed(refreshError, accessToken, refreshToken, req, res, next, "okta");
              })
          }
        }else if (err.message == "invalid signature"){
          //update signature file
          res.status(401).send("Invalid key signature: please contact support");
        }else{
          res.status(401).send("Invalid Token: " + err.message);
        }
      }else{
        next();
      }
    });
}

/**
 * Checks if the user role meets the minimum requirements of the route
 */
function hasRole(roleRequired) {
  if (!roleRequired) throw new Error('Required role needs to be set');

  return compose()
    .use(isAuthenticated())
    .use(function meetsRequirements(req, res, next) {
      if (req.user && (req.user.group &&
        (req.user.group.indexOf(roleRequired) > -1 || req.user.group.indexOf("admin") > -1)
        || req.user.aud === config.OKTA.OAUTH2_CLIENTID)) {
        next();
      }
      else {
        res.send(403);
      }
    });
}

exports.isAuthenticated = isAuthenticated;
exports.hasRole = hasRole;
