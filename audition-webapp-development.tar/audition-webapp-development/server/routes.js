/**
 * Main application routes
 */

'use strict';

import errors from './components/errors';
import path from 'path';
import errorHandler from 'errorhandler';
import auth from './auth/auth.service';

export default function(app, log) {

  // Insert routes below
  app.use('/api/users', auth.isAuthenticated(), require('./api/user'));
  app.use('/api/tracks', require('./api/track'));
  // app.use('/api/playlists', require('./api/playlist'));
  app.use('/api/playlists', auth.isAuthenticated(), require('./api/playlist'));
  app.use('/api/artists', auth.isAuthenticated(), require('./api/artist'));
  app.use('/api/albums', auth.isAuthenticated(), require('./api/album'));
  app.use('/api/admin', require('./api/admin'));


  app.use('/auth', require('./auth'));

  // All undefined asset or api routes should return a 404
  app.route('/:url(api|auth|components|app|bower_components|assets)/*')
    .get(errors[404]);

  app.route('/about_page.html')
    .get((req, res) => {
      res.sendFile(path.resolve(app.get('appPath') + '/about_page.html'));
    });

  app.route('/login')
    .get((req, res) => {
      res.sendFile(path.resolve(app.get('appPath') + '/external-login.html'));
    });

  // All other routes should redirect to the index.html
  app.route(['/','/*'])
    .get((req, res) => {
      if (req.cookies['UT'] === "E" || req.cookies['UT'] === "P"){
        res.sendFile(path.resolve(app.get('appPath') + '/index.html'));
      }else{
        if (req.originalUrl.indexOf("?") > -1) {
          var action = req.originalUrl.split("/", 3).join("/")
          res.redirect("/login?action=" + action);
        }else{
          res.redirect("/login");
        }
      }
    });

  var env = app.get('env');
  var log = require('./config/logger.js').log;
  if ('production' === env || 'test' === env) {
    app.use(function(err, req, res, next) {// Error handler - has to be last app.use
      log.error(err)
      next();
    });
  }
  if ('development' === env) {
    app.use(function(err, req, res, next) {// Error handler - has to be last app.use
      log.error(err)
      next(err);
    });
    app.use(errorHandler()); // Error handler - has to be last
  }

}
