/**
 * Main application file
 */

'use strict';

// Set default node environment to development
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
import * as config from './config/environment';
import * as localConf from './config/local.env';

// Setup server
var app = require('express')();
require('./config/logger')(app);
require('./config/express')(app);
require('./routes')(app);

// Start server
var http = require('http');
http.globalAgent.maxSockets = 100;
var server = http.createServer(app);
server.listen(config.port, config.ip, function () {
  console.log('Express server listening on %d, in %s mode', config.port, app.get('env'));
});

var https = require('https');
var fs = require('fs');
var httpsOps = {
 key: fs.readFileSync(localConf.HTTPS.key),
 cert: fs.readFileSync(localConf.HTTPS.cert),
  passphrase: localConf.HTTPS.passphrase,
};
var httpsServer = https.createServer(httpsOps, function(req, res){
  //temporary redirect
  res.writeHead(302, {
    'Location': config.BASE_URL
  });
  res.end();
})
httpsServer.listen(config.HTTPS_PORT, config.ip, function () {
 console.log('Express server listening on %d, in %s mode', config.HTTPS_PORT, app.get('env'));
});

// Expose app
exports = module.exports = app;
