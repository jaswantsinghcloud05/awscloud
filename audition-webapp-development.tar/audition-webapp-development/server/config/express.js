/**
 * Express configuration
 */

'use strict';

import express from 'express';
import favicon from 'serve-favicon';
import morgan from 'morgan';
import compression from 'compression';
import bodyParser from 'body-parser';
import methodOverride from 'method-override';
import cookieParser from 'cookie-parser';
import path from 'path';

//import lusca from 'lusca';
import config from './environment';
import localConf from './local.env';
import session from 'express-session';
import fileStreamRotator from 'file-stream-rotator';
import fs from 'fs';
import '../auth/adfs/passport.js';


export default function(app) {
  var env = app.get('env');
  app.set('views', config.root + '/server/views');
  app.engine('html', require('ejs').renderFile);
  app.set('view engine', 'html');
  app.use(compression());
  app.use(bodyParser.urlencoded({limit: '50mb', extended: false }));
  app.use(bodyParser.json({limit: '50mb'}));
  app.use(methodOverride());
  app.use(cookieParser());
  app.use(session({resave: 'true', saveUninitialized: 'true' , secret: 'palla'}));

  var passport = require('passport');
  app.use(passport.initialize());
  app.use(passport.session());
// Passport Configuration
  require('../auth/adfs/passport').setup(localConf);
  require('../auth/okta/passport').setup(localConf);
  app.use(function(req, res, next) {
    var allowedOrigins = ['http://dev-amplify.umusic.net', 'https://dev-amplify.umusic.net',
      'http://qa-amplify.umusic.net', 'https://qa-amplify.umusic.net',
      'http://uat-amplify.umusic.net', 'https://uat-amplify.umusic.net',
      'http://amplify.umusic.net','https://amplify.umusic.net',
      'http://local-amplify.umusic.net', 'https://local-amplify.umusic.net'];
    var origin = req.headers.origin;
    if(allowedOrigins.indexOf(origin) > -1){
      res.setHeader('Access-Control-Allow-Origin', origin);
      //res.header('Access-Control-Allow-Origin', 'http://127.0.0.1:8020');
      res.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      //res.header('Access-Control-Allow-Credentials', true);
    }
    return next();
  });

  // Persist sessions with mongoStore / sequelizeStore
  // We need to enable sessions for passport-twitter because it's an
  // oauth 1.0 strategy, and Lusca depends on sessions
  // app.use(session({
  //   secret: config.secrets.session,
  //   saveUninitialized: true,
  //   resave: false
  // }));

  /**
   * Lusca - express server security
   * https://github.com/krakenjs/lusca
   */
  // if ('test' !== env) {
  //   app.use(lusca({
  //     csrf: {
  //       angular: true
  //     },
  //     xframe: 'SAMEORIGIN',
  //     hsts: {
  //       maxAge: 31536000, //1 year, in seconds
  //       includeSubDomains: true,
  //       preload: true
  //     },
  //     xssProtection: true
  //   }));
  //   app.use(function (err, req, res, next) {//TODO Error handler - has to be last app.use
  //     /* We log the error internaly */
  //     log.error(err);
  //     /*
  //      * Remove Error's `stack` property. We don't want
  //      * users to see this at the production env
  //      */
  //     delete err.stack;
  //     next(err);
  //   });
  //
  //}

  app.set('appPath', path.join(config.root, 'client'));

  if ('production' === env || 'test' === env) {
    app.use(favicon(path.join(config.root, 'client', 'favicon.ico')));
    app.use(express.static(app.get('appPath')));
    // ensure log directory exists
    fs.existsSync(config.LOG_DIR) || fs.mkdirSync(config.LOG_DIR)
    // create a rotating write stream
    //TODO only daily available with filestreamrotator
    var accessLogStream = fileStreamRotator.getStream({
      date_format: 'YYYYMMDD',
      filename: path.join(config.LOG_DIR, 'access-%DATE%.log'),
      frequency: 'daily',
      verbose: false
    })
    // setup the logger
    app.use(morgan('combined', {
      stream: accessLogStream,
      skip: function (req, res) { return res.statusCode < 400 }
    }))
  }

  if ('development' === env) {
    app.use(require('connect-livereload')());
    app.use(express.static(path.join(config.root, '.tmp')));
    app.use(express.static(app.get('appPath')));
    app.use(morgan('dev'));
  }
}
