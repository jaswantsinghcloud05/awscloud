'use strict';

// Development specific configuration
// ==================================
module.exports = {
  es: {
    uri: '10.254.36.109:9200',
    TRACKS_IDX: "tracks-dev-idx",
    ARTISTS_IDX: "artists-dev-idx",
    ALBUMS_IDX: "albums-dev-idx",
    PLAYLISTS_IDX: "playlists-dev-idx",
    LOG_LEVEL: "debug"
  },

  LOG_DIR:"/Users/manfucd/development/aud-webapp/",
  LOG_LEVEL: "debug",
  UPLOAD_DIR: "./uploads/",
  BASE_URL: "http://localhost:9000",
  AWS_CONFIG:"/Users/manfucd/development/aud-webapp/server/config/aws-keys.json"

};
