'use strict';

// Test specific configuration
// ===========================
module.exports = {
  // MongoDB connection options
  ip:       process.env.OPENSHIFT_NODEJS_IP ||
  process.env.IP ||
  undefined,

  // Server port
  port:     process.env.OPENSHIFT_NODEJS_PORT ||
  process.env.PORT ||
  8080,
  // Server https port
  HTTPS_PORT:8443,

  // elasticsearch
  es: {
    uri: '10.254.36.109:9200',
    TRACKS_IDX: "tracks-dev-idx",
    ARTISTS_IDX: "artists-dev-idx",
    ALBUMS_IDX: "albums-dev-idx",
    PLAYLISTS_IDX: "playlists-dev-idx",
    LOG_LEVEL: "info"
  },
  UPLOAD_DIR: "/data/umg-audition/uploads/",
  LOG_DIR:"/data/umg-audition/logs/",
  LOG_LEVEL: "debug",
  BASE_URL: "https://dev-audition.umusic.net/",
  AWS_CONFIG:"/data/umg-audition/certs/aws-keys.json"

};
