'use strict';

var path = require('path');
var _ = require('lodash');

function requiredProcessEnv(name) {
  if(!process.env[name]) {
    throw new Error('You must set the ' + name + ' environment variable');
  }
  return process.env[name];
}

// All configurations will extend these options
// ============================================
var all = {
  env: process.env.NODE_ENV,

  // Root path of server
  root: path.normalize(__dirname + '/../../..'),

  // Server port
  port: process.env.PORT || 9000,
  // Server https port
  HTTPS_PORT:8443,

  // Secret for session, you will want to change this and make it an environment variable
  secrets: {
    session: 'ml5Sl6F2ugAa0zR6gLHSJNU3yoE7M83sLM_CNJAeVQmbMUJ8lSBHchB9h1npErwBLnBDm3-TZkmccgDqEX010rVg257okodRn8JoA_WW1Ykx4VY7JOog1x9dhdQVSrmRKvQhRzgAI9Bx2t42K8DSWTGDGiOwugPMPSPRgWfmW0Vw89WsckvjzEs0w7OFRLU3-k-C2EIzZvpdUP-S5MB-fYljNajzPx1N1a818idDwv2tdkOa5l1DDfXobTzwgO2BS6c26R4THid8WLBAgqouhQiajKy0AS3btpIn4ylMXqwTkoCbhWFRtwXkTEulfTUi4GW64e4DClXB2Aml-1c94w'
  },

  // List of user roles
  userRoles: ['general', 'playlist', 'admin'],
  partnerLabels: [
    { "term": { "label_name.keyword": "ABKCO" } },{ "term": { "label_name.keyword": "Abkco Music & Records, Inc. [US]" } }, { "term": { "label_name.keyword": "ABKCO Music & Records, Inc." } },
    { "term": { "label_name.keyword": "Atlantic" } },
    { "term": { "label_name.keyword": "Concord" } }, { "term": { "label_name.keyword": "Concord Records" } },{ "term": { "label_name.keyword": "Concord Records, Inc. [US]" } },{ "term": { "label_name.keyword": "Concord Records, Inc." } },{ "term": { "label_name.keyword": "Concord Jazz" } },
    { "term": { "label_name.keyword": "Deep Heads" } },
    { "term": { "label_name.keyword": "Disney" } }, { "term": { "label_name.keyword": "Walt Disney Records" } },{ "term": { "label_name.keyword": "Walt Disney Records [CA]" } },{ "term": { "label_name.keyword": "Hollywood Records" } },{ "term": { "label_name.keyword": "Hollywood Records Inc. [US]" } },
    { "term": { "label_name.keyword": "Elektra" } },
    { "term": { "label_name.keyword": "Fantasy" } }, { "term": { "label_name.keyword": "Fantasy Records" } },{ "term": { "label_name.keyword": "Prestige" } },{ "term": { "label_name.keyword": "Stax" } },
    { "term": { "label_name.keyword": "Jive" } },
    { "term": { "label_name.keyword": "Mammoth Records" } }, { "term": { "label_name.keyword": "Mammoth" } },{ "term": { "label_name.keyword": "Mammoth (UMG Account) [US]" } },
    { "term": { "label_name.keyword": "Montreux Sounds" } },
    { "term": { "label_name.keyword": "RCA" } },
    { "term": { "label_name.keyword": "Reprise" } }, { "term": { "label_name.keyword": "FRANK SINATRA DIGITAL REPRISE" } },
    { "term": { "label_name.keyword": "Rhino" } },
    { "term": { "label_name.keyword": "Rounder" } }, { "term": { "label_name.keyword": "Rounder Records [US]" } },{ "term": { "label_name.keyword": "Rounder Records" } },{ "term": { "label_name.keyword": "New Rounder" } },{ "term": { "label_name.keyword": "New Rounder [US]" } },
    { "term": { "label_name.keyword": "Rykodisk" } },
    { "term": { "label_name.keyword": "Sanctuary" } }, { "term": { "label_name.keyword": "Sanctuary Records" } }, { "term": { "label_name.keyword": "Sanctuary Records [US]" } }, { "term": { "label_name.keyword": "Sanctuary Records Group Ltd. [GB]" } },{ "term": { "label_name.keyword": "Trojan" } },{ "term": { "label_name.keyword": "Trojan Budget" } },{ "term": { "label_name.keyword": "Castle" } },
    { "term": { "label_name.keyword": "SLG" } }, { "term": { "label_name.keyword": "SLG, LLC" } },{ "term": { "label_name.keyword": "SLG, LLC [CA]" } },
    { "term": { "label_name.keyword": "Sony BMG Music Entertainment" } },
    { "term": { "label_name.keyword": "Sony Music Entertainment" } },
    { "term": { "label_name.keyword": "Stax" } },
    { "term": { "label_name.keyword": "United Audio Entertainment" } },
    { "term": { "label_name.keyword": "Vagrant Records" } }, { "term": { "label_name.keyword": "Vagrant Records DC" } },
    { "term": { "label_name.keyword": "Valory Music" } },
    { "term": { "label_name.keyword": "Varese Sarabande" } },
    { "term": { "label_name.keyword": "Warner Bros. Records" } },
    { "term": { "label_name.keyword": "WEA International" } },
    { "term": { "label_name.keyword": "Zomba" } },
    { "term": { "division_name.keyword": "ABKCO" } },{ "term": { "division_name.keyword": "Abkco Music & Records, Inc. [US]" } }, { "term": { "division_name.keyword": "ABKCO Music and Records, Inc." } },
    { "term": { "division_name.keyword": "Atlantic" } },
    { "term": { "division_name.keyword": "Concord" } }, { "term": { "division_name.keyword": "Concord Records" } },{ "term": { "division_name.keyword": "Concord Records, Inc. [US]" } },{ "term": { "division_name.keyword": "Concord Records, Inc." } },{ "term": { "division_name.keyword": "Concord Jazz" } },
    { "term": { "division_name.keyword": "Deep Heads" } },
    { "term": { "division_name.keyword": "Disney" } }, { "term": { "division_name.keyword": "Walt Disney Records" } },{ "term": { "division_name.keyword": "Walt Disney Records [CA]" } },{ "term": { "division_name.keyword": "Hollywood Records" } },{ "term": { "division_name.keyword": "Hollywood Records Inc. [US]" } },
    { "term": { "division_name.keyword": "Elektra" } },
    { "term": { "division_name.keyword": "Fantasy" } }, { "term": { "division_name.keyword": "Fantasy Records" } },{ "term": { "division_name.keyword": "Prestige" } },{ "term": { "division_name.keyword": "Stax" } },
    { "term": { "division_name.keyword": "Jive" } },
    { "term": { "division_name.keyword": "Mammoth Records" } }, { "term": { "division_name.keyword": "Mammoth" } },{ "term": { "division_name.keyword": "Mammoth (UMG Account) [US]" } },
    { "term": { "division_name.keyword": "Montreux Sounds" } },
    { "term": { "division_name.keyword": "RCA" } },
    { "term": { "division_name.keyword": "Reprise" } }, { "term": { "division_name.keyword": "FRANK SINATRA DIGITAL REPRISE" } },
    { "term": { "division_name.keyword": "Rhino" } },
    { "term": { "division_name.keyword": "Rounder" } }, { "term": { "division_name.keyword": "Rounder Records [US]" } },{ "term": { "division_name.keyword": "Rounder Records" } },{ "term": { "division_name.keyword": "New Rounder" } },{ "term": { "division_name.keyword": "New Rounder [US]" } },
    { "term": { "division_name.keyword": "Rykodisk" } },
    { "term": { "division_name.keyword": "Sanctuary" } }, { "term": { "division_name.keyword": "Sanctuary Records" } }, { "term": { "division_name.keyword": "Sanctuary Records [US]" } }, { "term": { "division_name.keyword": "Sanctuary Records Group Ltd. [GB]" } },{ "term": { "division_name.keyword": "Trojan" } },{ "term": { "division_name.keyword": "Trojan Budget" } },{ "term": { "division_name.keyword": "Castle" } },
    { "term": { "division_name.keyword": "SLG" } }, { "term": { "division_name.keyword": "SLG, LLC" } },{ "term": { "division_name.keyword": "SLG, LLC [CA]" } },
    { "term": { "division_name.keyword": "Sony BMG Music Entertainment" } },
    { "term": { "division_name.keyword": "Sony Music Entertainment" } },
    { "term": { "division_name.keyword": "Stax" } },
    { "term": { "division_name.keyword": "United Audio Entertainment" } },
    { "term": { "division_name.keyword": "Vagrant Records" } }, { "term": { "division_name.keyword": "Vagrant Records DC" } },
    { "term": { "division_name.keyword": "Valory Music" } },
    { "term": { "division_name.keyword": "Varese Sarabande" } },
    { "term": { "division_name.keyword": "Warner Bros. Records" } },
    { "term": { "division_name.keyword": "WEA International" } },
    { "term": { "division_name.keyword": "Zomba" } },
    { "term": { "company_name.keyword": "ABKCO" } },{ "term": { "company_name.keyword": "Abkco Music & Records, Inc. [US]" } }, { "term": { "company_name.keyword": "ABKCO Music and Records, Inc." } },
    { "term": { "company_name.keyword": "Atlantic" } },
    { "term": { "company_name.keyword": "Concord" } }, { "term": { "company_name.keyword": "Concord Records" } },{ "term": { "company_name.keyword": "Concord Records, Inc. [US]" } },{ "term": { "company_name.keyword": "Concord Records, Inc." } },{ "term": { "company_name.keyword": "Concord Jazz" } },
    { "term": { "company_name.keyword": "Deep Heads" } },
    { "term": { "company_name.keyword": "Disney" } }, { "term": { "company_name.keyword": "Walt Disney Records" } },{ "term": { "company_name.keyword": "Walt Disney Records [CA]" } },{ "term": { "company_name.keyword": "Hollywood Records" } },{ "term": { "company_name.keyword": "Hollywood Records Inc. [US]" } },
    { "term": { "company_name.keyword": "Elektra" } },
    { "term": { "company_name.keyword": "Fantasy" } }, { "term": { "company_name.keyword": "Fantasy Records" } },{ "term": { "company_name.keyword": "Prestige" } },{ "term": { "company_name.keyword": "Stax" } },
    { "term": { "company_name.keyword": "Jive" } },
    { "term": { "company_name.keyword": "Mammoth Records" } }, { "term": { "company_name.keyword": "Mammoth" } },{ "term": { "company_name.keyword": "Mammoth (UMG Account) [US]" } },
    { "term": { "company_name.keyword": "Montreux Sounds" } },
    { "term": { "company_name.keyword": "RCA" } },
    { "term": { "company_name.keyword": "Reprise" } }, { "term": { "company_name.keyword": "FRANK SINATRA DIGITAL REPRISE" } },
    { "term": { "company_name.keyword": "Rhino" } },
    { "term": { "company_name.keyword": "Rounder" } }, { "term": { "company_name.keyword": "Rounder Records [US]" } },{ "term": { "company_name.keyword": "Rounder Records" } },{ "term": { "company_name.keyword": "New Rounder" } },{ "term": { "company_name.keyword": "New Rounder [US]" } },
    { "term": { "company_name.keyword": "Rykodisk" } },
    { "term": { "company_name.keyword": "Sanctuary" } }, { "term": { "company_name.keyword": "Sanctuary Records" } }, { "term": { "company_name.keyword": "Sanctuary Records [US]" } }, { "term": { "company_name.keyword": "Sanctuary Records Group Ltd. [GB]" } },{ "term": { "company_name.keyword": "Trojan" } },{ "term": { "company_name.keyword": "Trojan Budget" } },{ "term": { "company_name.keyword": "Castle" } },
    { "term": { "company_name.keyword": "SLG" } }, { "term": { "company_name.keyword": "SLG, LLC" } },{ "term": { "company_name.keyword": "SLG, LLC [CA]" } },
    { "term": { "company_name.keyword": "Sony BMG Music Entertainment" } },
    { "term": { "company_name.keyword": "Sony Music Entertainment" } },
    { "term": { "company_name.keyword": "Stax" } },
    { "term": { "company_name.keyword": "United Audio Entertainment" } },
    { "term": { "company_name.keyword": "Vagrant Records" } }, { "term": { "company_name.keyword": "Vagrant Records DC" } },
    { "term": { "company_name.keyword": "Valory Music" } },
    { "term": { "company_name.keyword": "Varese Sarabande" } },
    { "term": { "company_name.keyword": "Warner Bros. Records" } },
    { "term": { "company_name.keyword": "WEA International" } },
    { "term": { "company_name.keyword": "Zomba" } }
  ],
  buildNumber: "N/A",
};

// Export the config object based on the NODE_ENV
// ==============================================
module.exports = _.merge(
  all,
  require('./' + process.env.NODE_ENV + '.js') || {});
