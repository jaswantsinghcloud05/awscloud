'use strict';

// Production specific configuration
// =================================
module.exports = {
  // Server IP
  ip:       process.env.OPENSHIFT_NODEJS_IP ||
            process.env.IP ||
            undefined,

  // Server port
  port:     process.env.OPENSHIFT_NODEJS_PORT ||
            process.env.PORT ||
            8080,
  // Server https port
  HTTPS_PORT:8443,

  // elasticsearch
  es: {
    uri: '10.254.36.113:9200',
    TRACKS_IDX: "tracks-uat-idx",
    ARTISTS_IDX: "artists-uat-idx",
    ALBUMS_IDX: "albums-uat-idx",
    PLAYLISTS_IDX: "playlists-uat-idx",
    LOG_LEVEL: "error"
  },
  UPLOAD_DIR: "/data/umg-audition/uploads/",
  LOG_DIR:"/data/umg-audition/logs/",
  LOG_LEVEL: "info",
  BASE_URL: "https://audition.umusic.com/",
  AWS_CONFIG:"/data/umg-audition/certs/aws-keys.json",


};
