'use strict';

exports = module.exports = {
  // List of user roles
  userRoles: ['general', 'playlist', 'admin']
};
