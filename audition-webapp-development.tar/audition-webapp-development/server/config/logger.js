'use strict';

import * as config from './environment';
import * as bunyan from 'bunyan';

export default function(app) {
  var obj = {};

  if( !obj.log ){
    obj.log = bunyan.createLogger({
      name: 'file+cloudwatch',
      streams: [{
        type: 'rotating-file',
        path: config.LOG_DIR + 'audition.log',
        level: config.LOG_LEVEL,
        period: '1m',   // daily rotation
        count: 3        // keep 3 back copies
      }
      ]
    });
  }

  /*with cloudwatch enabled
   var env = app.get('env');
   var stream = require('bunyan-cloudwatch')({
   logGroupName: 'my-group',
   logStreamName: 'my-stream',
   cloudWatchLogsOptions: {
   region: 'us-west-1'
   }
   });
   var log = bunyan.createLogger({
   name: 'file+cloudwatch',
   streams: [{
   type: 'rotating-file',
   path: config.LOG_DIR + 'audition.log',
   period: '1m',   // daily rotation
   count: 3        // keep 3 back copies
   },
   {
   stream: stream,
   type: 'raw'
   }
   ]
   });
   */

  module.exports = obj;
}
