"use strict";

 angular.module('config', [])

.constant('REST_BASE_URL', 'http://localhost:9000')
   .constant('AMPLIFY_URL', 'https://qa-amplify.umusic.net')
   .constant('INTERNAL_API_URL', 'https://api-dev-audition.umusic.net:9443')
// .constant('ES_URL', 'http://10.254.36.111:9200');
