class TracksManager {

  constructor($rootScope, trackService, messagingService, $location,$state,$timeout) {
    this.rootScope = $rootScope;
    this.trackService = trackService;
    this.messagingService = messagingService;
    this.tracks = [];
    this.metrics = {};
    this.totalTracksNum = 0;
    this.location = $location;
    this.state = $state;
    this.timeout = $timeout;
  }

  padWithZeroes(number, length) {

    while (number && number.length < length) {
      number = '0' + number;
    }
    return number;
  }

  set selectedTrack(track){
    if(track) {
      this.rootScope.selectedTrack = track;
      track.largeThumbnailUrl = "/api/tracks/" + track.r2_resource_id + "/assets/thumbnail-large";
      track.pips = this.padWithZeroes(track.pips,6)
      track.selected = true;
    }
  }

  get selectedTrack(){
    return this.rootScope.selectedTrack;
  }

  loadSelectedTrack(r2_resource_id){
    this.trackService.findByIsrc(r2_resource_id)
      .then((data) =>{
        this.selectedTrack = data.data.hits.hits[0]._source;
      })
  }

  set currentTracks(trackList){
    this.tracks = trackList;
  }

  get currentTracks(){
    return this.tracks;
  }

  get totalTracks(){
    return this.totalTracksNum;
  }

  set totalTracks(total){
    this.totalTracksNum = total;
  }

  get currentMetrics(){
    return this.metrics;
  }

  set currentMetrics(metrics){
    this.metrics = metrics;
  }

  updateTracks(skip){
    var promise = this.trackService.performSearch(skip)
    promise.success((data, code) => {
      if (code==204){
        this.tracks = [];
        this.totalTracksNum = 0;
      }else {
        if (data.searchId === this.trackService.searchCriteria.id) {
          this.tracks.length = 0;
          this.tracks.push(...data.result.hits.hits);
          this.totalTracksNum = data.result.hits.total;
        }
      }
    })
    return promise;
  }

  applyNewFilters(){
    var promise = this.updateTracks(0)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListUpdated);//TODO use RxJs observer pattern
    });
    this.trackService.getSearchMetrics().success((data, code) => {
      if (code == 204) {
        this.metrics = {};
        this.trackService.resetMetrics();
        this.totalTracksNum = 0;
      }else {
        if (data.searchId === this.trackService.searchCriteria.id) {
          //TODO review these loops
          this.metrics = data.result.aggregations;
          this.totalTracksNum = data.result.hits.total;
        }
      }
    }).finally((data) => {
      this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  getTracks(){
    var promise = this.updateTracks(0)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  getMetrics(){
    var promise = this.trackService.getSearchMetrics().success((data, code) => {
      if (code == 204) {
        this.metrics = {};
        this.trackService.resetMetrics();
        this.totalTracksNum = 0;
      }else {
        if (data.searchId === this.trackService.searchCriteria.id) {
          //TODO review these loops
          this.metrics = data.result.aggregations;
          this.totalTracksNum = data.result.hits.total;
        }
      }
    }).finally((data) => {
      this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  refreshTracks(skip){
    var promise = this.updateTracks(skip)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListRefreshed);//TODO use RxJs observer pattern
    });
    return promise;
  }

}

angular.module('auditionApp').service('tracksManager', TracksManager);
