angular.module('auditionApp').factory('playlistService', function(
  $http, $log, REST_BASE_URL, AMPLIFY_URL, INTERNAL_API_URL, $q, $timeout, $location, usersManager) {

  var playlistService = {};

  var createSearchPostPayload = function(filters){
    //TODO review this method
    var payload = angular.copy(filters);
    for (var property in payload.filters) {
      //remove UI attributes
      if (payload.filters.hasOwnProperty(property)) {
        payload.filters[property].forEach(function(item){
          delete item.label;
          delete item.count;
        })
      }
    }
    payload.sorting = payload.columnSorting.concat(payload.filterSorting)
    delete payload.columnSorting;
    delete payload.filterSorting;

    return payload;
  }

  playlistService.updatePlaylist = function(playlist) {
    if (playlist._id){
      var url = REST_BASE_URL + "/api/playlists/" + playlist._id + "?ver=" + playlist._version;
      return $http.put(url, playlist._source)
    }else{
      var url = REST_BASE_URL + "/api/playlists";
      return $http.post(url, playlist._source)
    }
  }

  playlistService.deletePlaylist = function(playlist,deleteFromBox) {
    var url = REST_BASE_URL + "/api/playlists/" + playlist._id + "?removeFiles=" + deleteFromBox
    return $http.delete(url);
  }

  playlistService.getPlaylist = function(id) {
    var url = REST_BASE_URL + "/api/playlists/" + id;
    return $http.get(url);
  }

  playlistService.searchByName = function(name) {
    var url = REST_BASE_URL + "/api/playlists?name=" + name;
    return $http.get(url);
  }

  playlistService.searchByNamePrivate = function(name) {
    var url = REST_BASE_URL + "/api/playlists?name=" + name + "&owner=1";
    return $http.get(url);
  }

  playlistService.saveToBox = function(playlist, statusListener) {

    var url = REST_BASE_URL + "/api/playlists/" + playlist._id + "/box";
    var promise = $http.post(url);
    promise.then((res)=>{
      var poller = function() {
        $http.get(REST_BASE_URL + "/api/playlists/" + playlist._id + "/box/status").then(function(response) {
          statusListener.data = response.data.result;
          if(response.data.result.status < 400 && response.data.result.status != 201){
            $timeout(poller, 2000);
          }
        });
      };
      if (res.status == 200){
        if (res.data.result && res.data.result.sharedLink){
          playlist._source.box_public_url = res.data.result.sharedLink;
        }
        poller()
      };
    })
    return promise;
  }

  playlistService.searchByTracks = function(filters, skip){
    var url = REST_BASE_URL + "/api/playlists/filter?skip=" + skip;

    return $http.post(url, createSearchPostPayload(filters));
  }

  playlistService.getTracksMetrics = function(filters){
    var url = REST_BASE_URL + "/api/playlists/metrics/filter";
    return $http.post(url, createSearchPostPayload(filters));
  }

  playlistService.sendPlaylistEmail = function(playlist) {
    var url = REST_BASE_URL + "/api/playlists/" + playlist._id + "/email"
    return $http.post(url);
  }

  playlistService.sendPlaylistToAmplify = function(playlist) {
    function uuidv4() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }
    var url =  AMPLIFY_URL + "/api/recordingsessions";
    var amplifyTracks = [];
    playlist._source.tracks.forEach((item) => {
      amplifyTracks.push(
        {
          "isrc": item.isrc,
          "artist": item.artist_name,
          "title": item.formatted_title,
          "audioUrl": INTERNAL_API_URL + "/api/tracks/" + item.r2_resource_id + "/audio/full-stream",
          "imageUrl": INTERNAL_API_URL + "/api/tracks/" + item.r2_resource_id + "/assets/thumbnail-large",
          "otherIdentifiers": {
            "upc": item.upc
          },
          "year": item.pc_notice_year
        })
    })
    var payload = {
      "recordingSessionId": uuidv4 = uuidv4(),
      "sourceName": "Audition",
      "sourceUrl": $location.absUrl(),
      "recordings": amplifyTracks,
      "timestamp": new Date().toISOString()
    }
    return $http.put(url, payload);
  }


  //
  // playlistService.addTrack = function(playlistId, track) {
  //   var url = REST_BASE_URL + "/api/playlists/" + playlistId + "/tracks";
  //   return $http.post(url, track)
  // }
  //
  // playlistService.filter = function(filter) {
  //   var url = REST_BASE_URL + "/api/playlists/filter";
  //   return $http.post(url,filter);
  // }
  //
  // playlistService.findByTrackFilter = function(filter) {
  //   var url = REST_BASE_URL + "/api/playlists/tracks/filter";
  //   return $http.post(url);
  // }

  // playlistService.addTrackList = function(playlistNames, playlistTracks) {
  //   var httpCalls = [];
  //   for(var i = 0; i<playlistNames.length; i++){
  //     var url = REST_BASE_URL + "/api/playlists/" + playlistNames[i] + "/tracks";
  //     httpCalls.push($http.post(url, playlistTracks));
  //   }
  //   return $q.all(httpCalls);
  // }
  //
  // playlistService.moveTrackList = function(currentPlaylist, playlistNames, playlistTracks) {
  //   var httpCalls = [];
  //   for(var i = 0; i<playlistNames.length; i++){
  //     var url = REST_BASE_URL + "/api/playlists/" + playlistNames[i] + "/tracks";
  //     httpCalls.push($http.post(url, playlistTracks));
  //   }
  //   httpCalls.push(playlistService.removeTrackList(currentPlaylist, playlistTracks));
  //   return $q.all(httpCalls);
  // }
  //
  // playlistService.removeTrackList = function(playlistName, playlistTracks) {
  //     var url = REST_BASE_URL + "/api/playlists/" + playlistName + "/tracks/delete-request";
  //     return $http.post(url, playlistTracks);
  // }
  //
  // playlistService.copyPlaylist = function(from, to) {
  //   var url = REST_BASE_URL + "/api/playlists/" + from + "/copy-request";
  //   return $http.post(url, {copyTo: to});
  // }


  return playlistService;
});
