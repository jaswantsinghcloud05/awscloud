angular.module('auditionApp').factory('albumService', function(
  $http, $log, REST_BASE_URL, $q, $timeout, usersManager) {

  var albumService = {};

  albumService.getAlbum = function(id) {
    var url = REST_BASE_URL + "/api/albums/" + id;
    return $http.get(url);
  }

  albumService.searchByAlbumName = function(val) {
    var url = REST_BASE_URL + "/api/albums?title=" + val;
    return $http.get(url);
  }

  albumService.findByRollupId = function(val) {
    var url = REST_BASE_URL + "/api/albums?release_rollup_id=" + val;
    return $http.get(url);
  }

  albumService.findByCanopusId = function(val) {
    var url = REST_BASE_URL + "/api/albums?canopus_id=" + val;
    return $http.get(url);
  }

  return albumService;
});
