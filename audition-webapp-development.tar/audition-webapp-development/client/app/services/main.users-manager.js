class UsersManager {

  constructor($rootScope, $locale) {
    this.rootScope = $rootScope;
  }

  set user(user) {
    this.currentUser = user;
  }

  get user() {
    if (!this.currentUser){
      var profile = localStorage.getItem('audition-profile');
      if (profile) this.currentUser = JSON.parse(localStorage.getItem('audition-profile'));
    }
    return this.currentUser;
  }

  get userType() {
    return this.user.type
  }

  isInGroup(group) {
    var found = false;
    for (var i=0; this.user.groups && i<this.user.groups.length; i++){
      if (this.user.groups[i]===group){
        return true
      }
    }
    return found;
  }

}

UsersManager.employee = "E";
UsersManager.client = "C";
UsersManager.amplifyUser = "amplifyuser";

angular.module('auditionApp').service('usersManager', UsersManager);
