angular.module('auditionApp').factory('artistService', function($http, $log, REST_BASE_URL, $q, $sce) {

  var artistService = {};
  var WIKI_EXTRACT_BASE_URL = 'https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=&explaintext=&format=json&callback=JSON_CALLBACK&titles=';
  var WIKI_REVISIONS_BASE_URL = 'https://en.wikipedia.org/w/api.php?action=query&prop=revisions&rvprop=content&rvsection=0&rnlimit=1&format=json&callback=JSON_CALLBACK&redirects=1&titles=';//&titles=No%20Doubt
  //TODO if we care about the api_key we should move it to the server and proxy the call from it
  var LASTFM_BASE_URL = 'https://ws.audioscrobbler.com/2.0/?method=artist.getInfo&api_key=a086f3a6616b6ac2ee86fa25ca90faf3&format=json&callback=JSON_CALLBACK&limit=5&mbid=';

  artistService.getArtistByCanopusId = function(canopusId){
    var url = REST_BASE_URL + "/api/artists/" + canopusId;
    return $http.get(url);
  }

  artistService.getEnhacedArtistByCanopusId = function(canopusId){

    var def = $q.defer();

    artistService.getArtistByCanopusId(canopusId)
      .then(function(result) {
        var artist = result.data.result;
        artist.wiki = "Loading"
        var wikiPromise = artistService.getWikiExtract(artist);
        if (wikiPromise != null) {
          wikiPromise.then((data) => {
              artist.wiki = data.data;
          },(error) => {
            artist.wiki = 'Unable to load wikipedia preview';
          });
        }else{
          artist.wiki = 'Artist description not available';
        }
        //TODO extract in function
        artist.imageUrl = "Loading";
        artistService.getLastFmPicture(artist);
        def.resolve(artist);
      },function(data) {
        def.reject(data);
      });

    var httpPromise = def.promise;
    return httpPromise;
  }

  artistService.getWikiExtract = function(artist){
    var promise = null;
    for (var i=0; i < artist.profiles.length; i++){
      if ("wikipedia" == artist.profiles[i].url_type){
        var pageId = artist.profiles[i].url.substring(artist.profiles[i].url.lastIndexOf('/')+1,artist.profiles[i].url.length);
        var url = REST_BASE_URL + "/api/artists/" + artist.canopus_id + "/wiki/" + pageId;
        promise = $http.get(url);
      }
    }
    return promise;
  }
  //TODO not used at the moment because extracting genres from the wiki revision
  //is a pain and prolly not worth it
  artistService.getWikiRevision0 = function(artist){
    var promise = $http({
      url: WIKI_REVISIONS_BASE_URL + encodeURIComponent(artist.default_name),
      method: 'jsonp'
    });
    return promise;
  }

  artistService.getLastFmPicture = function(artist){
    var promise = $http({
      url: LASTFM_BASE_URL + encodeURIComponent(artist.musicbrainz_id),
      method: 'jsonp'
    });
    promise.then(function(result) {
      if (result.data.artist) {
        result.data.artist.image.forEach(function (item) {
          if ("extralarge" == item.size) {
            artist.imageUrl = item['#text'];
          }
        });
      }
    });
    return promise;
  }

  artistService.searchByAlias = function(val) {
    var url = REST_BASE_URL + "/api/artists?alias=" + val;
    return $http.get(url);
  }


  return artistService;
});

