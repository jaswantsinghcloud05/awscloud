class UrlStatusManager {

  constructor($rootScope, $location, trackService, messagingService) {
    this.rootScope = $rootScope;
    this.location = $location;
    this.urlStatus = {tab:"tracks",filters :trackService.searchCriteria}
    this.messagingService = messagingService;
    this.trackService = trackService;
  }

  set status(status) {
    this.urlStatus.tab = status.tab;
    this.urlStatus.selectedTrack = status.selectedTrack;
    this.urlStatus.selectedAlbum = status.selectedAlbum;
    angular.copy(status.filters,this.trackService.searchCriteria);//TODO check if necessary
    this.messagingService.broadcast(MessagingService.urlChanged);//TODO use RxJs
  }

  get status() {
    return this.urlStatus;
  }

  updateUrl(url){
    if (url){
      this.location.url(url)
    }
    this.location.search("query",this.encodeParams(this.urlStatus));
  }

  encodeParams(){
    var encoded = this.urlStatus.tab;
    encoded += "§"+ (this.urlStatus.selectedTrack?this.urlStatus.selectedTrack:"");
    encoded += "§"+ (this.urlStatus.filters.query?this.urlStatus.filters.query:"");
    encoded += "§"+ (this.urlStatus.filters.boolean?this.urlStatus.filters.boolean:"");
    encoded += "§"+ (this.urlStatus.filters.match.canopus_id?this.urlStatus.filters.match.canopus_id:"");
    encoded += "§"+ (this.urlStatus.filters.match.r2_resource_id?this.urlStatus.filters.match.r2_resource_id:"");
    encoded += "§"+ (this.urlStatus.filters.match.playlistName?this.urlStatus.filters.match.playlistName:"");
    encoded += "§"+ (this.urlStatus.filters.match.publishing_rights_country?this.urlStatus.filters.match.publishing_rights_country:"");
    encoded += "§"+ (this.urlStatus.filters.match.resource_rollup_id?this.urlStatus.filters.match.resource_rollup_id:"");
    encoded += "§"+ this.urlStatus.filters.search.labels.join("~");
    encoded += "§"+ this.urlStatus.filters.search.countries.join("~");
    encoded += "§"+ this.urlStatus.filters.search.umgGenres.join("~");
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.genres);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.intensities);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.emotions);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.instrumentations);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.ensemble_timbres);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.ensemble_types);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.arrangements);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.tempos);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.rights);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.publishing);
    encoded += "§"+ this.encodeFilter(this.urlStatus.filters.filters.vocalGenders);
    encoded += "§"+ (this.urlStatus.filters.excludeLiveTracks?"1":"");
    encoded += "§"+ this.urlStatus.filters.ranges.bpm.min;
    encoded += "§"+ this.urlStatus.filters.ranges.bpm.max;
    encoded += "§"+ this.urlStatus.filters.ranges.minUMPGShares.min;
    encoded += "§"+ (this.urlStatus.filters.match.upc?this.urlStatus.filters.match.upc:"");
    // encoded += "§"+ this.urlStatus.filters.columnSorting.join("~");
    // encoded += "§"+ this.urlStatus.filters.filterSorting.join("~");
    return encoded;
  }

  updateStatusFromUrl(url){
    var params = url.split("§")
    this.urlStatus.tab = params[0];
    this.urlStatus.selectedTrack = params[1];
    this.urlStatus.filters.query = params[2];
    this.urlStatus.filters.boolean = params[3];
    this.urlStatus.filters.match.canopus_id = params[4];
    this.urlStatus.filters.match.r2_resource_id = params[5];
    this.urlStatus.filters.match.playlistName = params[6]
    this.urlStatus.filters.match.publishing_rights_country = params[7]
    this.urlStatus.filters.match.resource_rollup_id = params[8]
    if (params[9] != "") this.decodeArray(params[9].split("~"), this.urlStatus.filters.search.labels);
    if (params[10] != "") this.decodeArray(params[10].split("~"), this.urlStatus.filters.search.countries);
    if (params[11] != "") this.decodeArray(params[11].split("~"), this.urlStatus.filters.search.umgGenres);
    if (params[12] != "") this.decodeFilter(params[12].split("~"), this.urlStatus.filters.filters.genres);
    if (params[13] != "") this.decodeFilter(params[13].split("~"), this.urlStatus.filters.filters.intensities);
    if (params[14] != "") this.decodeFilter(params[14].split("~"), this.urlStatus.filters.filters.emotions);
    if (params[15] != "") this.decodeFilter(params[15].split("~"), this.urlStatus.filters.filters.instrumentations);
    if (params[16] != "") this.decodeFilter(params[16].split("~"), this.urlStatus.filters.filters.ensemble_timbres);
    if (params[17] != "") this.decodeFilter(params[17].split("~"), this.urlStatus.filters.filters.ensemble_types);
    if (params[18] != "") this.decodeFilter(params[18].split("~"), this.urlStatus.filters.filters.arrangements);
    if (params[19] != "") this.decodeFilter(params[19].split("~"), this.urlStatus.filters.filters.tempos);
    if (params[20] != "") this.decodeFilter(params[20].split("~"), this.urlStatus.filters.filters.rights);
    if (params[21] != "") this.decodeFilter(params[21].split("~"), this.urlStatus.filters.filters.publishing);
    if (params[22] != "") this.decodeFilter(params[22].split("~"), this.urlStatus.filters.filters.vocalGenders);
    this.urlStatus.filters.excludeLiveTracks = params[23];
    this.urlStatus.filters.ranges.bpm.min = parseInt(params[24]) || 0;
    this.urlStatus.filters.ranges.bpm.max = parseInt(params[25]) || 0;
    this.urlStatus.filters.ranges.minUMPGShares.min = parseInt(params[26]) || 0;
    this.urlStatus.filters.match.upc = params[27];
    // this.urlStatus.filters.columnSorting = (params[25]!="")?params[25].split("~"):[];
    // this.urlStatus.filters.filterSorting = params[26].split("~");

    this.messagingService.broadcast(MessagingService.urlChanged);//TODO use RxJs
  }

  encodeFilter(filterArray){
    var encoded = "";
    filterArray.forEach((item) => {
      encoded += (item.value?item.value:"") + "~"
    })
    return encoded.slice(0, -1);
  }

  decodeFilter(filterArray, filter){
    for (var i= 0; i<filter.length; i++){
      filter[i].value = filterArray[i];
    }
  }

  decodeArray(filterArray, filter){
    filter.length = 0;
    filterArray.forEach((item) => {
      filter.push(item);
    })
  }


}
angular.module('auditionApp').service('urlStatusManager', UrlStatusManager);
