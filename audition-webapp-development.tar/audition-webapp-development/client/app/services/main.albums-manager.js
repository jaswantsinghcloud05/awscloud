class AlbumsManager {

  constructor($rootScope, tracksManager, trackService, albumService, messagingService) {
    this.rootScope = $rootScope;
    this.albumService = albumService;
    this.messagingService = messagingService;
    this.albums = [];
    this.totalAlbumsNum = 0;
    this.currentAlbum = {};
    this.tracksManager = tracksManager;
  }

  loadSelectedAlbum(upc){
    this.albumService.getAlbum(upc)
      .then((result) => {
        this.currentAlbum = result.data.result;
        if (this.currentAlbum.thumbnail_large_filename) {
          this.currentAlbum.thumbnail_large_filename = "/api/albums/" + this.currentAlbum + "/stream?file=" + encodeURIComponent(this.selectedAlbum.thumbnail_large_filename.substring(19));
        }else{
          this.currentAlbum.thumbnail_large_filename = "not available"
        }
        this.messagingService.broadcast(MessagingService.albumUpdated);//TODO use RxJs observer pattern
      });
  }

  set selectedAlbum(album){
    this.currentAlbum = album;
    //this.rootScope.$broadcast(MessagingService.searchSelected);//TODO use RxJs

  }
  get selectedAlbum(){
    return this.currentAlbum;
  }

  loadAlternativeVersions(upc){
    if(this.currentAlbum && this.currentAlbum.upc == upc) {
      this.albumService.findByRollupId(this.currentAlbum.release_rollup_id)
        .then((result) => {
          this.albums.length = 0;
          this.albums.push(...result.data.hits.hits);
          this.messagingService.broadcast(MessagingService.albumsListUpdated);//TODO use RxJs observer pattern
      })
    }else{
      this.albumService.getAlbum(upc)
        .then((result) => {
          var album = result.data.result;
          this.albumService.findByRollupId(album.release_rollup_id)
          .then((result) => {
            this.albums.length = 0;
            this.albums.push(...result.data.hits.hits);
            this.messagingService.broadcast(MessagingService.albumsListUpdated);//TODO use RxJs observer pattern
          })
        });
    }
  }

  loadArtistAlbums(canopus_id){
    var promise = this.albumService.findByCanopusId(canopus_id);
    promise.then((result) => {
      this.albums.length = 0;
      this.albums.push(...result.data.hits.hits);
      this.messagingService.broadcast(MessagingService.albumsListUpdated);//TODO use RxJs observer pattern
    })
  }

  applyNewTracksFilters(filters){
    var promise = this.updatePlaylists(filters, 0)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListUpdated);//TODO use RxJs observer pattern
    });
    this.albumService.getTracksMetrics(filters).success((data, code) => {
      if (code == 204) {
        this.tracksManager.metrics = {};
        this.tracksManager.totalTracksNum = 0;
      }else {
        if (data.searchId === filters.id) {
          //TODO review these loops
          this.tracksManager.metrics = data.result.aggregations.tracks;
          this.tracksManager.totalTracksNum = data.result.hits.total;
        }
      }
    }).finally((data) => {
      this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  updatePlaylists(filters, skip){
    var promise = this.albumService.searchByTracks(filters,skip);
    promise.then((result) => {
      if (result.status==204) {
        this.albums = [];
        this.totalAlbumsNum = 0;
      }else{
        if (result.data.searchId === filters.id) {
            this.albums.length = 0;
            this.albums.push(...result.data.result.hits.hits);
            this.totalAlbumsNum = result.data.result.hits.total;
          }
        }
    });
    return promise;
  }

  set currentAlbums(albums){
    this.albums = albums;
  }

  get currentAlbums(){
    return this.albums;
  }

  get totalAlbums(){
    return this.totalAlbumsNum;
  }

  set totalAlbums(total){
    this.totalAlbumsNum = total;
  }
  //
  //
  //
  //
  //
  // set selectedAlbum(album){
  //   if(album) {
  //     this.currentAlbum = album;
  //     this.messagingService.broadcast(MessagingService.albumSelected);//TODO use RxJs observer pattern
  //   }
  // }
  //
  // get selectedAlbum(){
  //   return this.currentAlbum;
  // }
  //
  // addTrackToCurrentAlbum(track){
  //   if (!this.currentAlbum._source.tracks) this.currentAlbum._source.tracks = [];
  //   this.currentAlbum._source.tracks.push(track);
  //   return this.albumService.updateAlbum(this.currentAlbum)
  //     .then((data) =>{
  //       this.selectedAlbum = data.data.result.hits.hits[0];
  //       this.messagingService.broadcast(MessagingService.albumSelected);//TODO maybe us a specific message for update
  //     },(error) =>{
  //       this.currentAlbum._source.tracks.pop();
  //       if(error.status == "409"){
  //         this.albumService.getAlbum(this.currentAlbum._id)
  //           .then((data) => {
  //             this.selectedAlbum = data.data.result.hits.hits[0];
  //             this.addTrackToCurrentAlbum(track);
  //           },(error) => {
  //             //TODO
  //         });
  //       }
  //     });
  // }
  //
  // updateCurrentAlbum(){
  //   return this.updateAlbum(this.currentAlbum);
  // }
  //
  // updateAlbum(album){
  //   return this.albumService.updateAlbum(album)
  //     .then((data) =>{
  //       this.selectedAlbum = data.data.result.hits.hits[0];
  //       this.messagingService.broadcast(MessagingService.albumSelected);//TODO maybe us a specific message for update
  //     },(error) =>{
  //       if(error.status == "409"){
  //         this.albumService.getAlbum(this.currentAlbum._id)
  //           .then((data) => {
  //             this.selectedAlbum = data.data.result.hits.hits[0];
  //             this.updateCurrentAlbum();
  //           },(error) => {
  //             //TODO
  //           });
  //       }
  //     });
  // }
  //
  // set selectedTrack(track){
  //   if(track) {
  //     this.rootScope.selectedTrack = track;
  //   }
  // }
  //
  // get selectedTrack(){
  //   return this.rootScope.selectedTrack;
  // }
  //
  // createAlbumTextEmail() {
  //   if (this.currentAlbum){
  //     var content = String.fromCharCode(13) + String.fromCharCode(13) + "The album " + this.currentAlbum._source.name + " is available at " + this.currentAlbum._source.box_public_url
  //     content += String.fromCharCode(13) + "List of tracks" + String.fromCharCode(13) + String.fromCharCode(13);
  //     for (var i=0; i<this.currentAlbum._source.tracks.length;i++){
  //       var item = this.currentAlbum._source.tracks[i];
  //       content += (i+1) + ". " + item.formatted_title + " by " + item.artist_name + String.fromCharCode(13);
  //     }
  //     return content;
  //   }
  // }
  //
  // applyNewTracksFilters(filters){
  //   var promise = this.updateAlbums(filters, 0)
  //   promise.finally((data) => {
  //     this.messagingService.broadcast(MessagingService.trackListUpdated);//TODO use RxJs observer pattern
  //   });
  //   this.albumService.getTracksMetrics(filters).success((data) => {
  //     if (data.searchId === filters.id) {
  //       //TODO review these loops
  //       this.tracksManager.metrics = data.result.aggregations.tracks;
  //       this.tracksManager.totalTracksNum = data.result.hits.total;
  //     }
  //   }).error((data, status, headers, config)=>{
  //     if (status == 403 || status == 401) {
  //       this.tracksManager.metrics = {};
  //       this.tracksManager.totalTracksNum = 0;
  //     }else{
  //       console.error(config);
  //     }
  //   }).finally((data) => {
  //     this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
  //   });
  //   this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
  //   return promise;
  // }
  //
  // updateAlbums(filters, skip){
  //   var promise = this.albumService.searchByTracks(filters,skip);
  //   promise.success((data) => {
  //     if (data.searchId === filters.id) {
  //       this.albums.length = 0;
  //       this.albums.push(...data.result.hits.hits);
  //       this.totalAlbumsNum = data.result.hits.total;
  //     }
  //   }).error((data, status, headers, config) => {
  //     if (status==403 || status == 401){
  //       this.albums = [];
  //       this.totalAlbumsNum = 0;
  //     }else{
  //       //TODO show some sort of message
  //     }
  //   });
  //   return promise;
  // }
  //
  // getTracksMetrics(filters){
  //   var promise = this.albumService.getTracksMetrics(filters).success((data) => {
  //     if (data.searchId === filters.id) {
  //       //TODO review these loops
  //       this.tracksManager.metrics = data.result.aggregations;
  //       this.tracksManager.totalTracks = data.result.hits.total;
  //     }
  //   }).error((data, status, headers, config)=>{
  //     if (status == 403 || status == 401) {
  //       this.tracksManager.metrics = {};
  //       this.tracksManager.totalTracksNum = 0;
  //     }else{
  //       console.error(config);
  //     }
  //   }).finally((data) => {
  //     this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
  //   });
  //   this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
  //   return promise;
  // }
  //
  // refreshAlbums(filters, skip){
  //   var promise = this.updateAlbums(filters, skip)
  //   promise.finally((data) => {
  //     this.messagingService.broadcast(MessagingService.trackListRefreshed);//TODO use RxJs observer pattern
  //   });
  //   return promise;
  // }



}

angular.module('auditionApp').service('albumsManager', AlbumsManager);
