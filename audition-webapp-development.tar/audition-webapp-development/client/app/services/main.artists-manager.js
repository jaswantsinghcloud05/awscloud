class ArtistsManager {

  constructor($rootScope, messagingService, artistService) {
    this.rootScope = $rootScope;
    this.currentArtist;
    this.artistService = artistService;
  }

  loadSelectedArtist(canopusId){
    this.artistService.getEnhacedArtistByCanopusId(canopusId)
      .then((artist) => {
        this.currentArtist = artist;
      });
  }

  set selectedArtist(artist){
    this.currentArtist = artist;
    this.rootScope.$broadcast(MessagingService.searchSelected);//TODO use RxJs

  }
  get selectedArtist(){
    return this.currentArtist;
  }

}

angular.module('auditionApp').service('artistsManager', ArtistsManager);
