angular.module('auditionApp').factory('trackService', function($http, $log, $location, REST_BASE_URL, AMPLIFY_URL, INTERNAL_API_URL) {

  var trackService = {};
  var skip = 0;
  var lastRecodingId;

  trackService.searchCriteria = {
    query: undefined,
    boolean: false,
    match: {
      canopus_id: undefined,
      r2_resource_id: undefined,
      playlistName: undefined,
      publishing_rights_country: undefined,
      resource_rollup_id: undefined
    },
    search:{
      labels:[],
      countries:[],
      umgGenres: []
    },
    filters: {
      genres: [
        {label: "Electronic", id: "genre_electronic", value: "", count: 0},
        {label: "RnB", id: "genre_rnb", value: "", count: 0},
        {label: "Jazz", id: "genre_jazz", value: "", count: 0},
        {label: "Pop/Rock", id: "genre_pop_rock", value: "", count: 0},
        {label: "Latin", id: "genre_latin", value: "", count: 0},
        {label: "HipHop", id: "genre_hiphop", value: "", count: 0},
        {label: "Metal/Punk", id: "genre_metal", value: "", count: 0},
        {label: "Blues", id: "genre_blues", value: "", count: 0},
        {label: "Reggae", id: "genre_reggae", value: "", count: 0},
        {label: "Classical", id: "genre_classical", value: "", count: 0},
        {label: "Alternative Pop", id: "genre_alternative_pop", value: "", count: 0},
        {label: "Alternative Rock", id: "genre_alternative_rock", value: "", count: 0},
        {label: "Brazilian", id: "genre_brazilian", value: "", count: 0},
        {label: "Classic Pop", id: "genre_classic_pop", value: "", count: 0},
        {label: "Classic Rock", id: "genre_classic_rock", value: "", count: 0},
        {label: "Country", id: "genre_country", value: "", count: 0},
        {label: "Dance", id: "genre_dance", value: "", count: 0},
        {label: "Folk", id: "genre_folk", value: "", count: 0},
        {label: "Gospel", id: "genre_gospel", value: "", count: 0},
        {label: "Modern Pop", id: "genre_modern_pop", value: "", count: 0},
        {label: "Spoken", id: "genre_spoken", value: "", count: 0}
      ],
      intensities: [
        {label: "Calm", id: "intensity_calm", value: "", count: 0},
        {label: "Driving", id: "intensity_driving", value: "", count: 0},
        {label: "Groovy", id: "intensity_groovy", value: "", count: 0},
        {label: "Laidback", id: "intensity_laidback", value: "", count: 0},
        {label: "Powerful", id: "intensity_powerful", value: "", count: 0}
      ],
      emotions: [
        {label: "Aggressive", id: "emotion_aggressive", value: "", count: 0},
        {label: "Easy Going", id: "emotion_easy_going", value: "", count: 0},
        {label: "Happy", id: "emotion_happy", value: "", count: 0},
        {label: "Romantic", id: "emotion_romantic", value: "", count: 0},
        {label: "Sad", id: "emotion_sad", value: "", count: 0},
        {label: "Sentimental", id: "emotion_sentimental", value: "", count: 0},
        {label: "Suspenseful", id: "emotion_suspenseful", value: "", count: 0},
        {label: "Uplifting", id: "emotion_uplifting", value: "", count: 0}
      ],
      instrumentations: [
        {label: "Drum Set", id: "instrumentation_drumset", value: "", count: 0},
        {label: "Drum Machine", id: "instrumentation_electronic_drumkit", value: "", count: 0},
        {label: "Acoustic Guitar", id: "instrumentation_acoustic_guitar", value: "", count: 0},
        {label: "Electric Guitar", id: "instrumentation_electric_guitar", value: "", count: 0},
        {label: "Acoustic", id: "instrumentation_acoustic", value: "", count: 0},
        {label: "Orchestra/Strings", id: "instrumentation_strings_orchestra", value: "", count: 0},
        {label: "Brass", id: "instrumentation_brass", value: "", count: 0},
        {label: "Electronic", id: "instrumentation_electronic", value: "", count: 0},
        {label: "Acoustic Piano", id: "instrumentation_piano", value: "", count: 0},
      ],
      ensemble_timbres: [
        {label: "Acoustic", id: "ensemble_timbre_acoustic", value: "", count: 0},
        {label: "Electric", id: "ensemble_timbre_electric", value: "", count: 0},
        {label: "Electronic", id: "ensemble_timbre_electronic", value: "", count: 0}
      ],
      ensemble_types: [
        {label: "Electronic", id: "ensemble_type_electronic", value: "", count: 0},
        {label: "Folk Band", id: "ensemble_type_folk_band", value: "", count: 0},
        {label: "Large Jazz Band", id: "ensemble_type_large_jazz_band", value: "", count: 0},
        {label: "Orchestra", id: "ensemble_type_orchestra", value: "", count: 0},
        {label: "Pop Band", id: "ensemble_type_pop_band", value: "", count: 0},
        {label: "Rock Band", id: "ensemble_type_rock_band", value: "", count: 0},
        {label: "Small", id: "ensemble_type_small", value: "", count: 0},
        {label: "Small Jazz Band", id: "ensemble_type_small_jazz_band", value: "", count: 0},
        {label: "Solo", id: "ensemble_type_solo", value: "", count: 0},
        {label: "Voice Accompaniment", id: "ensemble_type_voice_accompaniment", value: "", count: 0}
      ],
      arrangements: [
        {label: "A Capella", id: "arrangement_a_capella", value: "", count:0},
        {label: "Instrumental", id: "arrangement_instrumental", value: "", count:0},
        {label: "Voice Music", id: "arrangement_voice_music", value: "", count:0}
      ],
      tempos: [
        {label: "slow", id: "tempo_slow", value: "", count:0},
        {label: "medium", id: "tempo_medium", value: "", count:0},
        {label: "fast", id: "tempo_fast", value: "", count:0}
      ],
      rights:[
        {label: "Sync", id: "sync", value: "N", count:0},
        {label: "Streaming", id: "streaming_restrict", value: "N", count:0},
        {label: "Download", id: "download_restrict", value: "N", count:0},
        {label: "Compilation", id: "comps", value: "N", count:0},
        {label: "Lost Rights", id: "lost_rights", value: "N", count:0},
        {label: "Exclude Union Orchestra", id: "unionized", value: "N", count:0},
      ],
      publishing:[
        {id: "uspub_publ_domain", value: "N", count:0}
      ],
      vocalGenders:[
        {id: "vocal_register_male", value: "", count:0},
        {id: "vocal_register_female", value: "", count:0}
      ]
    },
    excludeLiveTracks: false, //TODO change grouping, create an object called creativemetadata and put creative filters in it
    ranges: {
      decades: {min: 1900, max: new Date().getFullYear(), floor: 1900, ceil: new Date().getFullYear()},//TODO this is dangerous maybe it should be fixed to 2015
      bpm: {min: 0, max: 250, floor: 0, ceil: 250},
      popularity: {min: 0, max: 90, floor: 0, ceil: 90},
      minUMPGShares: {min: 0, max: 100, floor: 0, ceil: 100}
    },
    columnSorting:[],
    filterSorting:[],
    pageSize: 50
  };

  trackService.ISO3CountryCodes = {"BD": "BGD", "BE": "BEL", "BF": "BFA", "BG": "BGR", "BA": "BIH", "BB": "BRB", "WF": "WLF", "BL": "BLM", "BM": "BMU", "BN": "BRN", "BO": "BOL", "BH": "BHR", "BI": "BDI", "BJ": "BEN", "BT": "BTN", "JM": "JAM", "BV": "BVT", "BW": "BWA", "WS": "WSM", "BQ": "BES", "BR": "BRA", "BS": "BHS", "JE": "JEY", "BY": "BLR", "BZ": "BLZ", "RU": "RUS", "RW": "RWA", "RS": "SRB", "TL": "TLS", "RE": "REU", "TM": "TKM", "TJ": "TJK", "RO": "ROU", "TK": "TKL", "GW": "GNB", "GU": "GUM", "GT": "GTM", "GS": "SGS", "GR": "GRC", "GQ": "GNQ", "GP": "GLP", "JP": "JPN", "GY": "GUY", "GG": "GGY", "GF": "GUF", "GE": "GEO", "GD": "GRD", "GB": "GBR", "GA": "GAB", "SV": "SLV", "GN": "GIN", "GM": "GMB", "GL": "GRL", "GI": "GIB", "GH": "GHA", "OM": "OMN", "TN": "TUN", "JO": "JOR", "HR": "HRV", "HT": "HTI", "HU": "HUN", "HK": "HKG", "HN": "HND", "HM": "HMD", "VE": "VEN", "PR": "PRI", "PS": "PSE", "PW": "PLW", "PT": "PRT", "SJ": "SJM", "PY": "PRY", "IQ": "IRQ", "PA": "PAN", "PF": "PYF", "PG": "PNG", "PE": "PER", "PK": "PAK", "PH": "PHL", "PN": "PCN", "PL": "POL", "PM": "SPM", "ZM": "ZMB", "EH": "ESH", "EE": "EST", "EG": "EGY", "ZA": "ZAF", "EC": "ECU", "IT": "ITA", "VN": "VNM", "SB": "SLB", "ET": "ETH", "SO": "SOM", "ZW": "ZWE", "SA": "SAU", "ES": "ESP", "ER": "ERI", "ME": "MNE", "MD": "MDA", "MG": "MDG", "MF": "MAF", "MA": "MAR", "MC": "MCO", "UZ": "UZB", "MM": "MMR", "ML": "MLI", "MO": "MAC", "MN": "MNG", "MH": "MHL", "MK": "MKD", "MU": "MUS", "MT": "MLT", "MW": "MWI", "MV": "MDV", "MQ": "MTQ", "MP": "MNP", "MS": "MSR", "MR": "MRT", "IM": "IMN", "UG": "UGA", "TZ": "TZA", "MY": "MYS", "MX": "MEX", "IL": "ISR", "FR": "FRA", "IO": "IOT", "SH": "SHN", "FI": "FIN", "FJ": "FJI", "FK": "FLK", "FM": "FSM", "FO": "FRO", "NI": "NIC", "NL": "NLD", "NO": "NOR", "NA": "NAM", "VU": "VUT", "NC": "NCL", "NE": "NER", "NF": "NFK", "NG": "NGA", "NZ": "NZL", "NP": "NPL", "NR": "NRU", "NU": "NIU", "CK": "COK", "XK": "XKX", "CI": "CIV", "CH": "CHE", "CO": "COL", "CN": "CHN", "CM": "CMR", "CL": "CHL", "CC": "CCK", "CA": "CAN", "CG": "COG", "CF": "CAF", "CD": "COD", "CZ": "CZE", "CY": "CYP", "CX": "CXR", "CR": "CRI", "CW": "CUW", "CV": "CPV", "CU": "CUB", "SZ": "SWZ", "SY": "SYR", "SX": "SXM", "KG": "KGZ", "KE": "KEN", "SS": "SSD", "SR": "SUR", "KI": "KIR", "KH": "KHM", "KN": "KNA", "KM": "COM", "ST": "STP", "SK": "SVK", "KR": "KOR", "SI": "SVN", "KP": "PRK", "KW": "KWT", "SN": "SEN", "SM": "SMR", "SL": "SLE", "SC": "SYC", "KZ": "KAZ", "KY": "CYM", "SG": "SGP", "SE": "SWE", "SD": "SDN", "DO": "DOM", "DM": "DMA", "DJ": "DJI", "DK": "DNK", "VG": "VGB", "DE": "DEU", "YE": "YEM", "DZ": "DZA", "US": "USA", "UY": "URY", "YT": "MYT", "UM": "UMI", "LB": "LBN", "LC": "LCA", "LA": "LAO", "TV": "TUV", "TW": "TWN", "TT": "TTO", "TR": "TUR", "LK": "LKA", "LI": "LIE", "LV": "LVA", "TO": "TON", "LT": "LTU", "LU": "LUX", "LR": "LBR", "LS": "LSO", "TH": "THA", "TF": "ATF", "TG": "TGO", "TD": "TCD", "TC": "TCA", "LY": "LBY", "VA": "VAT", "VC": "VCT", "AE": "ARE", "AD": "AND", "AG": "ATG", "AF": "AFG", "AI": "AIA", "VI": "VIR", "IS": "ISL", "IR": "IRN", "AM": "ARM", "AL": "ALB", "AO": "AGO", "AQ": "ATA", "AS": "ASM", "AR": "ARG", "AU": "AUS", "AT": "AUT", "AW": "ABW", "IN": "IND", "AX": "ALA", "AZ": "AZE", "IE": "IRL", "ID": "IDN", "UA": "UKR", "QA": "QAT", "MZ": "MOZ"}

  trackService.performSearch = function(skip){
    if (skip){
      return search(skip);
    }else{
      return search(0);
    }
  }

  trackService.getSearchMetrics = function(){
    var url = REST_BASE_URL + "/api/tracks/metrics/filter";
    return $http.post(url, createSearchPostPayload(trackService.searchCriteria));
  }

  trackService.findByIsrc = function(r2_resource_id){
    //TODO set use regular find with canopusid in search criteria
    var url = REST_BASE_URL + "/api/tracks/" + r2_resource_id;
    return $http.get(url);
  }

  trackService.resetMetrics = function(){
    for (var property in trackService.searchCriteria.filters) {
      var filter = trackService.searchCriteria.filters[property];
      if (Array.isArray(filter)){
        filter.forEach(function (item) {
          item.count=0;
        });
      }
    }
  }

  trackService.resetFilters = function(){
    var searchCriteria = trackService.searchCriteria;
    var filters = trackService.searchCriteria.filters;
    var ranges = trackService.searchCriteria.ranges;
    for (var property in filters) {
      var filter = filters[property];
      if (Array.isArray(filter)){
        filter.forEach(function (item) {
          item.value="";
          item.count=0;
        });
      }
    }
    ranges.decades.min= 1900
    ranges.decades.max= new Date().getFullYear();
    ranges.bpm.min= 0;
    ranges.bpm.max=250;
    ranges.popularity.min= 0;
    ranges.minUMPGShares.min= 0;
    searchCriteria.match.canopus_id = undefined;
    searchCriteria.match.r2_resource_id = undefined;
    searchCriteria.match.playlistName = undefined;
    searchCriteria.match.resource_rollup_id = undefined;
    searchCriteria.query = undefined,
    searchCriteria.columnSorting = [];
    searchCriteria.filterSorting = [];
    searchCriteria.excludeLiveTracks = false;
  }

  trackService.searchByTrackName = function(val) {
    var url = REST_BASE_URL + "/api/tracks?title=" + val;
    return $http.get(url);
  }

  var createSearchPostPayload = function(filters){
    //TODO review this method
    var payload = angular.copy(filters);
    var filterActivated = false;
    for (var property in payload.filters) {
      //remove UI attributes
      if (payload.filters.hasOwnProperty(property)) {
        payload.filters[property].forEach(function(item){
          if (item.value === "Y"){
            filterActivated = true;
          }
          delete item.label;
          delete item.count;
        })
      }
    }
    payload.sorting = payload.columnSorting.concat(payload.filterSorting)
    delete payload.columnSorting;
    delete payload.filterSorting;
    if (filterActivated){}
    return payload;
  }

  var search = function(skip){
    var url = REST_BASE_URL + "/api/tracks/filter?skip=" + skip;

    return $http.post(url, createSearchPostPayload(trackService.searchCriteria));
  }

  trackService.getSuggestionsByQuery = function(val) {
    var url = REST_BASE_URL + "/api/tracks/suggestions/filter";
    var payload = createSearchPostPayload(trackService.searchCriteria)
    payload.query = val;
    return $http.post(url, payload);
  }


  trackService.sendToAmplify = function(track) {
    function uuidv4() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }
    var url =  AMPLIFY_URL + "/api/recordingsessions";
    var payload = {
      "recordingSessionId": uuidv4 = uuidv4(),
      "sourceName": "Audition",
      "sourceUrl": $location.absUrl(),
      "recordings": [
        {
          "isrc": track.isrc,
          "artist": track.artist_name,
          "title": track.formatted_title,
          "audioUrl": INTERNAL_API_URL + "/api/tracks/" + track.r2_resource_id + "/audio/full-stream",
          "imageUrl": INTERNAL_API_URL + "/api/tracks/" + track.r2_resource_id + "/assets/thumbnail-large",
          "otherIdentifiers": {
            "upc": track.upc
          },
          "year": track.pc_notice_year
        }
      ],
      "timestamp": new Date().toISOString()
    }
    return $http.put(url, payload);
  }


  return trackService;


});

