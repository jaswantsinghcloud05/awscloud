class PaginationManager {
//TODO get rid of rootScope
  constructor($rootScope) {
    this.rootScope = $rootScope;
    this.currentPage = 1;
  }
}

angular.module('auditionApp').service('paginationManager', PaginationManager);
