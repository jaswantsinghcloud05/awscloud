/**
 * Created by davide on 04/08/2016.
 */
class MessagingService {

  constructor($rootScope) {
    this.rootScope = $rootScope;
  }

  broadcast(message, payload){
    this.rootScope.$broadcast(message,payload)
  }
}

MessagingService.audioPlaying = "audioPlaying";
MessagingService.knobPlayerPlaying = "knobPlayerPlaying";
MessagingService.trackListUpdated = "trackListUpdated";
MessagingService.trackFiltersUpdated = "trackFiltersUpdated";
MessagingService.trackMetricsUpdated = "trackMetricsUpdated";
MessagingService.trackListRefreshed = "trackListRefreshed";
MessagingService.playlistSelected = "playlistSelected";
MessagingService.playlistItemMoved = "playlistItemMoved";
MessagingService.filtersReset = "filtersReset";
MessagingService.tabSelected = "tabSelected";
MessagingService.searchSelected = "searchSelected";
MessagingService.urlChanged = "urlChanged";
MessagingService.albumsListUpdated = "albumsListUpdated";
MessagingService.albumUpdated = "albumUpdated";

angular.module('auditionApp').service('messagingService', MessagingService);

