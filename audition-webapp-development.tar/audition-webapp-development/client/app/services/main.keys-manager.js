class KeysManager {
//TODO get rid of rootScope
  constructor($rootScope) {
    this.rootScope = $rootScope;
  }

  keyPushed (keyCode) {
    this.rootScope.isShiftDown = keyCode == 16;
    this.rootScope.isCtrlDown = keyCode == 91;
  }

  keyReleased (keyCode) {
    if (keyCode == 16) {
      this.rootScope.isShiftDown = false;
    }
    if (keyCode == 91) {
      this.rootScope.isCtrlDown = false;
    }
  }

  isCtrlDown(){

    return this.rootScope.isCtrlDown;
  }

  isShiftDown(){
    return this.rootScope.isShiftDown;
  }
}

register('auditionApp').service('keysManager', KeysManager);
