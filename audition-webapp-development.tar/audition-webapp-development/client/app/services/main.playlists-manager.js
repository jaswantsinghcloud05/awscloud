class PlaylistsManager {

  constructor($rootScope, tracksManager, trackService, playlistService, messagingService) {
    this.rootScope = $rootScope;
    this.playlistService = playlistService;
    this.messagingService = messagingService;
    this.playlists = [];
    this.totalPlaylistsNum = 0;
    this.currentPlaylist = {};
    this.tracksManager = tracksManager;
  }

  set currentFilteredPlaylists(playlists){
    this.playlists = playlists;
  }

  get currentFilteredPlaylists(){
    return this.playlists;
  }

  get totalPlaylists(){
    return this.totalPlaylistsNum;
  }

  set totalPlaylists(total){
    this.totalPlaylistsNum = total;
  }

  set selectedPlaylist(playlist){
    if(playlist) {
      this.currentPlaylist = playlist;
      this.messagingService.broadcast(MessagingService.playlistSelected);//TODO use RxJs observer pattern
    }
  }

  get selectedPlaylist(){
    return this.currentPlaylist;
  }

  addTrackToCurrentPlaylist(track){
    if (!this.currentPlaylist._source.tracks) this.currentPlaylist._source.tracks = [];
    this.currentPlaylist._source.tracks.push(track);
    return this.playlistService.updatePlaylist(this.currentPlaylist)
      .then((data) =>{
        this.selectedPlaylist = data.data.result.hits.hits[0];
        this.messagingService.broadcast(MessagingService.playlistSelected);//TODO maybe us a specific message for update
      },(error) =>{
        this.currentPlaylist._source.tracks.pop();
        if(error.status == "409"){
          this.playlistService.getPlaylist(this.currentPlaylist._id)
            .then((data) => {
              this.selectedPlaylist = data.data.result.hits.hits[0];
              this.addTrackToCurrentPlaylist(track);
            },(error) => {
              //TODO
          });
        }
      });
  }

  updateCurrentPlaylist(){
    return this.updatePlaylist(this.currentPlaylist);
  }

  updatePlaylist(playlist){
    return this.playlistService.updatePlaylist(playlist)
      .then((data) =>{
        this.selectedPlaylist = data.data.result.hits.hits[0];
        this.messagingService.broadcast(MessagingService.playlistSelected);//TODO maybe us a specific message for update
      },(error) =>{
        if(error.status == "409"){
          this.playlistService.getPlaylist(this.currentPlaylist._id)
            .then((data) => {
              this.selectedPlaylist = data.data.result.hits.hits[0];
              this.updateCurrentPlaylist();
            },(error) => {
              //TODO
            });
        }
      });
  }

  set selectedTrack(track){
    if(track) {
      this.rootScope.selectedTrack = track;
    }
  }

  get selectedTrack(){
    return this.rootScope.selectedTrack;
  }

  createPlaylistTextEmail() {
    if (this.currentPlaylist){
      var content = String.fromCharCode(13) + String.fromCharCode(13) + "The playlist " + this.currentPlaylist._source.name + " is available at " + this.currentPlaylist._source.box_public_url
      content += String.fromCharCode(13) + "List of tracks" + String.fromCharCode(13) + String.fromCharCode(13);
      for (var i=0; i<this.currentPlaylist._source.tracks.length;i++){
        var item = this.currentPlaylist._source.tracks[i];
        content += (i+1) + ". " + item.formatted_title + " by " + item.artist_name + String.fromCharCode(13);
      }
      return content;
    }
  }

  applyNewTracksFilters(filters){
    var promise = this.updatePlaylists(filters, 0)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListUpdated);//TODO use RxJs observer pattern
    });
    this.playlistService.getTracksMetrics(filters).success((data) => {
      if (data.searchId === filters.id) {
        //TODO review these loops
        this.tracksManager.metrics = data.result.aggregations.tracks;
        this.tracksManager.totalTracksNum = data.result.hits.total;
      }
    }).error((data, status, headers, config)=>{
      if (status == 204 || status == 401) {
        this.tracksManager.metrics = {};
        this.tracksManager.totalTracksNum = 0;
      }else{
        console.error(config);
      }
    }).finally((data) => {
      this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  updatePlaylists(filters, skip){
    var promise = this.playlistService.searchByTracks(filters,skip);
    promise.success((data) => {
      if (data.searchId === filters.id) {
        this.playlists.length = 0;
        this.playlists.push(...data.result.hits.hits);
        this.totalPlaylistsNum = data.result.hits.total;
      }
    }).error((data, status, headers, config) => {
      if (status==400 || status == 401){
        this.playlists = [];
        this.totalPlaylistsNum = 0;
      }else{
        //TODO show some sort of message
      }
    });
    return promise;
  }

  getTracksMetrics(filters){
    var promise = this.playlistService.getTracksMetrics(filters).success((data) => {
      if (data.searchId === filters.id) {
        //TODO review these loops
        this.tracksManager.metrics = data.result.aggregations;
        this.tracksManager.totalTracks = data.result.hits.total;
      }
    }).error((data, status, headers, config)=>{
      if (status == 204 || status == 401) {
        this.tracksManager.metrics = {};
        this.tracksManager.totalTracksNum = 0;
      }else{
        console.error(config);
      }
    }).finally((data) => {
      this.messagingService.broadcast(MessagingService.trackMetricsUpdated);//TODO use RxJs observer pattern
    });
    this.messagingService.broadcast(MessagingService.trackFiltersUpdated);//TODO use RxJs observer pattern
    return promise;
  }

  refreshPlaylists(filters, skip){
    var promise = this.updatePlaylists(filters, skip)
    promise.finally((data) => {
      this.messagingService.broadcast(MessagingService.trackListRefreshed);//TODO use RxJs observer pattern
    });
    return promise;
  }



}

angular.module('auditionApp').service('playlistsManager', PlaylistsManager);
