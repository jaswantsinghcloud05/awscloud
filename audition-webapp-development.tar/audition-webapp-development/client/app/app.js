//TODO some external libraries don't declare counter variables (i) which cause errors in prod
//'use strict';

angular.module('auditionApp', [
  'ngCookies',
  'ngResource',
  'ngSanitize',
  'ngAnimate',
  'ui.router',
  'ui.bootstrap',
  'ui.sortable',
  'ui.select',
  'config',
  'rzModule',
  'ngAudio',
  'ngStorage',
  'angular-bind-html-compile',
  'ngFileUpload',
  'datamaps',
  "chart.js",
  'ngMaterial',
  'ngMessages',
  'ngclipboard',
  'angular.img'
])
  .config(function ($stateProvider, $urlRouterProvider, $locationProvider, $httpProvider) {
    $urlRouterProvider
      .otherwise('/');
    $locationProvider.html5Mode(true);
    $httpProvider.interceptors.push('authInterceptor');
  })
  .factory('authInterceptor', function ($rootScope, $q, $cookieStore, $injector, usersManager,
                                        REST_BASE_URL, AMPLIFY_URL, $window) {
   return {
     // Add authorization token to headers
     request: function (config) {
       if(config.url.indexOf(AMPLIFY_URL) < 0 ){
         config.headers = config.headers || {};
         var bearer = $window.localStorage.getItem('audition-adfsAccessToken');
         if (bearer) {
           config.headers.Authorization = 'Bearer ' + bearer;
           config.headers.adfsRefreshToken = $window.localStorage.getItem('audition-adfsRefreshToken');
         }else{
           bearer = $window.localStorage.getItem('audition-oktaAccessToken');
           if (bearer) {
             config.headers.Authorization = 'Bearer ' + bearer;
             config.headers.oktaRefreshToken = $window.localStorage.getItem('audition-oktaRefreshToken');
           }
         }
       }
       return config;
     },
     response: function(response) {
       if (response.headers('adfsAccessToken')) localStorage.setItem('audition-adfsAccessToken',response.headers('adfsAccessToken'));
       if (response.headers('adfsRefreshToken')) localStorage.setItem('audition-adfsRefreshToken',response.headers('adfsRefreshToken'));
       if (response.headers('oktaAccessToken')) localStorage.setItem('audition-oktaAccessToken',response.headers('adfsAccessToken'));
       if (response.headers('oktaRefreshToken')) localStorage.setItem('audition-oktaRefreshToken',response.headers('adfsRefreshToken'));
       return $q.resolve(response);
     },

     // Intercept 401s and redirect you to login
     responseError: function(response) {
       if (response.headers('adfsAccessToken')) localStorage.setItem('audition-adfsAccessToken',response.headers('adfsAccessToken'));
       if (response.headers('adfsRefreshToken')) localStorage.setItem('audition-adfsRefreshToken',response.headers('adfsRefreshToken'));
       if (response.headers('oktaAccessToken')) localStorage.setItem('audition-oktaAccessToken',response.headers('oktaAccessToken'));
       if (response.headers('oktaRefreshToken')) localStorage.setItem('audition-oktaRefreshToken',response.headers('oktaRefreshToken'));
       if(response.status === 401 && !response.data.source) { //!$rootScope.loginModalOpen
         setTimeout(function() {
           var overlay = document.getElementsByClassName("full-dark-overlay");
           if (overlay && overlay[0]) {
             overlay[0].style.display = "block"
           }
         },1000);
           // remove any stale tokens
         var w = 500;
         var h = 700;
         // var left = (this.window.innerWidth/2)-(w/2);
         // var top = (this.window.innerHeight/2)-(h/2);
         //TODO do redirection in nodejs
         if(localStorage.getItem('audition-adfsRefreshToken')){
           var url = REST_BASE_URL + "/auth/adfs/login?action=" + (response.config.url || "");
           var popup = $window.open(url, "UMG login", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h);
         }else if(localStorage.getItem('audition-oktaAccessToken')){
           var url = REST_BASE_URL + "/auth/okta/login?action=" + (response.config.url || "");
           $window.open(url, "Partners login", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h);
         }else{
           $window.location.href = '/login' + (window.location.search || '');
         }
         //$injector.get("Modal").confirm.login()
         //$cookieStore.remove('adfsToken');
       }else if(response.status === 403) {
         var message= "You are not authorised to access Audition playlist functions. Please contact AppSupport if you require access.";
         if (response.data && response.data.error){
           message = response.data.error;
         }
         $injector.get("Modal").information.message("Operation Forbidden", message);
       }
       return $q.reject(response);
     }
   };
  })

  .run(function ($rootScope, $location, Auth) {
   // Redirect to login if route requires auth and you're not logged in
   $rootScope.$on('$stateChangeStart', function (event, next) {
     Auth.isLoggedInAsync(function(loggedIn) {
       if (next.authenticate && !loggedIn) {
         $location.path('/login');
       }
     });
   });
  })
  .filter('secondsToDateTime', [function() {
    return function(seconds) {
      return new Date(1970, 0, 1).setSeconds(seconds);
    };
  }]);

//ES6 polyfill
if (!Array.prototype.find) {
  Array.prototype.find = function(predicate) {
    if (this === null) {
      throw new TypeError('Array.prototype.find called on null or undefined');
    }
    if (typeof predicate !== 'function') {
      throw new TypeError('predicate must be a function');
    }
    var list = Object(this);
    var length = list.length >>> 0;
    var thisArg = arguments[1];
    var value;

    for (var i = 0; i < length; i++) {
      value = list[i];
      if (predicate.call(thisArg, value, i, list)) {
        return value;
      }
    }
    return undefined;
  };
}
if(!Array.prototype.move) {
  Array.prototype.move = function (from, to) {
    this.splice(to, 0, this.splice(from, 1)[0]);
  }
}
