angular.module('auditionApp')
  .filter('youtubeEmbedUrl', function ($sce) {
    return function(videoId) {
      return $sce.trustAsResourceUrl('http://img.youtube.com/vi/' + videoId + '/hqdefault.jpg');
    };
  });
