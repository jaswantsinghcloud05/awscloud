/**
 * Created by davide on 06/09/2015.
 */
angular.module('auditionApp').filter('notInPlaylistFilter', [function(){
  return function(input, param){
    var ret = [];
    var found = false;
//    if(!angular.isDefined(param)) param = $localStorage.playlistName;
    //TODO this create problem to angular watchers investigate why and to remove ng-hide element
//    if (angular.isDefined(input) && input.length == 0){
//      ret.push({name:''});
//    }
    angular.forEach(input, function(v){
      if(v.name === param){
        found = true;
      }else{
        ret.push(v);
      }
    });
    if (found) return []
    else return ret;
  };
}])
