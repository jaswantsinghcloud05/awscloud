'use strict';

angular.module('auditionApp')
  .config(function ($stateProvider,$urlRouterProvider) {
    $urlRouterProvider.when('/','/tracks-filters');
    $stateProvider
      .state('main', {
        abstract: true,
        url: '/',
        templateUrl: 'app/main/main.html',
        controller: 'MainCtrl',
        resolve:{
          query: ['$stateParams', function($stateParams){
            return $stateParams.query;
          }]
        }
      });
    $stateProvider
      .state('main.filteredTracks', {
        url: 'tracks-filters?query',
        component: 'searchContext',
        params: {
          query: {dynamic: true},
        },
        reloadOnSearch:false,
        onEnter: function(urlStatusManager, query){
          if(query){
            urlStatusManager.updateStatusFromUrl(decodeURI(query));
          }
        }
      });
    $stateProvider
      .state('main.trackContext', {
        url: 'track-context?query',
        component: 'trackContext',
        params: {
          query: {dynamic: true},
        },
        reloadOnSearch:false,
        onEnter: function(urlStatusManager, query){
          if(query){
            urlStatusManager.updateStatusFromUrl(decodeURI(query));
          }
        }
      });
    $stateProvider
      .state('main.artistContext', {
        url: 'artist-context?query',
        component: 'artistContext',
        params: {
          query: {dynamic: true},
        },
        reloadOnSearch:false,
        onEnter: function($state, query, urlStatusManager, artistsManager){
          if(query){
            urlStatusManager.updateStatusFromUrl(decodeURI(query));
            if(urlStatusManager.status.filters.match.canopus_id){
              artistsManager.loadSelectedArtist(urlStatusManager.status.filters.match.canopus_id);
            }
          }
        }
      });
    $stateProvider
      .state('main.albumContext', {
        url: 'album-context?query',
        component: 'albumContext',
        params: {
          query: {dynamic: true},
        },
        reloadOnSearch:false,
        onEnter: function($state, query, urlStatusManager, albumsManager){
          if(query){
            urlStatusManager.updateStatusFromUrl(decodeURI(query));
            if(urlStatusManager.status.filters.match.upc){
              albumsManager.loadSelectedAlbum(urlStatusManager.status.filters.match.upc);
            }
          }
        }
      });
  })
  .config(function($mdThemingProvider) {
  $mdThemingProvider.definePalette('AuditionColor_Palette', {
    '50': 'F0F2F2',
    '100': 'E3E8E8',
    '200': 'D1DADB',
    '300': 'C4CCCC',
    '400': 'B8BFBF',
    '500': '45545B',  // Tab Icon Active Color
    '600': '3E4B51',
    '700': '363F45',
    '800': '2C363A',
    '900': '252C30',
    'A100': 'C95F5B',
    'A200': 'D66565',
    'A400': 'E16A66',
    'A700': 'EB6F6A',

    'contrastDefaultColor': 'light',    // whether, by default, text (contrast)
                                        // on this palette should be dark or light
    'contrastDarkColors': ['500','600','700','800','900','A100','A200','A400','A700'],
    'contrastLightColors': undefined    // could also specify this if default was 'dark'

  });
  $mdThemingProvider.theme('default')
    .primaryPalette('AuditionColor_Palette', { 'default': '500'})
    .accentPalette('AuditionColor_Palette', { 'default': 'A400'});
  });
