angular.module('auditionApp').controller('PlayListCtrl', function (
  $rootScope, $scope,$timeout,trackService,playlistService,Upload,REST_BASE_URL, Modal) {

  //tracks list

  var uploadPlaylist = function(file){
    $scope.playlistImporting =true;
    $scope.f = file;
    if (file && !file.$error) {
      //TODO move into service
      file.upload = Upload.upload({
        url: REST_BASE_URL + '/api/playlists/' + $scope.playlist.selectedForImport + '/csv',
        file: file
      });

      file.upload.then(function (response) {
        if ($rootScope.playlists.indexOf($scope.playlist.selectedForImport)<0) {
          $rootScope.playlists.push($scope.playlist.selectedForImport);
          $rootScope.playlists.push($scope.playlist.selectedForImport+"-MASTER");
        }
        $scope.playlistImporting = false;
      }, function (response) {
        if (response.status > 0) {
          $scope.errorMsg = response.status + ': ' + response.data;
        }
        $scope.playlistImporting =false;
      });

      file.upload.progress(function (evt) {
        file.progress = Math.min(100, parseInt(100.0 *
          evt.loaded / evt.total));
      });
    }
  }

  $scope.playlist = {selectedForImport:''};
  $scope.playlistImporting =false;
  $scope.uploadFiles = function(file) {
    if ($scope.playlist && $scope.playlist.selectedForImport){
      if ($rootScope.playlists.indexOf($scope.playlist.selectedForImport)>-1){
        Modal.confirm.merge(uploadPlaylist)($scope.playlist.selectedForImport,file);
      }else{
        uploadPlaylist(file);
      }
    }
  }

  $scope.playlist = {selectedForDelete:''};
  $scope.playlistDeleting =false;
  $scope.onPlaylistDeleteClick = function() {
    Modal.confirm.delete(function(){
      $scope.playlistDeleting =true;
      playlistService.deletePlaylist($scope.playlist.selectedForDelete).then(function (response) {
        $rootScope.playlists.splice($rootScope.playlists.indexOf($scope.playlist.selectedForDelete), 1);
        $scope.playlist.selectedForDelete = undefined;
        $scope.playlistDeleting =false;
      }, function (response) {
        if (response.status > 0) {
          $scope.errorMsg = response.status + ': ' + response.data;
        }
        $scope.playlistDeleting =false;
      });
    })($scope.playlist.selectedForDelete);
  }

  var copyPlaylist = function(sourceName,destinationName){
    playlistService.copyPlaylist(sourceName,destinationName)
      .then(function(){
        $scope.playlistSaving =false;
      }, function (response) {
        if (response.status > 0) {
          $scope.errorMsg = response.status + ': ' + response.data;
        }
      }
    );
  }

  $scope.playlist = {selectedForSave:''};
  $scope.playlistSaving =false;
  $scope.onPlaylistSaveClick = function() {
    if ($scope.playlist && $scope.playlist.selectedForSave) {
      $scope.playlistSaving =true;
      if ($rootScope.playlists.indexOf($scope.playlist.selectedForSave) > -1) {
        Modal.confirm.merge(copyPlaylist)($scope.playlist.selectedForSave, $rootScope.playlistName,$scope.playlist.selectedForSave);
      } else {
        playlistService.copyPlaylist($rootScope.playlistName,$scope.playlist.selectedForSave)
          .then(function() {
            $rootScope.playlists.push($scope.playlist.selectedForSave);
            $scope.playlistSaving =false;
          }, function (response) {
            if (response.status > 0) {
              $scope.errorMsg = response.status + ': ' + response.data;
            }
            $scope.playlistSaving =false;
          }
        );
      }
    }
  }
//**************************************************************************
  //TODO end of "create a knob directive or a common controller to extend"

  var loadPlayList = function(){
    $scope.playlistLoading = true;
    playlistService.getPlaylist()
      .success(function(tracks){
        var playlist = [];
        if (unbindCollectionWatcher){
          unbindCollectionWatcher();
        }
        for (var i = 0; i < tracks.length; i++){
          var playlistTrack = {position: tracks[i].playlist_tags[0].position, track: tracks[i]};
          playlist.push(playlistTrack);
          if (playlistTrack.position == $localStorage.lastPlaylistTrackSelected){
            playlistTrack.selected = true;
          }
        }
        $rootScope.playlist = playlist;
        unbindCollectionWatcher = $rootScope.$watchCollection("playlist", playlistCollectionWatcher);
        $scope.playlistLoading =false;
      });
  }

  $scope.onTrackRowSelect = function (playlistItem) {
    //TODO find a better place where doing this
    playlistItem.track.largeThumbnailUrl = "/api/tracks/"+playlistItem.track.isrc+"/assets/thumbnail-large"
    $rootScope.selectedTrack = playlistItem.track;
    $rootScope.isArtistCollapsed = true;
    //highlight selected row
    var playlist = $rootScope.playlist;
    for(var i = 0; i < playlist.length; i++){
      playlist[i].selected = false;
    }
    playlistItem.selected = true;
    $localStorage.lastPlaylistTrackSelected = playlistItem.position
    maxInitilized = false;
  }

  $scope.onRemoveTrackClick = function (playlistTrackIdx) {
    var playlistTrack = $rootScope.playlist[playlistTrackIdx];
    playlistTrack.removing = true;
    playlistService.removeTrack(playlistTrack)
      .success(function(){
        playlistTrack.removing = false;
        var playlist = $rootScope.playlist;
        var idx = playlist.indexOf(playlistTrack);
        if (idx >= 0){
          $rootScope.playlist.splice(idx,1);
          for (i=idx; i<playlist.length; i++){
            playlist[i].position = i;
          }
        }
        //updates the track in the filtered one
        $rootScope.tracks.find(function(item, index,array){
          if (item.isrc == playlistTrack.track.isrc) {
            item.playlist_tags.find(function (item, index, array) {
              if (item.name == $localStorage.playlistName) {
                array.splice(index, 1);
                return true;
              }
            });
            return true;
          }
        });

        playlist[idx].selected = true;
      });
  }
})
