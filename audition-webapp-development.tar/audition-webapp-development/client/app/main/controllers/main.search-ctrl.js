angular.module('auditionApp').controller('SearchBarCtrl',
  function ($rootScope, $scope, $location, $window, $cookies) {

  var userName;

  $scope.onLogoutClick = function () {
      $window.localStorage.clear();
      $cookies.remove("UT");
      $window.location.href = "/login";
    };

    $scope.currentUserName = function () {
      if(!userName){
        var profile = $window.localStorage.getItem("audition-profile");
        if(profile) userName = JSON.parse(profile).name
      }
      return userName
    };

//TODO make this a directive    ************

});
