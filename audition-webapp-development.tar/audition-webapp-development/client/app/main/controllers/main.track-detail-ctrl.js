angular.module('auditionApp').controller('TrackDetailCtrl', function (
  $rootScope, $scope, artistService, urlStatusManager) {


  $scope.artistNameClick = function(track) {
    urlStatusManager.status.tab = "artistTracks";
    urlStatusManager.status.selectedTrack = undefined;
    urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    urlStatusManager.status.filters.match.canopus_id = track.canopus_id;
    urlStatusManager.updateUrl("/artist-context");//TODO make this call automatic in USM when the status is update
  }

  $scope.onTrackTitleClick = function(track) {
    urlStatusManager.status.tab = "trackVersions";
    urlStatusManager.status.selectedTrack = track.r2_resource_id;
    urlStatusManager.status.filters.match.resource_rollup_id = track.resource_rollup_id;
    urlStatusManager.status.filters.match.canopus_id = undefined;
    urlStatusManager.updateUrl("/track-context");//TODO make this call automatic in USM when the status is update
  }

  $scope.formatTags = function(track){
    var formatted = ""
    if(track && track.tags_details){
      track.tags_details.forEach((item)=>{
        if (item.source == "Manual"){
          formatted += `  ${item.path.substr(item.path.lastIndexOf("/")+1)}  |`;
        }
      })
    }
    return formatted.substr(0,formatted.length-2);
  }

});
