'use strict';

angular.module('auditionApp')
  .controller('MainCtrl', function ($rootScope, $scope, $transitions, $location, messagingService,
                                    tracksManager,playlistsManager, albumsManager, keysManager,Modal,trackService,
                                    urlStatusManager, artistsManager) {

    $rootScope.isShiftDown = false;
    $rootScope.isCtrlDown = false;
    $rootScope.playlistCheck = false;

    $transitions.onSuccess({ }, function(trans) {
      if($location.search().query){
        urlStatusManager.updateStatusFromUrl(decodeURI($location.search().query));
        if(urlStatusManager.status.filters.match.canopus_id){
          artistsManager.loadSelectedArtist(urlStatusManager.status.filters.match.canopus_id);
        }else if(urlStatusManager.status.filters.match.upc){
          albumsManager.loadSelectedAlbum(urlStatusManager.status.filters.match.upc);
        }
      }else{
        trackService.resetFilters();   //TODO
        messagingService.broadcast(MessagingService.urlChanged)
      }
    });


    $scope.onKeyDown = function ($event) {
      keysManager.keyPushed($event.keyCode);
    };

    $scope.onKeyUp = function ($event) {
      keysManager.keyReleased($event.keyCode);
    };

    $scope.onPublishRightsDetailClick = function(){
      Modal.information.map(tracksManager.selectedTrack);
    }
  });
