angular.module('auditionApp').controller('TrackFiltersCtrl', function (
  $rootScope, $scope, urlStatusManager, messagingService) {
  //called one page reload with parameters in url
  switch (urlStatusManager.status.tab){
    case "tracks":
      $scope.selectedIndex = 0;
      break;
    case "playlists":
      $scope.selectedIndex = 1;
  }

  $scope.$on(MessagingService.urlChanged, (event) => {
    switch (urlStatusManager.status.tab){
      case "tracks":
        $scope.selectedIndex = 0;
        break;
      case "playlists":
        $scope.selectedIndex = 1;
    }
  })

  $scope.filterCheck = true;
});
