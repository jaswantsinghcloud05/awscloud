angular.module('auditionApp').controller('TrackSimilarityCtrl', function (
  $rootScope, $scope, artistService, trackService,$timeout, ngAudio) {

  //audio variables  TODO move in knob directive


  $scope.onSimilarRowSelect = function (track) {
    //TODO find a better place where doing this
    if (track != $rootScope.selectedTrack) {
      track.largeThumbnailUrl = "/api/tracks/" + track.isrc + "/assets/thumbnail-large"
      $rootScope.selectedSimilarTrack = track;
      //$rootScope.isSelectedSimilarTracksCollapsed = false;
      maxInitilized = false;
    }
  }

  //TODO create a knob directive or a common controller to extend

  $rootScope.$on("trackListUpdated", function(event) {
    if (trackInPlay && trackInPlay.playing) {
      stopPlayBack(trackInPlay);
    }
  });

  var stopPlayBack = function (track) {
    $timeout.cancel(clipPlaybackTimeout);
    sound.stop();
    track.playing = false;
    track.clipPlaybackTime = 0;
  }

  $scope.onStartPlayingClick = function (track) {
    if (track.playing) {
      stopPlayBack(track);
    } else {
      if (trackInPlay && track !== trackInPlay) {
        stopPlayBack(trackInPlay)
      }
      sound = ngAudio.load("/api/tracks/" + track.isrc + "/audio/summary-stream");
      sound.play();
      trackInPlay = track;
      trackInPlay.playing = true;
      trackInPlay.clipPlaybackTime = 0;
      clipPlaybackTimeout = $timeout($scope.onTimeout, 200);
    }
  }

  $scope.onTimeout = function () {
    trackInPlay.clipPlaybackTime = sound.currentTime;
    if (isNaN(sound.duration) && sound.duration != undefined){
      //Safari put "Infinity" in duration and knob reconfigure doesn't work
      maxInitilized = true;
    }else if(!maxInitilized && sound.duration != undefined){
      $scope.max = sound.duration;
      angular.element('#playlist-knob-' + trackInPlay.isrc).trigger('configure', {
        max: sound.duration
      });
      maxInitilized = true;
    }
    if (sound.progress > 0 && sound.remaining == 0) {
      stopPlayBack(trackInPlay);
    } else {
      clipPlaybackTimeout = $timeout($scope.onTimeout, 200);
    }
    $scope.$apply();
  }
  //TODO end of "create a knob directive or a common controller to extend"

});
