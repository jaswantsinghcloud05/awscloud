
'use strict';
class WaveFormPlayerCtrl {

  constructor($rootScope, $scope, messagingService){
    this.scope = $scope;
    this.rootScope = $rootScope;
    this.messagingService = messagingService;
    this.activeUrl = null;
    this.timeline  = null;
    this.paused = true;
    this.regionColors = ["rgb(130, 126, 189)","rgb(215, 149, 255)","rgb(136, 224, 136)",
      "rgb(255, 163, 163)","rgb(146, 146, 146)","rgb(149, 171, 255)","rgb(226, 226, 226)"];

    this.scope.$on(MessagingService.trackListUpdated, (event) =>{
      if (this.wavesurfer && this.wavesurfer.isPlaying()){
        this.wavesurfer.stop();
      }
    });

    this.scope.$on(MessagingService.knobPlayerPlaying, (event) =>{
      if (this.wavesurfer && this.wavesurfer.isPlaying()){
        this.wavesurfer.stop();
      }
    });

    this.scope.$on('wavesurferInit', (e, wavesurfer) => {
      this.wavesurfer = wavesurfer;

      this.wavesurfer.on('play', () =>{
        this.paused = false;
      });

      this.wavesurfer.on('pause', () => {
        this.paused = true;
      });

      this.wavesurfer.on('finish', () => {
        this.paused = true;
        this.wavesurfer.seekTo(0);
        if(!this.rootScope.$$phase) this.scope.$apply();
      });

      this.wavesurfer.on('loading', (progress) => {
        this.wavesurferLoading = true;
        this.wavesurferProgress = progress;
        if(!this.rootScope.$$phase) this.scope.$apply();
      });
      this.wavesurfer.on('ready', () => {
        this.hideProgress();
        this.timeline = Object.create(WaveSurfer.Timeline);
        //load regions
        if (this.scope.regions) {
          this.scope.regions.forEach((item) => {
            this.wavesurfer.addRegion(
              {
                "start": item.start_time,
                "end": item.start_time + item.length,
                "color": this.regionColors[parseInt(item.label)],
                "drag": false
              }
            );
          })
        };
        this.wavesurfer.on('region-click', (region, e) => {
          e.stopPropagation();
          // Play on click, loop on shift click
          e.shiftKey ? region.playLoop() : region.play();
          this.paused = false;
          if(!this.rootScope.$$phase) this.scope.$apply();
        });
        //this.wavesurfer.on('region-click', editAnnotation);
        //this.wavesurfer.on('region-updated', saveRegions);
        //this.wavesurfer.on('region-removed', saveRegions);
        //this.wavesurfer.on('region-in', showNote);

        this.wavesurfer.on('region-play', (region) => {
          region.once('out', () => {
            this.wavesurfer.play(region.start);
            this.wavesurfer.pause();
            this.paused = true;
            if(!this.rootScope.$$phase) this.scope.$apply();
          });
        });
        this.timeline.init({
          wavesurfer: this.wavesurfer,
          container: "#" + this.scope.elementId + "-wave-timeline"
        });
        this.scope.redraw = true;
      });
      this.wavesurfer.on('destroy', this.hideProgress);
      this.wavesurfer.on('error', this.hideProgress);

    });

  }

  playPause(){
    this.messagingService.broadcast(MessagingService.audioPlaying);
    this.wavesurfer.playPause();
  }

  hideProgress(){
    this.wavesurferLoading = false;
    this.wavesurferProgress = 0;
    this.scope.$apply();
    this.wavesurfer.drawBuffer();
  }
}

class WaveFormPlayerComponent {

  constructor() {
    this.scope = {
      song: "=track", //from parent scope (being an object it must be =)
    };
    this.replace = true;
    this.controller = 'WaveFormPlayerCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div>
                        <img http-src="{{song.largeThumbnailUrl}}" style="width: 90px;">
                        <i class="material-icons wave-control-button" ng-click="ctrl.playPause()" ng-show="ctrl.paused">
                          play_circle_outline</i>
                        <i class="material-icons wave-control-button" ng-click="ctrl.playPause()" ng-hide="ctrl.paused">pause_circle_outline</i>
              
                        <div
                          style="width: 89%;height: 96px;float: right;">
                          <div class="waveform_wrapper">
                            <!--redraw-if="isArtistCollapsed==true" is required because wavesurfer draws the waveform based on the
                            container dimensions, if the track div is collapsed the waveform is invisible and needs to be redrawn
                            -->
                            <ng-wavesurfer id="track" ng-show="!ctrl.wavesurferLoading" track-id="song.r2_resource_id"
                                        regions="song.structure" renderer="Istorender"
                                        wave-color="#363F45" progress-color="#DF6C64" bar-width="2"
                                        height="48"></ng-wavesurfer>
                            <div id="track-wave-timeline" ng-show="!ctrl.wavesurferLoading"></div>
                            <uib-progressbar value="ctrl.wavesurferProgress" class="progress-striped progress"
                                             style="margin-top: 50px" type="danger" ng-show="ctrl.wavesurferLoading"></uib-progressbar>
                            <div class="track-length" ng-show="!ctrl.wavesurferLoading">
                              {{song.length | secondsToDateTime | date:'HH:mm:ss'}}
                            </div>
                          </div>
                        </div>`;
  }
}

register('auditionApp').directive('waveFormPlayer', WaveFormPlayerComponent);
register('auditionApp').controller('WaveFormPlayerCtrl', WaveFormPlayerCtrl);

