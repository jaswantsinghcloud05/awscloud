// Other than where specified, this should be the same as:
//   https://raw.githubusercontent.com/katspaugh/wavesurfer.js/master/src/util.js
//
// Override ajax function to add our auth headers
WaveSurfer.util.ajax = function (options) {
  var ajax = Object.create(WaveSurfer.Observer);
  var xhr = new XMLHttpRequest();
  var fired100 = false;

  xhr.open(options.method || 'GET', options.url, true);

  // START added code
  var bearer = localStorage.getItem('audition-adfsAccessToken');
  if (bearer) {
    xhr.setRequestHeader("Authorization", "Bearer " + bearer)
    xhr.setRequestHeader("adfsRefreshToken", localStorage.getItem('audition-adfsRefreshToken'))
  }else{
    bearer = localStorage.getItem('audition-oktaAccessToken');
    if (bearer) {
      xhr.setRequestHeader("Authorization", "Bearer " + bearer)
      xhr.setRequestHeader("oktaRefreshToken", localStorage.getItem('audition-oktaRefreshToken'))
    }
  }

  // END added code

  xhr.responseType = options.responseType || 'json';

  xhr.addEventListener('progress', function (e) {
    ajax.fireEvent('progress', e);
    if (e.lengthComputable && e.loaded == e.total) {
      fired100 = true;
    }
  });

  xhr.addEventListener('load', function (e) {
    if (!fired100) {
      ajax.fireEvent('progress', e);
    }
    ajax.fireEvent('load', e);

    if (200 == xhr.status || 206 == xhr.status) {
      ajax.fireEvent('success', xhr.response, e);
    } else {
      ajax.fireEvent('error', e);
    }
  });

  xhr.addEventListener('error', function (e) {
    ajax.fireEvent('error', e);
  });

  xhr.send();
  ajax.xhr = xhr;
  return ajax;
}
