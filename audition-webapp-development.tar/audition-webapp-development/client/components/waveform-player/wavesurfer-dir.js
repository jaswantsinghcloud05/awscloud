angular.module('auditionApp').directive('ngWavesurfer', function () {
  return {
    restrict: 'E',
    replace: true,

    link: function ($scope, $element, $attrs) {
      //TODO this could easly be the url of the tracks but for the moment
      //just using the r2_resource_id and building dynamically the url
      $scope.redrawIf = $scope.$eval($attrs.redrawIf);
      $scope.elementId = $attrs.id;

      $element.css('display', 'block');

      var options = angular.extend({container: $element[0]}, $attrs);
      //overriding default drawing algorithm
      WaveSurfer.Region.render= wavesurferOverrides.render;
      var wavesurfer = WaveSurfer.create(options);

      $scope.$watch($attrs.trackId, function (newValue, oldValue) {
        if (newValue != undefined && oldValue != newValue) {
          var regions = $scope.$eval($attrs.regions);
          if (regions) {
            $scope.regions = JSON.parse(regions);
          }
          wavesurfer.clearRegions();
          wavesurfer.empty();
          wavesurfer.load("/api/tracks/" + newValue + "/audio/full-stream", $attrs.data || null);
          $scope.$emit('wavesurferInit', wavesurfer);
        }
      }, true);
      $scope.$watch($attrs.redrawIf, function (newValue, oldValue) {
        if (newValue == true && $scope.redraw == true) {
          $scope.wavesurfer.drawBuffer();
          $scope.redraw = false;
        }
      });
    }
  }
});

var wavesurferOverrides = {
  //overriden in canvas-drawer
  drawBars: function (peaks, channelIndex) {
    // Split channels
    if (peaks[0] instanceof Array) {
      var channels = peaks;
      if (this.params.splitChannels) {
        this.setHeight(channels.length * this.params.height * this.params.pixelRatio);
        channels.forEach(this.drawBars, this);
        return;
      } else {
        peaks = channels[0];
      }
    }

    // A half-pixel offset makes lines crisp
    var $ = 0.5 / this.params.pixelRatio;
    var width = this.width;
    var height = this.params.height * this.params.pixelRatio;
    var offsetY = height * channelIndex || 0;
    var halfH = height / 2;
    var length = ~~(peaks.length / 2);
    var bar = this.params.barWidth * this.params.pixelRatio;
    var gap = Math.max(this.params.pixelRatio, ~~(bar / 2));
    var step = bar + gap;

    var absmax = 1;
    if (this.params.normalize) {
      var min, max;
      max = Math.max.apply(Math, peaks);
      min = Math.min.apply(Math, peaks);
      absmax = max;
      if (-min > absmax) {
        absmax = -min;
      }
    }

    var scale = length / width;

    this.waveCc.fillStyle = this.params.waveColor;
    if (this.progressCc) {
      this.progressCc.fillStyle = this.params.progressColor;
    }

    [ this.waveCc, this.progressCc ].forEach(function (cc) {
      if (!cc) { return; }
      for (var i = 0; i < width; i += step) {
        var h = Math.round(peaks[2 * i * scale] / absmax * halfH);
        cc.fillRect(i + $, halfH - h + offsetY+7, bar + $, h+7);
      }
    }, this);
  },
  /* overriden in WaveSurfer.Region */
  render: function () {
    var regionEl = document.createElement('region');
    regionEl.className = 'wavesurfer-region';
    regionEl.title = this.formatTime(this.start, this.end);
    regionEl.setAttribute('data-id', this.id);

    var width = this.wrapper.scrollWidth;
    this.style(regionEl, {
      position: 'absolute',
      zIndex: 2,
      height: '7px',
      top: '40px'
    });

    /* Resize handles */
    if (this.resize) {
      var handleLeft = regionEl.appendChild(document.createElement('handle'));
      var handleRight = regionEl.appendChild(document.createElement('handle'));
      handleLeft.className = 'wavesurfer-handle wavesurfer-handle-start';
      handleRight.className = 'wavesurfer-handle wavesurfer-handle-end';
      var css = {
        cursor: 'col-resize',
        position: 'absolute',
        left: '0px',
        top: '0px',
        width: '1%',
        maxWidth: '4px',
        height: '100%'
      };
      this.style(handleLeft, css);
      this.style(handleRight, css);
      this.style(handleRight, {
        left: '100%'
      });
    }

    this.element = this.wrapper.appendChild(regionEl);
    this.updateRender();
    this.bindEvents(regionEl);
  }
}
