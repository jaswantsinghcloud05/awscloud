'use strict';

WaveSurfer.Drawer.Istorender = Object.create(WaveSurfer.Drawer.Canvas);

WaveSurfer.util.extend(WaveSurfer.Drawer.Istorender, {
  drawBars: function (peaks, channelIndex) {
    // Split channels
    if (peaks[0] instanceof Array) {
      var channels = peaks;
      if (this.params.splitChannels) {
        this.setHeight(channels.length * this.params.height * this.params.pixelRatio);
        channels.forEach(this.drawBars, this);
        return;
      } else {
        peaks = channels[0];
      }
    }

    // A half-pixel offset makes lines crisp
    var $ = 0.5 / this.params.pixelRatio;
    var width = this.width;
    var height = this.params.height * this.params.pixelRatio;
    var offsetY = height * channelIndex || 0;
    var halfH = height / 2;
    var length = ~~(peaks.length / 2);
    var bar = this.params.barWidth * this.params.pixelRatio;
    var gap = Math.max(this.params.pixelRatio, ~~(bar / 2));
    var step = bar + gap;

    var absmax = 1;
    if (this.params.normalize) {
      var min, max;
      max = Math.max.apply(Math, peaks);
      min = Math.min.apply(Math, peaks);
      absmax = max;
      if (-min > absmax) {
        absmax = -min;
      }
    }

    var scale = length / width;

    this.waveCc.fillStyle = this.params.waveColor;
    if (this.progressCc) {
      this.progressCc.fillStyle = this.params.progressColor;
    }

    [ this.waveCc, this.progressCc ].forEach(function (cc) {
      if (!cc) { return; }
      for (var i = 0; i < width; i += step) {
        var h = Math.round(peaks[2 * i * scale] / absmax * halfH);
        cc.fillRect(i + $, halfH - h + offsetY+7, bar + $, h+7);
      }
    }, this);
  }});
