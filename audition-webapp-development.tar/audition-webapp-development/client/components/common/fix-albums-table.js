
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class FixAlbumTableCtrl {
  constructor($scope, $rootScope, albumsManager, trackService, tracksManager,
              keysManager, paginationManager, urlStatusManager, artistsManager){
    // super($scope, $rootScope, albumsManager, trackService, tracksManager,
    //   keysManager, paginationManager, urlStatusManager, Modal);

    this.rootScope = $rootScope;
    this.maxInitilized = false;
    this.trackService  = trackService;
    this.tracksManager = tracksManager;
    this.albumsManager = albumsManager;
    this.paginationManager = paginationManager;
    this.urlStatusManager = urlStatusManager;
    this.artistsManager = artistsManager;

    this.albums = [];


    $scope.$on(MessagingService.tabSelected, (event) => {
      this.loadAlbums();
    })

    $scope.$on(MessagingService.albumsListUpdated, (event) => {
      this.albums.length = 0;
      this.albumsManager.currentAlbums.forEach((item)=> {
        if(item._source.thumbnail_large_filename){
          item._source.thumbnail_large_filename = "/api/albums/" + item._source.upc + "/stream?file=" + encodeURIComponent(item._source.thumbnail_large_filename.substring(19));
        }else{
          item._source.thumbnail_large_filename = "not available";
        }
        this.albums.push(item._source);
      })
    })
    $scope.$on(MessagingService.albumUpdated, (event) => {
      albumsManager.loadAlternativeVersions(this.albumsManager.selectedAlbum.release_rollup_id);
    })

  }

  $onInit(){
    this.loadAlbums();
  }

  loadAlbums(){
    if (this.currentCriteria!==this.trackService.searchCriteria && this.urlStatusManager.urlStatus.tab==this.tabId) {
      //TODO remove condition and parametrise tabId
      if (this.tabId=="albumVersions"){
        this.albumsManager.loadAlternativeVersions(this.trackService.searchCriteria.match.upc);
      }else if(this.tabId=="artistAlbums"){
        this.albumsManager.loadArtistAlbums(this.trackService.searchCriteria.match.canopus_id );
      }
    }
  }

  onAlbumInfoClick(idx,album) {
    this.urlStatusManager.status.tab = "albumTracks";
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.filters.match.canopus_id = undefined;
    this.urlStatusManager.status.filters.match.upc = album.upc;
    this.urlStatusManager.updateUrl("/album-context");//TODO make this call automatic in USM when the status is update
  }

  onArtistInfoClick(idx,track) {
    this.urlStatusManager.status.tab = "artistTracks";
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.filters.match.canopus_id = track.canopus_id;
    this.urlStatusManager.status.filters.match.upc = undefined;
    this.urlStatusManager.updateUrl("/artist-context");//TODO make this call automatic in USM when the status is update
  }

}

let FixAlbumTableComponent = {


  bindings : {
    tabId: '<'
  },
  controller : 'FixAlbumTableCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="tracks_list_tbl" class="table albums-fix-column">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th></th>
                    <th>Album Name</th>
                    <th>Artist</th>
                    <th>Release</th>
                    <th>Label</th>
                    <th>Upc</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr ng-repeat='item in ctrl.albums'>
                    <td id="td_album_{{item.upc}}_thumbnail">
                      <div style="position: relative">
                        <a id="a_title_{{item.upc}}" ng-click="ctrl.onAlbumInfoClick($index, item)">
                        <img class="album-thumb" http-src="{{item.thumbnail_large_filename}}">
                        </a>
                      </div>
                    </td>
                    <td id="td_album_{{item.album_isrc}}_title">
                      <a id="a_title_{{item.upc}}" ng-click="ctrl.onAlbumInfoClick($index, item)">
                        <span uib-tooltip="{{item.formatted_title}}"
                                  tooltip-placement="top"
                                  tooltip-trigger="mouseenter"
                                  tooltip-popup-delay='1000'>{{item.formatted_title}}</span>
                      </a></td>
                    <td id="td_album_{{item.album_isrc}}_artist">
                    <a id="a_artist_{{item._source.r2_resource_id}}" ng-click="ctrl.onArtistInfoClick($index, item)">{{item.artist_name}}</a></td>
                    <td id="td_album_{{item.album_isrc}}_date">{{item.p_notice_year}}</td>
                    <td id="td_album_{{item.album_isrc}}_label">
                    <span uib-tooltip="{{item.label_name}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'>
                              {{item.label_name}}</span></td>
                    <td id="td_album_{{item.album_isrc}}_views">{{item.upc}}</td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              <div ng-show="ctrl.totalItems>0" style="position: absolute;left: 19vw;">
                <uib-pagination ng-change="ctrl.onPageChanged()"
                                total-items="ctrl.totalItems" ng-model="ctrl.currentPage" max-size="ctrl.maxSize" class="pagination-sm"
                                boundary-links="true" rotate="false" items-per-page="ctrl.itemsPerPage"></uib-pagination>
              </div>
              <span ng-show="ctrl.totalItems>0" style="float: right;margin-top: 1vh;margin-right: 4vh;">
                Showing tracks <strong>{{ctrl.itemsPerPage * (ctrl.currentPage-1)}}</strong> to <strong>{{ctrl.itemsPerPage *
                ctrl.currentPage}}</strong> of <strong>{{ctrl.totalItems}}</strong>
              </span>
              </div>
              `
}

angular.module('auditionApp').component('fixAlbumTable', FixAlbumTableComponent);
angular.module('auditionApp').controller('FixAlbumTableCtrl', FixAlbumTableCtrl);

