
'use strict';
/**
 * This file contains view and controller of the FixPlaylistTable directive.
 * This directive creates a html paginated table containing the playlists found in
 * this.tracksManager.currentTracks.
 *
 * */

class FixPlaylistTableCtrl {
  constructor($scope, $rootScope, playlistsManager, trackService, tracksManager,
              keysManager, paginationManager, urlStatusManager, Modal){
    this.rootScope = $rootScope;
    this.scope = $scope;
    this.maxInitilized = false;
    this.trackService  = trackService;
    this.keysManager = keysManager;
    this.tracksManager = tracksManager;
    this.paginationManager = paginationManager;
    this.playlistsManager = playlistsManager;
    this.urlStatusManager = urlStatusManager;
    this.modal = Modal;
    this.totalItems = 0;
    this.maxSize = 5;
    this.currentPage = 1;
    this.pageSize = this.trackService.searchCriteria.pageSize;
    this.itemsPerPage = this.trackService.searchCriteria.pageSize;
    this.matches = this.trackService.searchCriteria.match;
    this.sorting = false;
    this.metaData = true;
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.trackListUpdated, (event) => {
      this.playlists = this.playlistsManager.currentFilteredPlaylists;
      this.tracksManager.selectedTrack = undefined;
      this.selectedIdx = undefined;
      this.totalItems = this.playlistsManager.totalPlaylists;
    })
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.trackListRefreshed, (event) => {
      this.playlists = this.playlistsManager.currentFilteredPlaylists;
    })
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.tabSelected, (event) => {
      this.loadPlaylists();
    })
  }

  $onInit(){
    this.loadPlaylists();
  }

  loadPlaylists(){
    if (this.currentCriteria!==this.trackService.searchCriteria && this.urlStatusManager.urlStatus.tab==this.tabId) {
        angular.copy(this.trackService.searchCriteria,this.currentCriteria);
        this.playlistsManager.applyNewTracksFilters(this.trackService.searchCriteria);
    }
  }

  onTrackRowSelect(idx, track) {
  }

  /**
   * The form data
   * @memberof simple-table.SimpleTrackTableCtrl
   * @type {Object}
   * @property {String} fieldName column name to use for sorting
   * @property {String} order 1 asc, -1 desc
   * @todo at the moment it only handles sorting by one column even if the trackService
   * supports multiple column sorting
   */
  toggleSort(fieldName, order){
    var sort = this.trackService.searchCriteria.columnSorting;
    if (order==undefined){
      order = 1;
    }
    if(sort.length>0){
      if(sort[0][fieldName] != undefined){
        sort[0][fieldName] = sort[0][fieldName] * -1;
      }else{
        this.trackService.searchCriteria.columnSorting[0] = {[fieldName]: order};
      }
    } else {
      this.trackService.searchCriteria.columnSorting.push({[fieldName]:order})
    }
    this.sortBy = this.trackService.searchCriteria.columnSorting;
    this.sorting = true;
    var skip = this.trackService.searchCriteria.pageSize*(this.paginationManager.currentPage-1);
    var tracks;
    this.playlistsManager.refreshTracks(skip).finally(() => {//TODO use .then instead of .error, .finally
      this.sorting = false;
    });
  }

  /*
   *   TRACK LIST PAGINATION
   */
  onPageChanged() {
    var searchId;
    this.sorting =true;
    this.trackService.searchCriteria.id = Date.now();
    this.playlistsManager.refreshPlaylists(this.trackService.searchCriteria, this.itemsPerPage*(this.currentPage-1))
    .error(function (data, status, headers, config){//TODO use .then instead of .error, .finally
      //TODO show some sort of message
    }).finally(() =>{
      this.sorting = false;
    });
  }

}

let FixPlaylistTableComponent = {


    bindings : {
      tabId : '<'
    },
    controller : 'FixPlaylistTableCtrl',
    controllerAs : 'ctrl',
    //todo check why templeUrl not working after grunt build
    template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="playlists_list_tbl" class="table playlists-fix-column">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th></th>
                    <th>Playlist Name</th><!--<th><a href="#" ng-click="ctrl.toggleSort('name.keyword')" class="column-header">Playlist Name</a></th> -->
                    <th>Created By</th><!--<th><a href="#" ng-click="ctrl.toggleSort('createdBy')" class="column-header">Created By</a></th>  -->
                    <th>Created Date</th><!-- <th><a href="#" ng-click="ctrl.toggleSort('createdDate')" class="column-header">Created Date</a></th> -->
                    <th>Last Modified</th><!-- <th><a href="#" ng-click="ctrl.toggleSort('modifiedDate')" class="column-header">Last Modified</a></th> -->
                    <th>Rating</th><!-- <th><a href="#" class="column-header">Rating</a></th> -->
                    <th>Tags</th>
                  </tr>
                  </thead>
                  <tbody class="table-hover noselect">
                  <tr ng-repeat='item in ctrl.playlists'
                      ng-class="(item.selected==true)?'row-selected':''"
                      ng-click="ctrl.onTrackRowSelect($index, item._source)">
                    <td id="td_packshot_{{item._source.name}}">IMG</td>
                    <td id="td_title_{{item._source.name}}">
                    <span uib-tooltip="{{item._source.name}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'>{{item._source.name}}</span></td>
                    <td id="td_createdby_{{item._source.name}}">{{ item._source.createdBy}}</td>
                    <td id="td_created_{{item._source.name}}">{{ item._source.createdDate | date : 'mediumDate'}}</td>
                    <td id="td_modified_{{item._source.name}}">{{ item._source.modifiedDate | date : 'mediumDate'}}</td>
                    <td id="td_ranking_{{item._source.name}}"></td>
                    <td id="td_tags_{{item._source.name}}"></td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              <div ng-show="ctrl.totalItems>0" style="position: absolute;left: 19vw;">
                <uib-pagination ng-change="ctrl.onPageChanged()"
                                total-items="ctrl.totalItems" ng-model="ctrl.currentPage" max-size="ctrl.maxSize" class="pagination-sm"
                                boundary-links="true" rotate="false" items-per-page="ctrl.itemsPerPage"></uib-pagination>
              <!--  <div style="max-width: 9vw;margin-left: 30px;" class="input-group">
                  <input type="text" ng-model="ctrl.pageSize" class="form-control" style="height: 29px;" size="5">
                  <span class="input-group-btn">
                          <button ng-click="ctrl.onPageResizeClick()" class="btn btn-default"
                                  title="playlists per page" style="height: 29px;">
                            <span class="fa fa-retweet" style="vertical-align: top;"></span></button>
                  </span>
                </div>-->
              </div>
              <span ng-show="ctrl.totalItems>0" style="float: right;margin-top: 1vh;margin-right: 4vh;">
                Showing playlists <strong>{{ctrl.itemsPerPage * (ctrl.currentPage-1)}}</strong> to <strong>{{ctrl.itemsPerPage *
                ctrl.currentPage}}</strong> of <strong>{{ctrl.totalItems}}</strong>
              </span>
              </div>
              `
}

angular.module('auditionApp').component('fixPlaylistTable', FixPlaylistTableComponent);
angular.module('auditionApp').controller('FixPlaylistTableCtrl', FixPlaylistTableCtrl);

