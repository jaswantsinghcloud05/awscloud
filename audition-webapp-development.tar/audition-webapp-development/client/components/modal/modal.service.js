'use strict';

angular.module('auditionApp')
  .factory('Modal', function ($rootScope, $uibModal, $sce, trackService) {
    /**
     * Opens a modal
     * @param  {Object} scope      - an object to be merged with modal's scope
     * @param  {String} modalClass - (optional) class(es) to be applied to the modal
     * @return {Object}            - the instance $modal.open() returns
     */
    function openModal(scope, modalClass, size, controller) {
      var modalScope = $rootScope.$new();
      scope = scope || {};
      modalClass = modalClass || 'modal-default';

      angular.extend(modalScope, scope);

      return $uibModal.open({
        templateUrl: 'components/modal/modal.html',
        windowClass: modalClass,
        scope: modalScope,
        size:size,
        controller: controller
      });
    }

    // Public API here
    var publicAPI = {

      /* Confirmation modals */
      confirm: {

        /**
         * Create a function to open a delete confirmation modal (ex. ng-click='myModalFn(name, arg1, arg2...)')
         * @param  {Function} del - callback, ran when delete is confirmed
         * @return {Function}     - the function to open the modal (ex. myModalFn)
         */
        delete: function(playlist) {
            var scope= {
              modal: {
                dismissable: true,
                title: 'Delete playlist ' + playlist._source.name,
                deleteFromBox: playlist._source.box_public_url?"Y":"N",
                isInBox: playlist._source.box_public_url?true:false,
                html: `<div id="playlist_delete_popup_content">
                    <p style="font-size: 11px;margin-top: -15px;">Please confirm you wish to delete playlist <strong>` + name + `</strong>.<br><span style="color:#E16A66">This action cannot be undone.</span></p>
                    <md-checkbox ng-show="modal.isInBox" id="playlist_delete_check" md-no-ink ng-model="modal.deleteFromBox" style="position: relative; margin: 10px 0 -6px -25px;"
                        ng-true-value="'Y'" ng-false-value="'N'" aria-label="No Ink Effects"><p style="margin-top: 10px;font-size: 16px">Delete also from box</p></md-checkbox></div>`,
                buttons: [{
                  classes: 'btn-danger',
                  text: 'Delete',
                  click: function(e) {
                    deleteModal.close(e);
                  }
                }, {
                  classes: 'btn-default',
                  text: 'Cancel',
                  click: function(e) {
                    deleteModal.dismiss("cancel");
                  }
                }]
              }
            };

            var modalDeleteCtrl = function ($scope, $window, playlistsManager, playlistService, REST_BASE_URL) {

              $scope.confirm = function(e, data) {
                if(!data){
                  data = $scope.modal;
                }
                playlistService.deletePlaylist(playlist, (data.deleteFromBox=="Y"))
                  .then((data)=> {
                    playlistsManager.selectedPlaylist = {};
                    deleteModal.dismiss("Done");
                  }, (response) => {
                    if (response.status == 404) {
                      var w = 500;
                      var h = 700;
                      // var left = (this.window.innerWidth/2)-(w/2);
                      // var top = (this.window.innerHeight/2)-(h/2);
                      //TODO do redirection in nodejs
                      var url = REST_BASE_URL + "/auth/box/login?action=delete";
                      $window.open(url, "Box login", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h);
                    }
                  });
              }
              $scope.$on('modal.closing', function(event, reason, closed) {
                if (reason && typeof reason != "string"){//TODO only way I found to understand if has been pressed cancel or ok
                  event.preventDefault();
                  $scope.confirm(event, $scope.modal);
                }
              });
            };

            var deleteModal = openModal(scope, 'modal-delete',"md",modalDeleteCtrl);
          return deleteModal;
        },

        createPlaylist: function(action, playlistName) {
          var title = ""
          var okBtnText = "";
          switch (action) {
            case "rename":
              title = 'Rename playlist ' + playlistName;
              okBtnText = "Rename";
                  break;
            case "create":
              title = "Create new playlist";
              okBtnText = "Create";
                  break;
            case "duplicate":
              title = 'Copy playlist ' + playlistName;
              okBtnText = "Copy";
                  break;
          }
          var scope = {
            modal: {
              dismissable: true,
              title: title,
              html: `<div class="popup_content">
                  <p style="font-size: 11px;margin-top: -15px;margin-bottom: 10px;">Please provide a unique name for the playlist</p>
                  <p style="font-size: 11px;color: #de534a;margin: 0px 0px 24px 3px">{{modal.error}}</p>
                <md-input-container><label><p>New playlist name</p></label>
                <input id="txt_playlist_name" type="text" style="width: 236px;" ng-model="modal.playlistName"
                 ng-keydown="$event.which === 13 ? confirm($event,modal) : 0" ></md-input-container>`,
              buttons: [{
                classes: 'btn-danger',
                text: okBtnText,
                click: function(e, data) {
                  createModal.close(e, data);
                }
              }, {
                classes: 'btn-default',
                text: 'Cancel',
                click: function(e, data) {
                  createModal.dismiss("cancel");
                }
              }],
              backdrop: 'static',//TODO doens't work
              keyboard: false
            },
            action: action
          };
          var modalCreateCtrl = function ($scope, playlistsManager, playlistService) {
            var checkName = new RegExp(/[\/\\]/g);
            $scope.confirm = function(e, data) {
              if (data.playlistName && data.playlistName.length > 2
                && !checkName.test(data.playlistName)){
                var playlist;
                switch (action){
                  case "rename":
                    playlist = playlistsManager.selectedPlaylist
                    playlist._source.name = data.playlistName;
                    break;
                  case "create":
                    playlist = {_source:{name:data.playlistName}}
                    break;
                  case "duplicate":
                    playlist = playlistsManager.selectedPlaylist
                    playlist._source.name = data.playlistName;
                    delete playlist._id;
                    delete playlist._source.box_public_url;
                    break;
                }
                playlistService.updatePlaylist(playlist)
                  .then( function(response) {
                    playlistsManager.selectedPlaylist = response.data.result.hits.hits[0];
                    createModal.dismiss("Done");
                  })
                  .catch( function(err) {
                    if(err.status == 400){
                      data.error = 'A playlist with this name already exists';
                    }
                    if(err.status == 409){
                      playlistService.getPlaylist(playlist._id)
                        .then((result) => {
                          playlistsManager.selectedPlaylist  = result.data.result.hits.hits[0];
                          $scope.confirm(e,data);
                        },(error) => {
                          //TODO
                        });
                    }
                  });
              } else{
                data.error = 'The playlist name must be more than 2 characters long and should not contain special characters like ./\\';
              }
            }

            $scope.$on('modal.closing', function(event, reason, closed) {
              if (reason && typeof reason != "string"){//TODO only way I found to understand if has been pressed cancel or ok
                event.preventDefault();
                $scope.confirm(event, $scope.modal);
              }
            });
          };
          var createModal = openModal(scope, 'modal-create',"md",modalCreateCtrl);
          return createModal;
        },
        showProgress: function(playlist, status) {//TODO this is a service automatically generated,
          // not really convinced about putting too much html here
          var scope = {
            status: status,
            modal: {
              dismissable: true,
              title: 'Copying files to box',
              html: $sce.trustAsHtml(`
                  <span><p style="font-size: 11px">{{status.data.message}}</p></span>
                  <div class="row">
                    <div class="col-sm-11">
                      <uib-progressbar class="progress-striped active" max="100" value="status.data.progress" type="danger"><i></i></uib-progressbar>
                    </div>
                  </div>`),
              backdrop: 'static',//TODO doens't work
              keyboard: false
            }
          };
          var modalProgressCtrl = function ($scope, playlistsManager,playlistService,usersManager,$window) {
            $scope.$watch('status.data', function() {
              if($scope.status.data){
                if ($scope.status.data.progress < 100){
                  $scope.modal.dismissable= false  ;
                }else {
                  $scope.modal.dismissable = true;
                  if ($scope.status.data.status ==201) {
                    if (usersManager.userType === UsersManager.employee) {
                      var emailText = playlistsManager.createPlaylistTextEmail();
                      if (emailText.length <= 1400) {
                        $window.location.href = "mailto:?body=" + encodeURIComponent(emailText);
                      } else {
                        progress.close();
                        publicAPI.information.playlistEmailText(emailText);
                      }
                    }else{
                      status.data.message = "Sending playlist email..."
                      playlistService.sendPlaylistEmail(playlist)
                        .then(() => {
                          status.data.message = "Success! An email with the download link has been sent to your email address and will be with you soon"
                        },(status.data.message = "Unable to send the email, please try again later using the 're-send email' link in the playlist panel"))
                    }
                  }
                }
              }
            });
            $scope.$on('modal.closing', function(event, reason, closed) {
              if (reason=="backdrop click" || reason=="escape key press"){
                event.preventDefault();
              }
            });
          };
          var progress = openModal(scope, 'modal-login',"md",modalProgressCtrl)
          return progress;
        }

      },
      information:{
        message: function(title,message){
          // not really convinced about putting too much html here
          var infoModal;
          var scope = {
            message: message,
            modal: {
              dismissable: true,
              title: title,
              html: $sce.trustAsHtml(`
                  <span><p style="font-size: 11px">{{message}}</p></span>`),
              backdrop: 'static',//TODO doens't work
              buttons: [{
                classes: 'btn-default',
                text: 'Ok',
                click: function(e, data) {
                  infoModal.dismiss("cancel");
                }
              }]
            }
          };
          return infoModal = openModal(scope, 'modal-login',"md");
        },
        video: function(iframe) {
          // not really convinced about putting too much html here
          var scope = {
            modal: {
              dismissable: true,
              html: $sce.trustAsHtml('<div style="width:898px; height:600px">' + iframe +'</div>'),
              backdrop: "static",
              buttons: []
            }
          };

          var videoModal = openModal(scope, 'modal-video', 'lg');
          return videoModal;
        },
        map: function(track) {
          var getMapColor = function (value){
            if (value < 50){
              return "LOW";
            }else if(value < 100){
              return "MEDIUM";
            }else{
              return "HIGH";
            }
          }
          var chartOptions = {};
          var mapObject = {
            scope: 'world',
            projection: 'mercator',
            responsive:true,
            geographyConfig: {
              highlightBorderWidth: 2,
              // don't change color on mouse hover
              highlightFillColor: function(geo) {
                return geo.fillKey || '#F5F5F5';
              },
              // only change border
              highlightBorderColor: '#B7B7B7',
              popupTemplate: function(geo, data) {
                if (data){
                  return ['<div class="hoverinfo"><strong>',
                    geo.properties.name, '</br>UMPG rights share: ', data.percentage,
                    '%</strong></div>'].join('');
                }else{
                  return ['<div class="hoverinfo">',
                    '<strong>', geo.properties.name, '</strong>',
                    '</div>'].join('');
                }
              }
            },
            fills: {
              'HIGH': '#9ecf7f',
              'MEDIUM': '#dfe873',
              'LOW': '#fef376',
              'defaultFill': '#F0F2F2'
            }
          }
          var pubRights = track.nouspub_rights
          var usRights = track.uspub_umpg_shares;
          var data = {};
          if (pubRights) {
            for (var i = 0; i < pubRights.length; i++) {
              data[trackService.ISO3CountryCodes[pubRights[i].country_code]] = {
                "fillKey": getMapColor(pubRights[i].mechanicals),
                percentage: pubRights[i].mechanicals
              }
            }
          }
          if (usRights){
            data.USA = {"fillKey": getMapColor(usRights),
              percentage: usRights};
          }
          mapObject.data = data;

          var scope = {
            modal: {
              dismissable: true,
              backdrop: "static",
              buttons: []
            },
            mapConfig: mapObject,
            track:track,
            chartOptions: chartOptions,
            chartColors: ["#E16A66","#45545B","#1b998b","#1282a2","1b998b"]
          };
          chartOptions.labels = [];
          chartOptions.data = [];
          if (track.uspub_publishers){
            track.uspub_publishers.forEach((item)=>{
              chartOptions.labels.push(item.name);
              chartOptions.data.push(item.share)
            })
            chartOptions.options= {
              tooltips: {
                bodyFontSize:9
              },
              legend: {
                display:(track.uspub_publishers.length < 8),
                position:'bottom',
                labels: {
                  boxWidth:10,
                  fontSize:8
                }
              }
            }
          }
          var modalScope = $rootScope.$new();

          angular.extend(modalScope, scope);

          return $uibModal.open({
            templateUrl: 'components/modal/modal-map.html',
            windowClass: "modal-map",
            scope: modalScope
          });

        },
        playlistEmailText: function(text) {
          // not really convinced about putting too much html here
          var scope = {
            modal: {
              dismissable: true,
              title: "Playlist track listing",
              html: $sce.trustAsHtml(`<div class="popup_content">
                  <p style="font-size: 11px;margin-top: -15px;margin-bottom:5px;">Please use the button by the right to copy the track list</p>
                  <span id="btn_copy_email_text" 
                              class="fa fa-copy"
                              style="float: right;font-size: 22px;margin:-27px 16px 9px 0px"
                              uib-tooltip='Copy to clipboard'
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'
                              ngclipboard data-clipboard-target="#txt_email_text"></span>
                    <textarea id="txt_email_text" 
                    style="height: 300px;width: 533px;">` + text +`</textarea>
                  <p style="font-size: 11px;margin-top: 15px;margin-bottom: -32px;"><strong>Why Am I seeing this?</strong><br/>The content of this email is too long to be handled automatically by the browser. You can 
                  change the text above or leave it as it is and when ready hit the copy button at the top right to copy the text in memory. <br/>Done? You can now paste it directly in your email client!</p>
                  `),
              backdrop: "static",
              buttons: []
            }
          };

          var playlistModal = openModal(scope);
          return playlistModal;
        }


      }
    };
    return publicAPI
  });
