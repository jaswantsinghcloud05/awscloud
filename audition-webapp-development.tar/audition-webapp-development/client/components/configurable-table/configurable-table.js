
'use strict';
/**
 *
 * TODO replace all scopes with instance variables like this.tracks
 *
 * */

class CustomTrackTableCtrl {
  constructor($scope, playlistService, trackService, keysManager, tracksManager, $localStorage){
    this.maxInitilized = false;
    this.trackInPlay;
    this.selectedTrack = $scope.selectedTrack;
    this.selectedIdx = $scope.selectedIdx;
    this.trackService  = trackService;
    this.keysManager = keysManager;
    this.tracksManager = tracksManager;
    $scope.trackColumnsList = ["average_loudness","dynamic_complexity","canopus_id","download_rights","formatted_title","genre_blues","genre_classical","genre_electronica","genre_jazz","genre_latin","genre_metal_punk","genre_rap","genre_reggae",
      "genre_pop_rock","genre_rnb","genre_soul_funk","harmonic_key","harmonic_mode","instrumentation_heavy_rock_metal_drumkit","instrumentation_jazz_country_soul_drumkit","instrumentation_light_pop_rock_drumkit","instrumentation_electronic_drumkit",
      "instrumentation_acoustic_guitar","instrumentation_electric_guitar" ,"instrumentation_acoustic","instrumentation_strings_orchestra","instrumentation_brass","instrumentation_electronic","instrumentation_piano","isrc","mood_calm","mood_dynamic","mood_sad","mood_happy","mood_romantic",
      "length","release_date","resource_rollup_id", "rhythm_bpm_mean","rhythm_bpm_std","rhythm_complexity","rhythm_meter","rhythm_percussivity","rhythm_periodicity","rhythm_speed_a","rhythm_speed_b","stream_rights","sync_rights","talent_id","talent_name","territorial_rights",
      "timbre_bright","tonality_tonal","track_genre","version_title"];

    $scope.tracksTable = {};
    $scope.tracksTable.column1 = "formatted_title";
    $scope.tracksTable.column2 = "talent_name";
    $scope.tracksTable.column3 = "track_genre";
    $scope.tracksTable.column4 = "rhythm_bpm_mean";
    $scope.tracksTable.column5 = "harmonic_key";
    $scope.tracksTable.column6 = "harmonic_mode";
    $scope.tracksTable.column7 = "territorial_rights";
    $scope.tracksTable.column8 = "release_date";

    //TODO apparently it doesn't work on the controller scope. Also create services
    //to handle events (http://stackoverflow.com/questions/24830679/why-do-we-use-rootscope-broadcast-in-angularjs)
    $scope.$on("trackListUpdated", (event, tracks) => {
      if (this.trackInPlay && this.trackInPlay.playing) {
        stopPlayBack(this.trackInPlay);
      }
      this.tracks = tracks;
      this.selectedTrack = undefined;
      this.selectedIdx = undefined;
    })

    $scope.$on("playlistSelected", (event) => {
      var playlistConf = $localStorage[$rootScope.playlistName];
      if (playlistConf && playlistConf.columns){
        $scope.tracksTable.column1 = playlistConf.columns[0];
        $scope.tracksTable.column2 = playlistConf.columns[1];
        $scope.tracksTable.column3 = playlistConf.columns[2];
        $scope.tracksTable.column4 = playlistConf.columns[3];
        $scope.tracksTable.column5 = playlistConf.columns[4];
        $scope.tracksTable.column6 = playlistConf.columns[5];
        $scope.tracksTable.column7 = playlistConf.columns[6];
        $scope.tracksTable.column8 = playlistConf.columns[7];
      }else {
        $scope.tracksTable.column1 = "formatted_title";
        $scope.tracksTable.column2 = "talent_name";
        $scope.tracksTable.column3 = "track_genre";
        $scope.tracksTable.column4 = "rhythm_bpm_mean";
        $scope.tracksTable.column5 = "harmonic_key";
        $scope.tracksTable.column6 = "harmonic_mode";
        $scope.tracksTable.column7 = "territorial_rights";
        $scope.tracksTable.column8 = "release_date";
      }
    })
  }

  onTrackRowSelect(idx, track) {
    //TODO find a better place where doing this
    if (track != this.selectedTrack) {
      if (this.selectedIdx!=undefined && this.keysManager.isShiftDown()){
        var max,min;
        if(this.selectedIdx>idx){
          max = this.selectedIdx-1;
          min = idx;
        }else{
          min = this.selectedIdx+1;
          max = idx;
        }
        for(var i = min; i<=max; i++){
          this.tracks[i].selected = true;
        }
      }else if(this.selectedIdx!=undefined && this.keysManager.isCtrlDown()){
        track.selected = !track.selected;
      }else{
        track.largeThumbnailUrl = "/api/tracks/" + track.isrc + "/assets/thumbnail-large"
        for(var i = 0; i<this.tracks.length; i++){
          this.tracks[i].selected = false;
        }
        this.tracksManager.selectedTrack(track);
        track.selected = true;
        this.maxInitilized = false;
        this.selectedIdx = idx;
        //load all playlist tags
        this.trackService.findByIsrc(track.isrc)
          .then(function(data){
            track.playlist_tags = data.data.playlist_tags;
          })
      }
    }

  }

  onColumnHeaderChanged(){
    if (!$localStorage[$rootScope.playlistName]){
      $localStorage[$rootScope.playlistName] = {};
    }
    var localPlaylistConf = $localStorage[$rootScope.playlistName];
    localPlaylistConf.columns = [];
    localPlaylistConf.columns.push($scope.tracksTable.column1);
    localPlaylistConf.columns.push($scope.tracksTable.column2);
    localPlaylistConf.columns.push($scope.tracksTable.column3);
    localPlaylistConf.columns.push($scope.tracksTable.column4);
    localPlaylistConf.columns.push($scope.tracksTable.column5);
    localPlaylistConf.columns.push($scope.tracksTable.column6);
    localPlaylistConf.columns.push($scope.tracksTable.column7);
    localPlaylistConf.columns.push($scope.tracksTable.column8);
  }


  onTrackFlagClick(track){
    for (var i=0; i<track.playlist_tags.length; i++){
      if ($rootScope.playlistName==track.playlist_tags[i].name) {
        if (track.playlist_tags[i].flagged==undefined){
          track.playlist_tags[i].flagged = false;
        }
        playlistService.setTrackFlagged($rootScope.playlistName, track, !track.playlist_tags[i].flagged)
          .then(function (data) {
            track.playlist_tags[i].flagged = !track.playlist_tags[i].flagged;
          }, function (data, status, headers, config) {
            //TODO do something in case of error
          });
        break;
      }
    }
  }

}

class CustomizableTrackTableComponent {

  constructor() {
    this.scope = {
      selectedTrack: "=selectedTrack",
      selectedIdx: "=selectedIdx"
    };
    this.templateUrl = "/components/configurable-table/configurable-table.html";
    this.replace = true;
    this.controller = 'CustomTrackTableCtrl';
    this.controllerAs = 'ctrl';
  }
}

register('auditionApp').directive('configurableTrackTable', CustomizableTrackTableComponent);
register('auditionApp').controller('CustomTrackTableCtrl', CustomTrackTableCtrl);

