
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class AlbumContextCtrl {
  constructor($scope, $rootScope, $stateParams, $timeout, Modal, urlStatusManager,
              tracksManager,albumsManager,playlistsManager, messagingService){
    this.rootScope = $rootScope;
    this.scope = $scope;
    this.tracksManager = tracksManager;
    this.albumsManager = albumsManager;
    this.playlistsManager = playlistsManager;
    this.urlStatusManager = urlStatusManager;
    this.messagingService = messagingService;
    this.timeout = $timeout;
    this.modal = Modal;
    this.selectedAlbum = this.albumsManager.selectedAlbum;
    this.albumLength = 0;

    $scope.$on(MessagingService.albumUpdated, (event) => {
      this.selectedAlbum = this.albumsManager.selectedAlbum;

      this.tracks = this.tracksManager.currentTracks;
      this.tracks.forEach((item)=>{
        this.albumLength += item._source.length;
      })
    })

    $scope.$on(MessagingService.urlChanged, (event) => {
      this.selectTab();
      this.timeout(() =>{
        //TODO need to wait the new tab is selected
        this.messagingService.broadcast(MessagingService.tabSelected);//TODO use RxJs
      }, 100);
    })
    this.selectTab();
  }

  selectTab(){
    switch (this.urlStatusManager.status.tab) {
      case "albumTracks":
        this.selectedIndex = 0;
        break;
      case "albumVersions":
        this.selectedIndex = 1;
        break;
      case "albumAbout":
        this.selectedIndex = 2;
        break;
    }
  }

  onTabSelected(tabName){
    this.urlStatusManager.status.tab = tabName;
    this.urlStatusManager.updateUrl("/album-context");//TODO make this call automatic in USM when the status is update
  }

  onReturnToFullCatalogClick(){
    this.urlStatusManager.status.tab = "tracks";
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.filters.match.upc = undefined;
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.updateUrl("/tracks-filters");//TODO make this call automatic in USM when the status is update
  }

  addTracksToPlaylist(tracks){

    var selectedPlaylist = this.playlistsManager.selectedPlaylist;
    var track = tracks[0]._source;
    if (!selectedPlaylist.tracks) selectedPlaylist.tracks = [];
    track.position = selectedPlaylist.tracks.length;
    var promise = this.playlistsManager.addTrackToCurrentPlaylist(track)
      .then((data) =>{
        if (tracks.length>1) {
          return this.addTracksToPlaylist(tracks.slice(1));
        }else{
          return promise
        }
      }).catch((error)=>{
        return promise;
      })
  }

  onAddAlbumToCurrentPlaylistClick(){
    var selectedPlaylist = this.playlistsManager.selectedPlaylist;
    if (angular.equals({},selectedPlaylist)) {
      this.modal.confirm.createPlaylist("create");
    }else{
      if(selectedPlaylist){
        var playlistTracks = selectedPlaylist._source.tracks;
        var tracks = this.tracksManager.currentTracks;
        var sanitizedTracks = [];
        if (playlistTracks && playlistTracks.length>0){
          for(var i=0; i< tracks.length; i++){
            var found = false;
            for(var j=0; j< playlistTracks.length; j++) {
              if (tracks[i]._source.r2_resource_id == playlistTracks[j].r2_resource_id){
                found = true;
                break;
              }
            }
            if (!found){
              sanitizedTracks.push(tracks[i]);
            }
          }
        }else{
          sanitizedTracks = tracks;
        }

        if (sanitizedTracks.length >0) this.addTracksToPlaylist(sanitizedTracks).then((data) => {
          this.selectedPlaylist = data.data.result.hits.hits[0];
          this.messagingService.broadcast(MessagingService.playlistSelected);//TODO maybe us a specific message for update
        })
      }else{
        this.rootScope.playlistCheck = true;
      }
    }
  }
}

let AlbumContextComponent = {

    binding : {},
    controller : 'AlbumContextCtrl',
    controllerAs : 'ctrl',
    //todo check why templeUrl not working after grunt build
    template : `
                <div id="album_context" style="overflow-x: hidden;position:relative;left: 25px;top:-76px">
                  <div id="context_wrapper"><img http-src="{{ctrl.selectedAlbum.thumbnail_large_filename}}" id="context_image">
                    <h2 class="win-scroll">{{ctrl.selectedAlbum.formatted_title}}</h2>
                    <p class="standard_text">Duration {{ctrl.albumLength | secondsToDateTime | date:'HH:mm:ss'}}&nbsp;&nbsp;|&nbsp;&nbsp;Year {{ ctrl.selectedAlbum.p_notice_year}} 
                      <md-menu id="context_menu">
                        <md-button id="context_menu_button" ng-click="$mdMenu.open($event)" class="md-icon-button">
                            <i class="material-icons">more_vert</i>
                        </md-button>
                        <md-menu-content>
                            <md-menu-item>
                                <md-button ng-disabled="true">Instant Export</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-disabled="true">Show Filtered Albums</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-click="ctrl.onAddAlbumToCurrentPlaylistClick()">Add album to current playlist</md-button>
                            </md-menu-item>
                               <md-menu-item>
                                <md-button ng-click="ctrl.onReturnToFullCatalogClick()">Return to Full Catalogue</md-button>
                            </md-menu-item>
                        </md-menu-content>
                      </md-menu>
                    </p>
                  </div>
                  <md-content style="background-color: white;">
                    <md-tabs md-selected="ctrl.selectedIndex" md-dynamic-height="" md-no-pagination="true" md-enable-disconnect="true">
                      <md-tab ng-click='ctrl.onTabSelected("albumTracks")'>
                        <md-tab-label>
                          Track Listing
                        </md-tab-label>
                        <md-tab-body>
                          <album-tracks></album-tracks>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-click='ctrl.onTabSelected("albumVersions")'>
                        <md-tab-label>
                          Versions
                        </md-tab-label>
                        <md-tab-body>
                          <fix-album-table tab-id="'albumVersions'"></fix-album-table>
                        </md-tab-body>
                      </md-tab>
                      <!--<md-tab ng-click='ctrl.onTabSelected("albumAbout")'>
                        <md-tab-label>
                          About
                        </md-tab-label>
                        <md-tab-body>
                          <Album-videos></Album-videos>
                        </md-tab-body>
                      </md-tab>-->
                    </md-tabs>
                  </md-content>
                </div>
              `
}

angular.module('auditionApp').component('albumContext', AlbumContextComponent);
angular.module('auditionApp').controller('AlbumContextCtrl', AlbumContextCtrl);

