
'use strict';
/**
 * This file contains view and controller of the track-versions directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 *
 * TODO the table component could be extracted and merged with fix-tracks-table
 * */

class AlbumTracksCtrl extends FixTrackTableCtrl{
  constructor($scope, $rootScope, playlistsManager, trackService, tracksManager,
              keysManager, paginationManager, urlStatusManager, Modal,
              albumsManager, usersManager, AMPLIFY_URL){
    super($scope, $rootScope, playlistsManager, trackService, tracksManager,
      keysManager, paginationManager, urlStatusManager, Modal, albumsManager,
      usersManager, AMPLIFY_URL)
    this.albumsManager = albumsManager;
    $scope.$on(MessagingService.trackListUpdated, (event) => {
      this.tracks = this.tracksManager.currentTracks;
      this.tracks.sort((track1, track2) => {
        var upc = this.albumsManager.selectedAlbum.upc;
        var album1 = track1._source.albums.find((item) => {
          return upc == item.upc
        })
        var album2 = track2._source.albums.find((item) => {
          return upc == item.upc
        })
        return (album1.package_sequence_number*100 + album1.track_sequence_number) > (album2.package_sequence_number*100 + album2.track_sequence_number) ? 1 : -1
      })
    })
  }

  loadTracks() {
    if (this.currentCriteria !== this.urlStatusManager.urlStatus.filters && this.urlStatusManager.urlStatus.tab == "albumTracks") {
      angular.copy(this.urlStatusManager.urlStatus.filters, this.currentCriteria);
      this.tracksManager.applyNewFilters();
    }
  }

  getTrackNumber(track) {
    var album =  track.albums.find((item) => {
      return this.albumsManager.selectedAlbum.upc == item.upc
    })
    if (album) return album.track_sequence_number
  }

  getPackageNumber(track) {
    var album =  track.albums.find((item) => {
      return this.albumsManager.selectedAlbum.upc == item.upc
    })
    if (album) return album.package_sequence_number
  }


}

let AlbumTracksComponent = {


  binding : {},
  controller : 'AlbumTracksCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="tracks_list_tbl" class="table album-tracks">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th>
                       <div style="display:flex;margin-top: -17px;">
                       <i id="rights_tab_btn" class="fa fa-copyright ng-scope" style="margin-top: 23px; margin-right: -2px;" aria-hidden="true"></i>
                       <md-switch class="_md-thumb" ng-model="ctrl.metaData" aria-label="filter_toggle" ng-true-value="true" ng-false-value="false"
                       style="height: 0px; width:37px"> </md-switch>
                          <md-tooltip md-direction="left">{{ctrl.metaData ? "Metadata" : "Rights"}}</md-tooltip>
                       <i id="metadata_tab_btn" class="fa fa-microphone ng-scope" style="margin-top: 23px; margin-left: -2px;" aria-hidden="true"></i>
                    </div>
                    </th>
                    <th>Cd</th><!--ng-click="ctrl.toggleSort('track_sequence_number')" -->
                    <th>Tr</th><!--ng-click="ctrl.toggleSort('track_sequence_number')" -->
                    <th>Title</th><!--ng-click="ctrl.toggleSort('formatted_title')" -->
                    <th>Artist</th><!--ng-click="ctrl.toggleSort('canopus_artist_name')"  -->
                    <th>Year</th><!-- -->
                    <th>Duration</th><!-- -->
                    <th>Label</th><!-- ng-click="ctrl.toggleSort('popularity')" -->
                    <th>UMG Genre</th>
                    <th>{{!ctrl.metaData ? "Publish" : "Ed/Ex"}}</th>
                    <th>{{!ctrl.metaData ? "Record" : "Vox/Inst"}}</th>
                    <th><span ng-show="!ctrl.metaData">Territory</span><a ng-show="ctrl.metaData" href="#" ng-click="ctrl.toggleSort('rhythm_bpm_mean')" class="column-header">Speed(BPM)</a></th>
                  </tr>
                  </thead>
                  <tbody class="table-hover noselect">
                  <tr ng-repeat="item in ctrl.tracks"
                      ng-class="(item.selected==true)?'row-selected':''"
                      ng-click="ctrl.onTrackRowSelect($index, item._source)">
                    <td>
                      <div style="display:flex;">
                        <span id="btn_add_track_to_playlist_{{item._source.r2_resource_id}}" 
                              class="glyphicon glyphicon-plus-sign"
                              style="margin-right: 4px;font-size: 15px;"
                              ng-click="ctrl.onAddToPlaylistClick(item._source);$event.stopPropagation()"></span>
                        <div ng-click="ctrl.onStartPlayingClick(item)"
                             uib-tooltip='Play 30 sec clip'
                             tooltip-placement="top"
                             tooltip-trigger="mouseenter"
                             tooltip-popup-delay='1000'>
                          <knob-player track="item._source" knob-max='max'
                                knob-options="knobOptions" html-id="track_knob_{{item._source.r2_resource_id}}"></knob-player>
                        </div>
                        <span id="track-play-icon" ng-click="ctrl.onTrackPlayClick($index, item._source)"
                           class="fa fa-play" style="margin: 2px 3px 0px -15px;">
                        </span>
                        <img ng-show="ctrl.isAmplifyUser" src="assets/images/amplify_logo.svg" ng-click="ctrl.onSendToAmplifyClick(item._source)"
                          class="amplify_button" ng-class="{'amplify-spinning': item._source.imageSpinning==true}">
                      </div>
                    </td>
                    <td id="td_number_{{item._source.r2_resource_id}}">
                    <span>{{ctrl.getPackageNumber(item._source)}}</span></td>
                    <td id="td_number_{{item._source.r2_resource_id}}">
                    <span>{{ctrl.getTrackNumber(item._source)}}</span></td>
                    <td>
                    <span uib-tooltip="{{item._source.formatted_title}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'><a id="a_title_{{item._source.r2_resource_id}}" ng-click="ctrl.onTrackInfoClick($index, item._source)">{{item._source.formatted_title}}</a></span></td>
                    <td id="td_artist_name_{{item._source.r2_resource_id}}">
                      <span uib-tooltip="{{item._source.artist_name}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'><a id="a_artist_{{item._source.r2_resource_id}}" ng-click="ctrl.onArtistInfoClick($index, item._source)">{{item._source.artist_name}}</a></span></td>
                    <td id="td_release_{{item._source.r2_resource_id}}">{{ item._source.release_date | date : 'yyyy'}}</td>
                    <td id="td_length_{{item._source.r2_resource_id}}">{{item._source.length | secondsToDateTime | date:'HH:mm:ss'}}</td>
                    <td id="td_label_{{item._source.r2_resource_id}}">
                      <span uib-tooltip="{{item._source.label_name}}">{{ item._source.label_name}}</span></td>
                    <td><span uib-tooltip="{{item._source.track_genre}}"
                             tooltip-placement="top"
                             tooltip-trigger="mouseenter"
                             tooltip-popup-delay='1000'>{{ item._source.track_genre}}</span></td>
                    <td>
                    <span ng-show="ctrl.metaData"></span>
                    <span ng-show="!ctrl.metaData" 
                                          uib-tooltip="{{ctrl.formatPublishers(item._source)}}"
                                          tooltip-class="fontSmallClass"
                                          tooltip-placement="top"
                                          tooltip-trigger="mouseenter"
                                          tooltip-popup-delay='1000'
                                          tooltip-append-to-body="true"
                                          style="text-align: center;">{{ctrl.getRightsShare(item._source)}}</span></td>
                    <td>
                    <span ng-show="ctrl.metaData"></span>
                    <div ng-show="!ctrl.metaData" style="min-width: 68px;">
                      <right-icons track="item"></right-icons>
                    </div>
                    </td>
                    <td>
                      <div ng-show="ctrl.metaData" style="text-align: center;margin-left: -17px;">{{ item._source.rhythm_bpm_mean | number : 0}}</div>
                      <span ng-show="!ctrl.metaData" uib-tooltip="{{item._source.territorial_right}}"
                                          tooltip-placement="top"
                                          tooltip-trigger="mouseenter"
                                          tooltip-popup-delay='1000'>
                          <!-- make a filter instead of conditions -->
                        <span ng-show='(item._source.territorial_right.indexOf("World")>=0 || item._source.territorial_right.indexOf("Universe")>=0)
                        && item._source.territorial_right.indexOf("Excluding")<0'>
                        World</span>
                        <span ng-show='(item._source.territorial_right.indexOf("World")>=0 || item._source.territorial_right.indexOf("Universe")>=0)
                        && item._source.territorial_right.indexOf("Excluding")>0'>
                        World Excludes</span>
                        <span ng-show='item._source.territorial_right.indexOf("World")<0 && item._source.territorial_right.indexOf("Universe")<0'>
                        Country</span>
                      </span>
                    </td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              `
}

angular.module('auditionApp').component('albumTracks', AlbumTracksComponent);
angular.module('auditionApp').controller('AlbumTracksCtrl', AlbumTracksCtrl);

