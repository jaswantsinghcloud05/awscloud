
'use strict';
/**
 * This file contains view and controller of the Album details component.
 * */

class AlbumInfoCtrl {
  constructor($scope, $rootScope, albumsManager, urlStatusManager) {
    this.rootScope = $rootScope;
    this.albumsManager = albumsManager;
  }
}

let AlbumInfoComponent = {

  binding : {},
  controller : 'AlbumInfoCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div class="sl-track-div">
                <div class="container-fluid">
                  <div class="scrollable-wrapper">
                    <p class="standard-text"> {{ctrl.albumsManager.selectedAlbum.wiki}}
                    <a ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'wikipedia'}| limitTo:1" ng-href="{{item.url}}" target="_blank">..Read more on Wikipedia</a>
                    </p>
                    <ul id="album_link_logos">
                      <li aria-label="Official Website">
                      <a id="a_official_site" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'official homepage'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/albumsite.svg" 
                        uib-tooltip='Official Website'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Wikipedia">
                      <a id="a_wiki" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'wikipedia'}| limitTo:1" 
                      ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/wikipedia.svg" 
                        uib-tooltip='Wikipedia'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="MusicBrainz">
                      <a id="a_musicbrainz" href="https://musicbrainz.org/album/{{ctrl.albumsManager.selectedAlbum.musicbrainz_id}}"
                        target="_blank"><img http-src="/assets/images/musicbrainz.svg" 
                        uib-tooltip='MusicBrainz'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Discogs">
                      <a id="a_discogs" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'discogs'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/discogs.svg" 
                        uib-tooltip='Discogs'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="All Music">
                      <a id="a_allmusic" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'allmusic'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/allmusic.svg" 
                        uib-tooltip='All Music'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Who Sampled">
                      <a id="a_whosampled" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url: 'whosampled'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/whosampled.svg" 
                        uib-tooltip='Who Sampled'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Last.fm">
                      <a id="a_lastfm" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url_type: 'last.fm'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/lastfm.svg"
                        uib-tooltip='Last.fm'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Genius">
                      <a id="a_genius" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url: 'genius'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/genius.svg" 
                        uib-tooltip='Genius'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Facebook">
                      <a id="a_facebook" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url: 'facebook'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/facebook.svg" 
                        uib-tooltip='Facebook'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                      <li aria-label="Twitter">
                      <a id="a_twitter" ng-repeat="item in ctrl.albumsManager.selectedAlbum.profiles| filter: {url: 'twitter'}| limitTo:1"
                        ng-href="{{item.url}}" target="_blank"><img http-src="/assets/images/twitter.svg" 
                        uib-tooltip='Twitter'
                        tooltip-placement="top"
                        tooltip-trigger="mouseenter"
                        tooltip-popup-delay='1000'></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              `
}

angular.module('auditionApp').component('albumInfo', AlbumInfoComponent);
angular.module('auditionApp').controller('AlbumInfoCtrl', AlbumInfoCtrl);

