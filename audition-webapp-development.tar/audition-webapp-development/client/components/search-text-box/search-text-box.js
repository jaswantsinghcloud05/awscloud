
'use strict';
class SearchBoxCtrl {
  constructor($rootScope, $scope, urlStatusManager, trackService, tracksManager, artistService, artistsManager,
              albumService, albumsManager, usersManager, $q){
    this.trackService  = trackService;
    this.artistService  = artistService;
    this.albumService = albumService;
    this.artistsManager = artistsManager;
    this.tracksManager = tracksManager;
    this.albumsManager = albumsManager;
    this.urlStatusManager = urlStatusManager;
    this.usersManager = usersManager;
    this.searchModel = "";
    this.q = $q
    this.queryString = "";
    $scope.$on(MessagingService.filtersReset, (event, data) => {
      this.searchModel = "";
    });
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.urlChanged, (event) => {
      this.searchModel = this.urlStatusManager.status.filters.query;
    })
    this.searchModel = this.urlStatusManager.status.filters.query;
    this.modelOptions = {
      debounce: {
        default: 400,
        blur: 0
      },
      getterSetter: true
    };
  }

  search(val) {

    if (val.length >= 2 ){
      var deferred = this.q.defer();
      var promise = this.q.all([this.artistService.searchByAlias(val), this.trackService.getSuggestionsByQuery(val),
        this.albumService.searchByAlbumName(val)])
        .then((response) =>{
          var isFirst = true;
          //ARTISTS
          var artists = response[0].data.hits.hits.map(function (item) {
            var artist = {name: item._source.default_name,
              canopus_id: item._source.canopus_id};
            return artist;
          });
          //Adds group title
          artists.unshift({name: "Artists", group: "artists", disabled:true})

        //TRACKS
          var tracks = [];
          if (response[1].data){
            tracks = response[1].data.hits.hits.map(function (item) {
              var track = { name: item._source.formatted_title + ' (' + item._source.artist_name + ')',
                track : item._source};
              return track;
            });
          }
          tracks.unshift({name: "show all tracks  >>", group: "tracks"})

        //ALBUMS
          var albums = response[2].data.hits.hits.map(function (item) {
            var album = { name: item._source.formatted_title  + " (year " + item._source.p_notice_year + ")",
              album : item._source};
            return album;
          });
          albums.unshift({name: "Albums", group: "albums", disabled: true})

          var searchList = [];
          return searchList.concat(artists.concat(tracks).concat(albums))
        });
      return promise;
    }else {
      return null;
    }
  }

  onSearchSelected($item, $model, $event) {
    this.queryString = $event.currentTarget.value;
    if ($model.group == "tracks") {
      this.trackService.searchCriteria.query = this.queryString;
      this.trackService.searchCriteria.boolean = false;
      this.trackService.searchCriteria.match.canopus_id = undefined;
      this.trackService.searchCriteria.match.resource_rollup_id = undefined;
      this.urlStatusManager.status.tab = $model.group;
      this.urlStatusManager.updateUrl("/tracks-filters");
    } else if ($model.disabled) {
      this.trackService.searchCriteria.query = this.queryString;
      this.trackService.searchCriteria.boolean = true;
      this.trackService.searchCriteria.match.canopus_id = undefined;
      this.trackService.searchCriteria.match.resource_rollup_id = undefined;
      this.urlStatusManager.status.tab = "tracks";
      this.urlStatusManager.updateUrl("/tracks-filters");
    } else {
      this.trackService.searchCriteria.query = this.queryString;
      this.trackService.searchCriteria.boolean = false;
      if ($model.canopus_id) {
        this.trackService.searchCriteria.match.upc = undefined;
        this.trackService.searchCriteria.match.canopus_id = $model.canopus_id;
        this.trackService.searchCriteria.match.resource_rollup_id = undefined;
        this.urlStatusManager.status.tab = "artistTracks";
        this.urlStatusManager.updateUrl("/artist-context");
      } else if ($model.album) {
        this.trackService.searchCriteria.match.upc = $model.album.upc;
        this.trackService.searchCriteria.match.canopus_id = undefined;
        this.trackService.searchCriteria.match.resource_rollup_id = undefined;
        this.urlStatusManager.status.tab = "albumTracks";
        this.albumsManager.selectedAlbum = $model.album;
        this.searchModel = this.queryString;
        this.urlStatusManager.updateUrl("/album-context");
      } else {
        this.trackService.searchCriteria.match.upc = undefined;
        this.trackService.searchCriteria.match.canopus_id = undefined;
        this.trackService.searchCriteria.match.resource_rollup_id = $model.track.resource_rollup_id;
        this.urlStatusManager.status.tab = "trackVersions";
        this.urlStatusManager.status.selectedTrack = $model.track.r2_resource_id;
        this.tracksManager.selectedTrack = $model.track;
        this.searchModel = this.queryString;
        this.urlStatusManager.updateUrl("/track-context");
      }
    }
    this.searchModel = this.queryString;
  };

  onSearchBoxKeyUp($event){
    if ($event.keyCode == 13) {
      window.setTimeout(function(){
          angular.element(document.querySelector('#clear_bool_search_btn')).focus() }
        , 1000);
      this.queryString = $event.currentTarget.value
      this.trackService.searchCriteria.query = this.queryString;
      this.trackService.searchCriteria.boolean = true;
      this.trackService.searchCriteria.match.canopus_id = undefined;
      this.trackService.searchCriteria.match.r2_resource_id = undefined;
      this.trackService.searchCriteria.match.resource_rollup_id = undefined;
      this.trackService.searchCriteria.match.upc = undefined;
      this.urlStatusManager.status.tab = "tracks";
      this.urlStatusManager.updateUrl("/tracks-filters");
      this.searchModel = this.queryString;
    }else{
      this.queryString = this.searchModel;
    }
  }

  onClearSearch() {
    if (this.searchModel){
      this.searchModel="";
      this.artistsManager.selectedArtist = undefined;
      this.trackService.searchCriteria.match.canopus_id = undefined;
      this.trackService.searchCriteria.match.r2_resource_id = undefined;
      this.trackService.searchCriteria.match.upc = undefined;
      this.trackService.searchCriteria.query = undefined;
      this.trackService.searchCriteria.match.resource_rollup_id = undefined;
      this.urlStatusManager.status.tab = "tracks";
      this.urlStatusManager.updateUrl("/tracks-filters");
    }
  }

}

class SearchBoxComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'SearchBoxCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div class="toolbar_search_wrapper">
          <form role="search">
            <div>
              <script type="text/ng-template" id="allin-typeahead-item.html">
                <div class="typeahead-group-header" ng-if="match.model.disabled">{{match.label}}</div>
                <a ng-if="!match.model.disabled" ng-class="match.model.group?'typeahead-group-header':'typeahead-drop-item'" >
                  <span ng-bind-html="match.label | uibTypeaheadHighlight:query"></span>
                </a>
              </script>
              <i ng-show="loadingSearch && ctrl.searchModel.length>=2" class="fa-li fa fa-spinner fa-spin"
                 style="top: 5px;color: black; left: 394px;"></i>
              <input id="bool_search_text" type="text" ng-model="ctrl.searchModel" ng-model-options="ctrl.modelOptions" 
                     placeholder="Search for..."
                     uib-typeahead="item as item.name for item in ctrl.search($viewValue)"
                     typeahead-loading="loadingSearch"
                     typeahead-template-url="allin-typeahead-item.html"
                     typeahead-on-select='ctrl.onSearchSelected($item, $model, $event)'
                     typeahead-show-hint="true",
                     typeahead-wait-ms="500",
                     typeahead-select-on-blur="true",
                     ng-keyup="ctrl.onSearchBoxKeyUp($event)"
                     style="width: 405px"><!--todo there is a style class for this but doesn't work on aws-->
            </div>
          </form>
          <div id="clear_bool_search_btn" class="cancel_search" ng-click="ctrl.onClearSearch()"><i class="material-icons">&#xe14c;</i></div>
        </div>`;
  }
}

register('auditionApp').directive('searchBox', SearchBoxComponent);
register('auditionApp').controller('SearchBoxCtrl', SearchBoxCtrl);

