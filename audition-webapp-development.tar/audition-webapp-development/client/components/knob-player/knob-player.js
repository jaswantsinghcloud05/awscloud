'use strict';

/**
 * Created by davide on 18/01/2016.
 */
class KnobPlayerCtrl {

  constructor(ngAudio, $timeout, $scope, tracksManager, messagingService) {
    ngAudio.setUnlock(false);
    this.ngAudio = ngAudio;
    this.timeout = $timeout;
    this.messagingService = messagingService;
    this.maxInitilized = false;
    this.max = 30;
    //TODO defaults to be overridden if passed in scope
    this.knobOptions = {
      'width': 15,
      'height': 15,
      'fgColor': '#DF6C64',
      'bgColor': 'black',
      'thickness': .15,
      'displayInput': false,
      'readOnly': true,
      'step': .2
    }
    this.scope = $scope;
    this.track = $scope.song;
    if (this.scope.autoStop != false) {
      $scope.$on(MessagingService.knobPlayerPlaying, (args, trackInPlay) => {
        if (this.track && this.track.playing && trackInPlay !== this.track) {
          this.stopPlayBack();
        }
      })
    }
    $scope.$on(MessagingService.trackFiltersUpdated, (event) => {
      if (this.track && this.track.playing) {
        this.stopPlayBack();
      }
    })

    $scope.$on(MessagingService.audioPlaying, (event) => {
      if (this.track && this.track.playing) {
        this.stopPlayBack();
      }
    })
    $scope.$on(MessagingService.trackListRefreshed, (event) => {
      if (this.track && this.track.playing) {
        this.stopPlayBack();
      }
    })

  }
  onPlayClick(){
    if (this.track.playing){
      this.stopPlayBack();
    }else {

      this.sound = this.ngAudio.load("/api/tracks/"+this.track.r2_resource_id+"/audio/summary-stream");
      this.sound.play();
      this.track.playing = true;
      this.track.clipPlaybackTime = 0;
      this.messagingService.broadcast(MessagingService.knobPlayerPlaying,this.track);
      //bind "this" to the timeout to use it in onTimeout
      this.clipPlaybackTimeout = this.timeout(this.onTimeout.bind(this), 200);
    }
  }

  onTimeout(){
    this.track.clipPlaybackTime = this.sound.currentTime;
    if (isNaN(this.sound.duration) && this.sound.duration != undefined){
      //Safari put "Infinity" in duration and knob reconfigure doesn't work
      this.maxInitilized = true;
    }else if(!this.maxInitilized && this.sound.duration != undefined){
      this.max = this.sound.duration; //this alone doesn't work in safari
      angular.element('#track-knob-'+this.track.r2_resource_id).trigger('configure', {
        max: this.sound.duration
      });
      this.maxInitilized = true;
    }
    if (this.sound.progress > 0 && this.sound.remaining == 0) {
      this.stopPlayBack(this.track);
    }else{
      this.clipPlaybackTimeout = this.timeout(this.onTimeout.bind(this), 200);
    }
    this.scope.$apply();
  }

  stopPlayBack(){
    this.timeout.cancel(this.clipPlaybackTimeout);
    if (this.sound){
      this.sound.stop();
    }
    this.track.playing = false;
    this.track.clipPlaybackTime=0;
  }
}


class KnobPlayerDirective {

  constructor() {
    this.scope = {
      onPlayClick: "&",
      song: "=track", //from parent scope (being an object it must be =)
      //knobOptions: "=",
      autoStop: "@",
      htmlId: "@"
    };
    this.template = `<div ng-click="ctrl.onPlayClick()"
     style="min-width: 36px;height: 0px;margin-top: -4px; position:relative; cursor:pointer">
          <knob id="{{htmlId}}" knob-max="ctrl.max" knob-data="song.clipPlaybackTime" knob-options="ctrl.knobOptions"></knob>
                                <span id="{{htmlId}}_countdown" ng-show="ctrl.sound.remaining">{{("0"+(ctrl.sound.remaining | number: 0)).slice(-2)}}</span>
                                <span id="{{htmlId}}_30" ng-hide="ctrl.sound.remaining">30</span>
        </div>`;
    this.replace = true;
    this.controller = 'KnobPlayerCtrl';
    this.controllerAs = 'ctrl';

  }
}

register('auditionApp').directive('knobPlayer', KnobPlayerDirective);
register('auditionApp').controller('KnobPlayerCtrl', KnobPlayerCtrl);

