
'use strict';
class RightsFilterCtrl extends FilterPanelCtrl{

  constructor($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager) {
    super($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager);
    //this.loadingMetrics = super.loadingMetrics;
    this.totalTracks = 0;
    this.scope = $scope;
    this.minUMPGSharesOptions = {
      showTicks: true,
      stepsArray: [
        {value:0, legend: "Off"},
        {value:25, legend: "25%"},
        {value:50, legend: "50%"},
        {value:75, legend: "75%"},
        {value:100, legend: "100%"}
      ],
      onEnd: (sliderId, modelValue, highValue, pointerType) =>{
        if (!this.searchCriteria.match.publishing_rights_country){
          this.searchCriteria.match.publishing_rights_country="US";
        }
        this.updateFilters();
      }
    }

    $scope.$on(MessagingService.filtersReset, (event, data) => {
      this.searchCriteria.match.publishing_rights_country = undefined;
    });

    this.countries = [
      {country_id:"NONE", country_name: " -- clear selection --"},{country_id:"AU", country_name: "Australia"},{country_id:"AT", country_name: "Austria"},
      {country_id:"BE", country_name: "Belgium"},{country_id:"BA", country_name: "Bosnia and Herzegovina"},{country_id:"BR", country_name: "Brazil"},
      {country_id:"BG", country_name: "Bulgaria"},{country_id:"CN", country_name: "China"},{country_id:"HR", country_name: "Croazia"},{country_id:"CY", country_name: "Cyprus"},
      {country_id:"CZ", country_name: "Czech Republic"},{country_id:"DK", country_name: "Denmark"},{country_id:"EE", country_name: "Estonia"},
      {country_id:"FI", country_name: "Finland"},{country_id:"FR", country_name: "France"},{country_id:"DE", country_name: "Germany"},{country_id:"GR", country_name: "Greece"},
      {country_id:"HK", country_name: "Hong Kong"},{country_id:"HU", country_name: "Hungary"},{country_id:"IS", country_name: "Iceland"},{country_id:"IN", country_name: "India"},
      {country_id:"ID", country_name: "Indonesia"},{country_id:"IT", country_name: "Italy"},{country_id:"IE", country_name: "Ireland"},{country_id:"IL", country_name: "Israel"},
      {country_id:"JP", country_name: "Japan"},{country_id:"KR", country_name: "Korea"},{country_id:"LV", country_name: "Latvia"},{country_id:"LT", country_name: "Lithuania"},
      {country_id:"LU", country_name: "Luxembourg"},{country_id:"MK", country_name: "Macedonia, Republic of"},{country_id:"MT", country_name: "Malta"},
      {country_id:"MA", country_name: "Marocco"},{country_id:"ME", country_name: "Montenegro"},{country_id:"NL", country_name: "Netherlands"},
      {country_id:"NZ", country_name: "New Zealand"},{country_id:"NG", country_name: "Nigeria"},{country_id:"NO", country_name: "Norway"},{country_id:"PL", country_name: "Poland"},
      {country_id:"PT", country_name: "Portugal"},{country_id:"RO", country_name: "Romania"},{country_id:"RU", country_name: "Russia"},{country_id:"SA", country_name: "Saudi Arabia"},
      {country_id:"RS", country_name: "Serbia"},{country_id:"SG", country_name: "Singapore"},{country_id:"SK", country_name: "Slovakia"},{country_id:"SI", country_name: "Slovenia"},
      {country_id:"ZA", country_name: "South Africa"},{country_id:"ES", country_name: "Spain"},{country_id:"SE", country_name: "Sweden"},{country_id:"CH", country_name: "Switzerland"},
      {country_id:"TW", country_name: "Taiwan"},{country_id:"TR", country_name: "Turkey"},{country_id:"UA", country_name: "Ukraine"},{country_id:"AE", country_name: "United Arab Emirates"},
      {country_id:"GB", country_name: "United Kingdom"},{country_id:"US", country_name: "United States"},{country_id:"UY", country_name: "Uruguay"},{country_id:"VN", country_name: "Viet Nam"}
    ]
    $scope.$on('trackMetricsUpdated', (event, data) => {
      this.totalTracks = this.tracksManager.totalTracks;
    });
  }

  onCountrySelected(item){
    if (item.country_id == "NONE"){
      this.searchCriteria.match.publishing_rights_country = undefined;
      this.searchCriteria.ranges.minUMPGShares.min = 0;
    }else {
      this.searchCriteria.match.publishing_rights_country = item.country_id;
    }
    this.updateFilters();
  }
}

class RightsFilterComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'RightsFilterCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `
              <div>
                <div class="filter-container" style="padding-left: 10px;">
                  <div class="filter-container-heading">
                     <label class="filter-label-slider">Recording Rights&nbsp;&nbsp;</label>
                     <span ng-show="ctrl.totalTracks>0" class="badge">{{ctrl.totalTracks}}</span>
                  </div>
                  <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.rights">
                    <p style="margin-left: 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;
                      <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span>
                    </p>
                    <div class="col-md-push-2">
                      <div class="btn-group btn-group-xs pull-right">
                        <md-checkbox id="{{item.id}}_check" md-no-ink ng-model="item.value" ng-change="ctrl.updateFilters()"
                        ng-true-value="'Y'" ng-false-value="'N'" aria-label="No Ink Effects"></md-checkbox>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="filter-container">
                  <div class="filter-slider-container step-slider">
                    <div class="filter-container-heading">
                      <label class="filter-label-slider">Publishing Rights</label>
                    </div>
                  <div class="row">
                    <p style="margin-left: 1pc; width:151px; float:left; font-size: 11px">Public Domain: US only
                      <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span>
                    </p>
                    <div class="col-md-push-2">
                      <div class="btn-group btn-group-xs pull-right">
                        <md-checkbox id="public_doamin_check" md-no-ink ng-model="ctrl.searchCriteria.filters.publishing[0].value" ng-change="ctrl.updateFilters()"
                        ng-true-value="'Y'" ng-false-value="'N'" aria-label="No Ink Effects"></md-checkbox>
                      </div>
                    </div>
                  </div>
                  <div style="margin-bottom: 6px;">
                    <ui-select class="filters-dropdown" on-select="ctrl.onCountrySelected($item)"
                               ng-model="ctrl.searchCriteria.match.publishing_rights_country" theme="selectize">
                      <ui-select-match allow-clear="true" placeholder="Type in a country">
                        {{$select.selected.country_name}}
                      </ui-select-match>
                      <ui-select-choices
                        repeat="country.country_id as country in ctrl.countries | filter: $select.search">
                        <div ng-bind-html="country.country_name | highlight: $select.search"></div>
                      </ui-select-choices>
                    </ui-select>
                  </div>
                    <p style="float:left; font-size: 11px">Minimum UMPG share&nbsp;</p>
                    <rzslider 
                      rz-slider-model="ctrl.searchCriteria.ranges.minUMPGShares.min"
                      rz-slider-translate="ctrl.minUMPGSharesOptions"
                      rz-slider-options="ctrl.minUMPGSharesOptions"></rzslider>
                  </div>
                </div>
              </div>`
  }
}

register('auditionApp').directive('rightsFilter', RightsFilterComponent);
register('auditionApp').controller('RightsFilterCtrl', RightsFilterCtrl);

