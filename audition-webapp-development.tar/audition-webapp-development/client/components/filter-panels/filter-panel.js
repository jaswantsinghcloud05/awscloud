'use strict';
class FilterPanelCtrl {
  constructor($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager) {
    this.trackService = trackService;
    this.tracksManager = tracksManager;
    this.searchCriteria = trackService.searchCriteria;
    this.timeout = $timeout;
    //Tracks logic to move in TracksCtrl
    this.loadingMetrics = false;
    this.urlStatusManager = urlStatusManager;
    this.scrollDisabled = true;
 //   this.httpParamSerializerJQLike = $httpParamSerializerJQLike;

    $scope.$on(MessagingService.trackMetricsUpdated, (event, data) => {
      this.loadingMetrics = false;
    });
    $scope.$on(MessagingService.trackFiltersUpdated, (event, data) => {
      this.loadingMetrics = true;
    });

  //   $scope.$watch('ctrl.trackService.searchCriteria', (newValue, oldValue, scope) => {
  //     if (!angular.equals(scope.ctrl.trackService.searchCriteria,oldValue)){
  //       this.$location.search("query",JSON.stringify(this.trackService.searchCriteria))
  //     }
  //   }, true)
  }

  onSliderEnd = (sliderId, modelValue, highValue, pointerType) => {
    this.updateFilters();
  }

  updateSorting(fieldName, sorting){
    //TODO this is now used only by the creative metadata panel, once we will be able to use
    //scripting in es the rounded part will be removed and it'll become more generic
    var sort = this.trackService.searchCriteria.filterSorting;
    var found = false;
    for(var i=0; i<sort.length; i++){
      if (sort[i][fieldName+"_rounded"]){
        sort.splice(i,1);
        found = true;
        break;
      }
    }
    if(!found && sorting){
      sort.push({[fieldName+"_rounded"]:-1})
    }
  }

  updateFilters(fieldName, sorting) {
    if (sorting!=null){
      this.updateSorting(fieldName,sorting)
    }
    this.urlStatusManager.updateUrl()
  }

}

angular.module('auditionApp').controller('filterPanelCtrl', FilterPanelCtrl);
