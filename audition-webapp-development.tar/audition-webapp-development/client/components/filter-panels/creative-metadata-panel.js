
'use strict';
class CreativeMetaDataCtrl extends FilterPanelCtrl{

  constructor($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager) {
    super($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager);

    this.selectedUmgGenre = '';
    this.selectedUmgGenres = [];
    this.umgGenres = [{"value": "Pop"},{"value": "Classical"},{  "value": "Rock",  "key": 160617},{  "value": "Jazz",  "key": 108073},{  "value": "Soundtrack",  "key": 56577},{  "value": "Dance",  "key": 53764},{  "value": "Alternative",  "key": 52128},{  "value": "Hip Hop",  "key": 46001},{  "value": "Country",  "key": 42555},{  "value": "Christian",  "key": 34366},{  "value": "Metal",  "key": 32985},{  "value": "R & B",  "key": 30624},{  "value": "Spoken Word",  "key": 28949},{  "value": "Latin",  "key": 28765},{  "value": "Folk",  "key": 26891},{  "value": "Children",  "key": 26414},{  "value": "World",  "key": 24377},{  "value": "Schlager",  "key": 18845},{  "value": "Latin / Regional Mexican",  "key": 17890},{  "value": "Electronic",  "key": 15546},{  "value": "Blues",  "key": 14127},{  "value": "J-POP",  "key": 12386},{  "value": "J-Pop",  "key": 11782},{  "value": "Holiday",  "key": 10588},{  "value": "Reggae",  "key": 9950},{  "value": "French Pop",  "key": 9467},{  "value": "Gospel",  "key": 8191},{  "value": "Hip Hop/Rap",  "key": 7297},{  "value": "Comedy",  "key": 6721},{  "value": "New Age",  "key": 6552},{  "value": "Cantopop",  "key": 6251},{  "value": "Vocal",  "key": 5839},{  "value": "Rap",  "key": 5681},{  "value": "Latin / Pop",  "key": 5084},{  "value": "Children's Music",  "key": 4851},{  "value": "Easy Listening",  "key": 4393},{  "value": "Singer Songwriter",  "key": 3949},{  "value": "Instrumental",  "key": 3768},{  "value": "Volksmusik",  "key": 3675},{  "value": "Bluegrass",  "key": 3419},{  "value": "Soul",  "key": 3236},{  "value": "Punk",  "key": 3158},{  "value": "Mandopop",  "key": 3095},{  "value": "R&B",  "key": 3021},{  "value": "German Pop",  "key": 2832},{  "value": "Devotional",  "key": 2693},{  "value": "K-POP",  "key": 2640},{  "value": "Flamenco",  "key": 2579},{  "value": "Kayokyoku",  "key": 2477},{  "value": "Singer/Songwriter",  "key": 1946},{  "value": "Musical",  "key": 1916},{  "value": "Latin / Urban",  "key": 1901},{  "value": "MPB",  "key": 1719},{  "value": "Ghazal",  "key": 1662},{  "value": "Classical Crossover",  "key": 1541},{  "value": "Fado",  "key": 1416},{  "value": "Latin / Tropical",  "key": 1210},{  "value": "Samba",  "key": 1045},{  "value": "Inspirational",  "key": 1036},{  "value": "Adult Contemporary",  "key": 914},{  "value": "Reggaeton",  "key": 885},{  "value": "Sertanejo",  "key": 879},{  "value": "Latin / Rock",  "key": 877},{  "value": "Funk",  "key": 843},{  "value": "Children's",  "key": 839},{  "value": "Afrikaans",  "key": 802},{  "value": "Enka",  "key": 741},{  "value": "Disco",  "key": 666},{  "value": "Musique Francophone",  "key": 587},{  "value": "Rock-Traditional and Classic",  "key": 587},{  "value": "Tango",  "key": 567},{  "value": "Urban",  "key": 539},{  "value": "Axé",  "key": 476},{  "value": "Classic Rock",  "key": 418},{  "value": "Forró",  "key": 382},{  "value": "Kids",  "key": 352},{  "value": "Pagode",  "key": 334},{  "value": "Brega",  "key": 309},{  "value": "Traditional Jazz",  "key": 305},{  "value": "Adult",  "key": 287},{  "value": "TV/Film",  "key": 211},{  "value": "Latin Regional Mexican",  "key": 210},{  "value": "Indian Classical",  "key": 207},{  "value": "Bossa nova",  "key": 206},{  "value": "Animation (Film/TV)",  "key": 199},{  "value": "Latin Pop International",  "key": 199},{  "value": "Swing",  "key": 192},{  "value": "Contemporary Christian",  "key": 181},{  "value": "Classics",  "key": 156},{  "value": "Classics (Film)",  "key": 156},{  "value": "Kids & Family (Film)",  "key": 143},{  "value": "Indian Pop",  "key": 138},{  "value": "Urban/R and B",  "key": 129},{  "value": "Motown",  "key": 120},{  "value": "Southern Gospel",  "key": 120},{  "value": "Vocals",  "key": 99},{  "value": "Documentary",  "key": 91},{  "value": "Regional Indian",  "key": 89},{  "value": "Opera",  "key": 88},{  "value": "Independent",  "key": 76},{  "value": "Oldies (Mobile)",  "key": 67},{  "value": "Kids (TV)",  "key": 65},{  "value": "Pop Alternative",  "key": 65},{  "value": "Contemporary Jazz",  "key": 64},{  "value": "Kids & Family",  "key": 64},{  "value": "Dance/Electronic",  "key": 58},{  "value": "Jovem Guarda",  "key": 57},{  "value": "Caribbean",  "key": 47},{  "value": "Classical Mainstream",  "key": 41},{  "value": "Latin Tejano",  "key": 41},{  "value": "Soundtrack Scores",  "key": 37},{  "value": "Urban-Christian",  "key": 36},{  "value": "Bossa Nova",  "key": 34},{  "value": "Broadway (Mobile)",  "key": 33},{  "value": "Broadway",  "key": 32},{  "value": "Latin Urban / Reggaeton",  "key": 30},{  "value": "Christian Rock",  "key": 29},{  "value": "Sports (Film/TV)",  "key": 29},{  "value": "Independent (Film)",  "key": 28},{  "value": "Sports",  "key": 24},{  "value": "Fitness & Workout",  "key": 21},{  "value": "Latin Pop",  "key": 21},{  "value": "Urban Latino",  "key": 21},{  "value": "Karaoke",  "key": 20},{  "value": "Classical(Vocal,Early,Chamber)",  "key": 18},{  "value": "Bhangda",  "key": 16},{  "value": "Latin Jazz",  "key": 16},{  "value": "Celtic",  "key": 14},{  "value": "Latin Alternative/Rock",  "key": 14},{  "value": "Lounge",  "key": 12},{  "value": "Music Feature Films",  "key": 12},{  "value": "80's (Mobile)",  "key": 11},{  "value": "Romance (Film)",  "key": 11},{  "value": "Tamil",  "key": 11},{  "value": "80's",  "key": 10},{  "value": "Qawwali",  "key": 9},{  "value": "Western (Film)",  "key": 5},{  "value": "Bhangra",  "key": 4},{  "value": "Concert Films",  "key": 4},{  "value": "Romance",  "key": 4},{  "value": "Drama",  "key": 3},{  "value": "Drama (Film/TV)",  "key": 3},{  "value": "Animation",  "key": 2},{  "value": "Documentary (Film)",  "key": 2},{  "value": "Special Effects (Mobile)",  "key": 2},{  "value": "Bollywood",  "key": 1},{  "value": "Cantopop/HK-Pop",  "key": 1},{  "value": "Choro",  "key": 1},{  "value": "Classic TV",  "key": 1},{  "value": "Frevo",  "key": 1},{  "value": "Horror",  "key": 1},{  "value": "Latin Tropical",  "key": 1},{  "value": "Oldies",  "key": 1},{  "value": "Reality TV",  "key": 1},{  "value": "Sci-Fi & Fantasy",  "key": 1},{  "value": "Sci-Fi & Fantasy (Film/TV)",  "key": 1},{  "value": "Short Films",  "key": 1},{  "value": "Western",  "key": 1}];
    this.arrangementOptions = {
      stepsArray: [
        {value:"", legend: "Off"},
        {value:"arrangement_voice_music", legend: "Voice Music"},
        {value:"arrangement_instrumental", legend: "Instrumental"},
        {value:"arrangement_a_capella", legend: "A Capella"}
      ],
      showTicks: true,
      onEnd: this.onSliderChange,
      id: "arrangements"
    };
    this.tempoOptions = {
      stepsArray: [
        {value:"", legend: "Off"},
        {value:"tempo_slow", legend: "slow"},
        {value:"tempo_medium", legend: "Medium"},
        {value:"tempo_fast", legend: "Fast"}
      ],
      showTicks: true,
      onEnd: this.onSliderChange,
      id: "tempos"
    };
    this.vocalGenderOptions = {
      stepsArray: [
        {value:"vocal_register_male", legend: "Low"},
        {value:"", legend: "Off"},
        {value:"vocal_register_female", legend: "High"}
      ],
      showTicks: true,
      onEnd: this.onSliderChange,
      id: "vocalGenders"
    };

    this.bpmOptions = {
      floor : this.searchCriteria.ranges.bpm.floor,
      ceil: this.searchCriteria.ranges.bpm.ceil,
      onEnd: this.onSliderEnd
    };
    $scope.$on(MessagingService.trackMetricsUpdated, (event, data) => {
      this.updateMetadataMetrics();
    });

    $scope.$on(MessagingService.trackFiltersUpdated, (event, data) => {
      this.totalGenre = 0;
      this.totalInstumentation = 0;
      this.totalEmotions = 0;
      this.totalIntensities = 0;
      this.totalEnsembleTimbre = 0;
      this.totalEnsembleType = 0;
    });

    $scope.$on(MessagingService.filtersReset, (event, data) => {
      this.tempo = "";
      this.arrangement = "";
      this.vocalGender = "";
      this.totalGenre = 0;
      this.totalInstumentation = 0;
      this.totalEmotions = 0;
      this.totalEnsembleTimbre = 0;
      this.totalEnsembleType = 0;
      this.totalIntensities = 0;
    });

    $scope.$on(MessagingService.urlChanged, (event, data) => {
      this.setSliders();
      this.setChips();
    });
  }

  $onInit(){
    this.setSliders();
    this.setChips();
  }

  setSliders(){
    this.tempo = "";
    this.urlStatusManager.status.filters.filters.tempos.forEach((item) => {
      if (item.value == "Y") this.tempo = item.id;})
    this.arrangement = "";
    this.urlStatusManager.status.filters.filters.arrangements.forEach((item) => {
      if (item.value == "Y") this.arrangement = item.id;})
    this.vocalGender = "";
    this.urlStatusManager.status.filters.filters.vocalGenders.forEach((item) => {
      if (item.value == "Y") this.vocalGender = item.id;})
  }

  setChips(){
    angular.copy(this.urlStatusManager.status.filters.search.umgGenres,this.selectedUmgGenres);
    this.selectedUmgGenres = this.umgGenres.filter((localGenre) => {
      return null != this.urlStatusManager.status.filters.search.umgGenres.find((genre) => {
          return localGenre.value === genre;
        })
    });
  }

  onSliderChange = (sliderId, modelValue, highValue, pointerType) => {
    this.searchCriteria.filters[sliderId].forEach((item) => {
      if (item.id === modelValue) {
        item.value = "Y";
      } else {
        item.value = "";
      }
      this.updateFilters();
    })
  }

  updateMetadataMetrics(){
    //TODO review these loops
    this.totalGenre = 0;
    this.totalInstumentation = 0;
    this.totalEmotions = 0;
    this.totalIntensities = 0;
    this.totalEnsembleTimbre = 0;
    this.totalEnsembleType = 0;
    var aggregations = this.tracksManager.currentMetrics;
    this.searchCriteria.filters.genres.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalGenre += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.searchCriteria.filters.emotions.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalEmotions += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.searchCriteria.filters.intensities.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalIntensities += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.searchCriteria.filters.instrumentations.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalInstumentation += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.searchCriteria.filters.ensemble_types.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalEnsembleType += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.searchCriteria.filters.ensemble_timbres.forEach((item) => {
      if (aggregations) {
        for (var name in aggregations) {
          if (name == item.id) {
            item.count = aggregations[name].doc_count;
            if (item.count > 500) {
              item.count = "500+";
            }
            this.totalEnsembleTimbre += aggregations[name].doc_count;
          }
        }
      } else {
        item.count = 0;
      }
    });
    this.totalItems = this.tracksManager.totalTracks;
  }

  /**
   * Search for countries.
   */
  umgGenreSearch (query) {
    var lowercaseQuery = angular.lowercase(query);
    var results = lowercaseQuery ? this.umgGenres.filter((item) => {
      return (item.value.toLowerCase().indexOf(lowercaseQuery) > -1);
    }) : [];
    return results;
  }

  onUmgGenreAdded(genre){
    this.urlStatusManager.status.filters.search.umgGenres.push(genre.value);
    this.updateFilters();
  }

  onUmgGenreRemoved(index){
    this.urlStatusManager.status.filters.search.umgGenres.splice(index,1);
    this.updateFilters();
  }

}

class CreativeMetaDataComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'CreativeMetaDataCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `
              <div>
                <div id="creative-filter-container" class="filter-container">
                  <uib-accordion close-others="false">
                    <uib-accordion-group is-open="accordionStatus.genreOpen"
                                         is-disabled="accordionStatus.isGenreDisabled">
                      <uib-accordion-heading>
                        <span id="genre_acc_btn" class="filter-label">Genre&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalGenre>0" class="badge">{{ctrl.totalGenre}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.genreOpen, 'glyphicon-chevron-right': !accordionStatus.genreOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.genres">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)">
                                 <span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                    <uib-accordion-group is-open="accordionStatus.emotionsOpen"
                                         is-disabled="accordionStatus.isEmotionsDisabled">
                      <uib-accordion-heading>
                        <span id="emotions_acc_btn" class="filter-label">Emotion&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalEmotions>0" class="badge">{{ctrl.totalEmotions}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.emotionsOpen, 'glyphicon-chevron-right': !accordionStatus.emotionsOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.emotions">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)"><span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                    <uib-accordion-group is-open="accordionStatus.intensitiesOpen"
                                         is-disabled="accordionStatus.isIntensitiesDisabled">
                      <uib-accordion-heading>
                        <span id="intensities_acc_btn" class="filter-label">Intensity&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalIntensities>0" class="badge">{{ctrl.totalIntensities}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.intensitiesOpen, 'glyphicon-chevron-right': !accordionStatus.intensitiesOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.intensities">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)"><span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                    <uib-accordion-group is-open="accordionStatus.instrOpen"
                                         is-disabled="accordionStatus.isInstrDisabled">
                      <uib-accordion-heading>
                        <span id="instrumentation_acc_btn" class="filter-label">Instrumentation&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalInstumentation>0" class="badge">{{ctrl.totalInstumentation}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.instrOpen, 'glyphicon-chevron-right': !accordionStatus.instrOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.instrumentations">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)"><span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                    <uib-accordion-group is-open="accordionStatus.ensembleTimbreOpen"
                                         is-disabled="accordionStatus.isEnsembleTimbreDisabled">
                      <uib-accordion-heading>
                        <span id="ensembleTimbre_acc_btn" class="filter-label">Ensemble Timbre&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalEnsembleTimbre>0" class="badge">{{ctrl.totalEnsembleTimbre}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.ensembleTimbreOpen, 'glyphicon-chevron-right': !accordionStatus.ensembleTimbreOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.ensemble_timbres">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)"><span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                    <uib-accordion-group is-open="accordionStatus.ensembleTypeOpen"
                                         is-disabled="accordionStatus.isEnsembleTypeDisabled">
                      <uib-accordion-heading>
                        <span id="ensembleType_acc_btn" class="filter-label">Ensemble Types&nbsp;&nbsp;</span>
                        <span ng-show="ctrl.totalEnsembleType>0" class="badge">{{ctrl.totalEnsembleType}}</span>
                        <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span><i
                        class="pull-right glyphicon glyphicon-grey"
                        ng-class="{'glyphicon-chevron-down': accordionStatus.ensembleTypeOpen, 'glyphicon-chevron-right': !accordionStatus.ensembleTypeOpen}"></i>
                      </uib-accordion-heading>
                      <div>
                        <div class="row" ng-repeat="item in ctrl.searchCriteria.filters.ensemble_types">
                          <p style="margin: 0 0 3px 1pc; width:151px; float:left; font-size: 11px">{{item.label}}&nbsp;<span
                            ng-show="item.count>0 || item.count==='500+'" class="badge">{{item.count}}</span></p>

                          <div class="col-md-push-2">
                            <div class="btn-group btn-group-xs pull-right">
                              <button id="{{item.id}}_minus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-red', false:'btn-default filter-button-label'}[item.value=='N']"
                                      ng-model="item.value" uib-btn-radio="'N'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)">
                                <span class="glyphicon glyphicon-minus"></span></button>
                              <button id="{{item.id}}_plus_btn" type="button" class="btn filter-button-label"
                                      ng-class="{true:'btn-green', false:'btn-default filter-button-label'}[item.value=='Y']"
                                      ng-model="item.value" uib-btn-radio="'Y'" uncheckable
                                      ng-change="ctrl.updateFilters(item.id)"><span>+</span></button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </uib-accordion-group>
                  </uib-accordion>
                </div>
                <div class="filter-container" 
                style="margin-top: -21px; margin-bottom: 16px;">
                        <div style="position: relative">
                              <md-chips ng-model="ctrl.selectedUmgGenres" md-autocomplete-snap
                                      md-require-match="true" md-on-add="ctrl.onUmgGenreAdded($chip)"
                                      md-on-remove="ctrl.onUmgGenreRemoved($index)">
                              <md-autocomplete
                                  md-selected-item="ctrl.selectedUmgGenre"
                                  md-search-text="ctrl.searchUmgGenreText"
                                  md-items="item in ctrl.umgGenreSearch(ctrl.searchUmgGenreText)"
                                  md-item-text="item.value"
                                  placeholder="UMG Genre">
                                <span md-highlight-text="ctrl.searchUmgGenreText">{{item.value}}</span>
                              </md-autocomplete>
                              <md-chip-template>
                                <span>{{$chip.value}}</span>
                              </md-chip-template>
                            </md-chips>
                        </div>
                </div>
                <div class="filter-container" style="margin-top: -6px;">
                  <div class="filter-slider-container step-slider">
                    <div class="filter-container-heading">
                      <label class="filter-label-slider">Arrangement</label>
                    </div>
                    <rzslider 
                      rz-slider-id="arrangements"
                      rz-slider-model="ctrl.arrangement"
                      rz-slider-options="ctrl.arrangementOptions">
                      </rzslider>
                  </div>
                </div>
                <div class="filter-container">
                  <div class="filter-slider-container step-slider">
                    <div class="filter-container-heading">
                      <label class="filter-label-slider">Tempo</label>
                    </div>
                    <rzslider 
                      rz-slider-id="tempos"
                      rz-slider-model="ctrl.tempo"
                      rz-slider-options="ctrl.tempoOptions"></rzslider>
                  </div>
                </div>
                <div class="filter-container">
                  <div class="filter-slider-container step-slider">
                    <div class="filter-container-heading">
                      <label class="filter-label-slider">Vocal Register</label>
                    </div>
                    <rzslider 
                      rz-slider-id="vocalGenders"
                      rz-slider-model="ctrl.vocalGender"
                      rz-slider-options="ctrl.vocalGenderOptions"></rzslider>
                  </div>
                </div>
                <div class="filter-container">
                  <div class="filter-slider-container">
                    <div class="filter-container-heading" style="margin-bottom: 28px;">
                      <label class="filter-label-slider">BPM</label>
                    </div>
                    <rzslider
                      rz-slider-model="ctrl.searchCriteria.ranges.bpm.min"
                      rz-slider-high="ctrl.searchCriteria.ranges.bpm.max"
                      rz-slider-options="ctrl.bpmOptions"></rzslider>
                  </div>
                </div>
                <div style="width: 92%;">
                  <p style="width:151px; float:left; font-size: 11px">Exclude "live" tracks
                    <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin"></span>
                  </p>
                  <div class="col-md-push-2">
                    <div class="btn-group btn-group-xs pull-right">
                      <md-checkbox id="exclude_live_check" md-no-ink ng-model="ctrl.searchCriteria.excludeLiveTracks" ng-change="ctrl.updateFilters()"
                       aria-label="No Ink Effects"></md-checkbox>
                    </div>
                  </div>
                </div>
              </div>`;
  }
}

register('auditionApp').directive('creativeMetaDataFilter', CreativeMetaDataComponent);
register('auditionApp').controller('CreativeMetaDataCtrl', CreativeMetaDataCtrl);

