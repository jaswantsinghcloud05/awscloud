
'use strict';
class MetricsCtrl extends FilterPanelCtrl{

  constructor($rootScope, $scope, trackService, tracksManager, $timeout, $location, $state) {
    super($rootScope, $scope, trackService, tracksManager, $timeout, $location, $state);
    this.loadingMetrics = super.loadingMetrics;
  }

  translatePopularity(value){
    if (value == 0){
      return 'All'
    }else{
      return 'Top ' + (100 - value) + '%';
    }
  }

}

class MetricsComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'MetricsCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div class="filter-container">
                  <label class="filter-label">POPULARITY</label>

                  <div class="filter-slider-container">
                    <rzslider
                      rz-slider-ceil="ctrl.searchCriteria.ranges.popularity.ceil"
                      rz-slider-model="ctrl.searchCriteria.ranges.popularity.min"
                      rz-slider-high="ctrl.searchCriteria.ranges.popularity.max"
                      rz-slider-step="10"
                      rz-slider-translate="ctrl.translatePopularity"/>
                  </div>
                </div>`;
  }
}

register('auditionApp').directive('metricsFilter', MetricsComponent);
register('auditionApp').controller('MetricsCtrl', MetricsCtrl);

