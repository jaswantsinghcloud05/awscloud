
'use strict';
class RepertoireDataCtrl extends FilterPanelCtrl{

  constructor($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager) {
    super($rootScope, $scope, $timeout, trackService, tracksManager, urlStatusManager);
    // this.loadingMetrics = super.loadingMetrics;
    this.decadesOptions = {
      floor : this.searchCriteria.ranges.decades.floor,
      ceil: this.searchCriteria.ranges.decades.ceil,
      step:10,
      translate: this.translateDecades,
      //onEnd: this.onSliderEnd
      disabled: true
    };
    this.selectedCountries = [];
    this.selectedCountry = null;
    this.searchCountryText = null;

    this.countries = [
      {"value": "United States","key": "US"},{"value": "United Kingdom","key": "GB"},{"value": "Germany","key": "DE"},
      {"value": "France","key": "FR"},{"value": "Japan","key": "JP"},{"value": "Australia","key": "AU"},{"value": "Canada","key": "CA"},
      {"value": "Sweden","key": "SE"},{"value": "Brazil","key": "BR"},{"value": "Finland","key": "FI"},{"value": "Italy","key": "IT"},
      {"value": "Mexico","key": "MX"},{"value": "Netherlands","key": "NL"},{"value": "Denmark","key": "DK"},
      {"value": "Hong Kong","key": "HK"},{"value": "Greece","key": "GR"},{"value": "Norway","key": "NO"},{"value": "Spain","key": "ES"},
      {"value": "South Africa","key": "ZA"},{"value": "India","key": "IN"},{"value": "Malaysia","key": "MY"},
      {"value": "Argentina","key": "AR"},{"value": "Austria","key": "AT"},{"value": "Portugal","key": "PT"},
      {"value": "Switzerland","key": "CH"},{"value": "Belgium","key": "BE"},{"value": "New Zealand","key": "NZ"},
      {"value": "Czech Republic","key": "CZ"},{"value": "Poland","key": "PL"},{"value": "Hungary","key": "HU"},
      {"value": "Singapore","key": "SG"},{"value": "Taiwan","key": "TW"},{"value": "United Arab Emirates","key": "AE"},
      {"value": "Korea","key": "KR"},{"value": "Romania","key": "RO"},{"value": "Ireland","key": "IE"},{"value": "Turvalue","key": "TV"},
      {"value": "Chile","key": "CL"},{"value": "Philippines","key": "PH"},{"value": "Slovakia","key": "SK"},
      {"value": "Indonesia","key": "ID"},{"value": "Colombia","key": "CO"},{"value": "Russia","key": "RU"},
      {"value": "China","key": "CN"},{"value": "Venezuela","key": "VE"},{"value": "Thailand","key": "TH"},{"value": "UNKNOWN","key": "99"},
      {"value": "Ukraine","key": "UA"},{"value": "Latvia","key": "LV"},{"value": "Bulgaria","key": "BG"}
    ];

    this.selectedLabels = [];
    this.selectedLabel = null;
    this.searchLabelText = null;

    angular.copy(urlStatusManager.status.filters.search.labels,this.selectedLabels);
    this.selectedCountries = this.countries.filter((country) =>{
        return null != urlStatusManager.status.filters.search.countries.find((countryId) => {
            return country.key === countryId;
          })
        }
      );
    $scope.$on(MessagingService.urlChanged, (event) => {
      angular.copy(urlStatusManager.status.filters.search.labels,this.selectedLabels);
      this.selectedCountries = this.countries.filter((country) =>{
          return null != urlStatusManager.status.filters.search.countries.find((countryId) => {
              return country.key === countryId;
            })
        }
      );
    })
  }

  /**
   * Search for countries.
   */
  countrySearch (query) {
    var results = query ? this.countries.filter(this.createFilterFor(query)) : [];
    return results;
  }

  /**
   * Create filter function for a query string
   */
  createFilterFor(query) {
    var lowercaseQuery = angular.lowercase(query);

    return function filterFn(item) {
      return (item.value.toLowerCase().indexOf(lowercaseQuery) > -1);
    };

  }

  translateDecades(value){
    return value+"s";
  }

  onLabelAdded(label){
    this.urlStatusManager.status.filters.search.labels.push(label);
    this.updateFilters();
  }

  onLabelRemoved(index){
    this.urlStatusManager.status.filters.search.labels.splice(index,1);
    this.updateFilters();
  }

  onCountryAdded(country){
    this.urlStatusManager.status.filters.search.countries.push(country.key);
    this.updateFilters();
  }

  onCountryRemoved(index){
    this.urlStatusManager.status.filters.search.countries.splice(index,1);
    this.updateFilters();
  }

}

class RepertoireDataComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'RepertoireDataCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div>
                    <div class="filter-container">
                        <div style="position: relative">
                            <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin" 
                              style="position: absolute; bottom: 9px; right: 6px;"></span>
                            <md-chips ng-model="ctrl.selectedCountries" md-autocomplete-snap
                                      md-require-match="true" md-on-add="ctrl.onCountryAdded($chip)"
                                      md-on-remove="ctrl.onCountryRemoved($index)">
                              <md-autocomplete
                                  md-selected-item="ctrl.selectedCountry"
                                  md-search-text="ctrl.searchCountryText"
                                  md-items="item in ctrl.countrySearch(ctrl.searchCountryText)"
                                  md-item-text="item.value"
                                  placeholder="Country of data entry">
                                <span md-highlight-text="ctrl.searchCountryText">{{item.value}}</span>
                              </md-autocomplete>
                              <md-chip-template>
                                <span>{{$chip.value}}</span>
                              </md-chip-template>
                            </md-chips>
                        </div>
                          <div style="position: relative">
                            <span ng-show="ctrl.loadingMetrics" class="fa fa-spinner fa-spin" 
                              style="position: absolute; bottom: 9px; right: 6px;"></span>
                            <md-chips ng-model="ctrl.selectedLabels" md-on-add="ctrl.onLabelAdded($chip)"
                                      md-on-remove="ctrl.onLabelRemoved($index)" 
                                      placeholder="Type a label and press return">
                              <md-chip-template >
                                <span>{{$chip}}</span>
                              </md-chip-template>
                            </md-chips>
                          </div>
                     </div>
<!--
                      <div class="filter-container">
                        <div class="filter-slider-container" style="position: relative">
                          <div class="filter-container-heading" style="margin-bottom: 28px;">
                                <label class="filter-label">DECADES</label>
                          </div>
                          <rzslider
                                  rz-slider-model="ctrl.searchCriteria.ranges.decades.min"
                                  rz-slider-high="ctrl.searchCriteria.ranges.decades.max"
                                  rz-slider-options="ctrl.decadesOptions"></rzslider>
                        </div>
                      </div>
-->
                    </div>
`;
  }
}

register('auditionApp').directive('repertoireDataFilter', RepertoireDataComponent);
register('auditionApp').controller('RepertoireDataCtrl', RepertoireDataCtrl);
