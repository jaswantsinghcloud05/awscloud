'use strict';
class SyncFiltersCtrl {

  constructor($rootScope, $scope, $timeout, tracksManager, urlStatusManager, messagingService, usersManager) {
    this.tracksManager = tracksManager;
    this.urlStatusManager = urlStatusManager;
    this.messagingService = messagingService;
    this.usersManager = usersManager;
    this.scope = $scope;
    this.timeout = $timeout;
    this.filtersSwitch = "Filters Enabled";
    this.metadataFiltersSelected = false;
    this.rightsFiltersSelected = false;
    this.repertoireFiltersSelected = false;

    $timeout(function(){$scope.$broadcast("rzSliderForceRender")}, 3000, true);

    $scope.$on(MessagingService.urlChanged, (event, data) => {
      this.setFilterGroupFlags()
    });
  }

  $onInit(){
    this.setFilterGroupFlags();
    this.isEmployee = (this.usersManager.userType === UsersManager.employee);
  }

  setFilterGroupFlags(){
    var filters = this.urlStatusManager.status.filters.filters;
    var ranges = this.urlStatusManager.status.filters.ranges;
    var matches = this.urlStatusManager.status.filters.match;
    var search = this.urlStatusManager.status.filters.search;

    this.metadataFiltersSelected = false;
    filters.genres.some((item)=>{
      return this.metadataFiltersSelected = (item.value == "Y");
    })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.intensities.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.emotions.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.instrumentations.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.arrangements.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.tempos.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.ensemble_timbres.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.ensemble_types.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || filters.vocalGenders.some((item)=>{
        return this.metadataFiltersSelected = (item.value == "Y");
      })
    this.metadataFiltersSelected = this.metadataFiltersSelected || this.urlStatusManager.status.filters.excludeLiveTracks
      || search.umgGenres && search.umgGenres.length > 0;
    this.rightsFiltersSelected = false;
    filters.rights.some((item)=>{
      return this.rightsFiltersSelected = (item.value == "Y");
    })
    this.rightsFiltersSelected = ranges.minUMPGShares.min > 0 || this.rightsFiltersSelected || matches.publishing_rights_country;
    this.repertoireFiltersSelected = search.labels && search.labels.length > 0 || search.countries && search.countries.length > 0;

  }

  onTabSelect(){
    this.timeout( () => {
      this.scope.$broadcast("reCalcViewDimensions")}, 500, true);
  }

  onClearFiltersClick(){
    var filtersStatus = this.urlStatusManager.status.filters;
    var filters = filtersStatus.filters;
    var ranges = filtersStatus.ranges;
    for (var property in filters) {
      var filter = filters[property];
      if (Array.isArray(filter)){
        filter.forEach(function (item) {
          item.value="";
          item.count=0;
        });
      }
    }
    ranges.decades.min= 1900
    ranges.decades.max= new Date().getFullYear();
    ranges.bpm.min= 0;
    ranges.bpm.max=250;
    ranges.popularity.min= 0;
    ranges.minUMPGShares.min= 0;
    filtersStatus.search.labels.length = 0;
    filtersStatus.search.countries.length = 0;
    filtersStatus.search.umgGenres.length = 0;
    filtersStatus.columnSorting = [];
    filtersStatus.filterSorting = [];
    filtersStatus.excludeLiveTracks = false;
    this.messagingService.broadcast(MessagingService.filtersReset);
    this.urlStatusManager.updateUrl();
  }

}

class SyncFiltersComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'SyncFiltersCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `
<div class="sl-filter-div">
  <div id="filters" class="standard_margin_excl_top content_filters_wrapper">
    <md-content>
      <md-tabs md-dynamic-height="" md-no-pagination="true" md-border-bottom="">
        <md-tab ng-if="ctrl.isEmployee">
          <md-tab-label>
            <i id="rights_tab_btn" ng-class="{'fa fa-copyright icon-red':ctrl.rightsFiltersSelected,
                        'fa fa-copyright icon-default':!ctrl.rightsFiltersSelected}" aria-hidden="true"></i>
          </md-tab-label>
          <md-tab-body>
            <div class="filter_tab_content_wrapper">
              <div class="filter_heading">
                <h3>Rights Information</h3>
                  <span class="filter-reset-btn" ng-click="ctrl.onClearFiltersClick()">
                    <i class="fa fa-times clear_filters" aria-hidden="true" ></i>
                  </span>
              </div>
              <div class="filter_scrollable">
                <rights-filter></rights-filter>
              </div>
            </div>
          </md-tab-body>
        </md-tab>
        <md-tab>
          <md-tab-label>
            <i id="metadata_tab_btn" ng-class="{'fa fa-microphone icon-red':ctrl.metadataFiltersSelected,
                        'fa fa-microphone icon-default':!ctrl.metadataFiltersSelected}" aria-hidden="true"></i>
          </md-tab-label>
          <md-tab-body>
            <div class="filter_tab_content_wrapper">
              <div class="filter_heading">
              <h3 id="creative-metadata-lbl">Creative Metadata</h3>
                 <span class="filter-reset-btn" ng-click="ctrl.onClearFiltersClick()">
                    <i class="fa fa-times clear_filters" aria-hidden="true"></i>
                  </span>
              </div>
              <div class="filter_scrollable">
                <creative-meta-data-filter></creative-meta-data-filter>
              </div>
            </div>
          </md-tab-body>
        </md-tab>
        <md-tab>
          <md-tab-label>
            <i id="repertoire_tab_btn" ng-class="{'fa fa-dot-circle-o icon-red':ctrl.repertoireFiltersSelected,
                        'fa fa-dot-circle-o icon-default':!ctrl.repertoireFiltersSelected}" aria-hidden="true"></i>
          </md-tab-label>

          <md-tab-body>
            <div class="filter_tab_content_wrapper">
              <div class="filter_heading">
                <h3>Repertoire Data</h3>
                <span class="filter-reset-btn" ng-click="ctrl.onClearFiltersClick()">
                  <i class="fa fa-times clear_filters" aria-hidden="true" ></i>
                </span>
              </div>
              <div class="filter_scrollable">
                <repertoire-data-filter></repertoire-data-filter>
              </div>
            </div>
          </md-tab-body>

        </md-tab>

        <md-tab ng-disabled="true">

          <md-tab-label>
            <i class="fa fa-line-chart" aria-hidden="true"></i>
          </md-tab-label>

          <md-tab-body>
            <div class="filter_tab_content_wrapper">
              <div class="filter_heading">
                <h3 id="metrics-lbl">Metrics</h3>
                <span class="filter-reset-btn" ng-click="ctrl.onClearFiltersClick()">
                  <i class="fa fa-times clear_filters" aria-hidden="true"></i>
                </span>
               </div>
              <div class="filter_scrollable">
               <div style=" position:absolute; top:0; left:0; right:0; bottom:0; background-color:rgba(255, 255, 255, 0.71); z-index:9999; color:white;"></div>
               <metrics-filter></metrics-filter>
              </div>
            </div>
          </md-tab-body>

        </md-tab>

        <md-tab ng-disabled="true">

          <md-tab-label>
            <i class="fa fa-list" aria-hidden="true"></i>
          </md-tab-label>

          <md-tab-body>
            <div class="filter_tab_content_wrapper">
              <div class="filter_heading">
                <h3>Playlists</h3>
                <span class="filter-reset-btn" ng-click="ctrl.onClearFiltersClick()">
                  <i class="fa fa-times clear_filters" aria-hidden="true""></i>
                </span>
              </div>
              <div class="filter_scrollable">
                <p>
                  Coming soon ...
                </p>
              </div>
            </div>
          </md-tab-body>

        </md-tab>

      </md-tabs>
    </md-content>
  </div>
</div>
`;
  }
}

register('auditionApp').directive('syncFilters', SyncFiltersComponent);
register('auditionApp').controller('SyncFiltersCtrl', SyncFiltersCtrl);

