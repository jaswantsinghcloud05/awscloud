
'use strict';
class PlaylistSearchBoxCtrl {
  constructor($rootScope, $scope, playlistsManager, playlistService){
    this.playlistService = playlistService;
    this.playlistsManager = playlistsManager;
    this.searchModel = null;
    this.loadingSearch = false;
    $scope.$on(MessagingService.filtersReset, (event, data) => {
      this.searchModel = null;
    });
    $scope.$on(MessagingService.playlistSelected, (event, data) => {
      if (angular.equals({},this.playlistsManager.selectedPlaylist)){
        this.searchModel = null;
      }else{
        this.searchModel = this.playlistsManager.selectedPlaylist;
      }
    });

  }

  search(val) {

    if (val.length >= 2){
      this.loadingSearch = true;
      var promise = this.playlistService.searchByName(val)
        .then((response)=> {
          this.loadingSearch = false;
          return response.data.result.hits.hits
        },(err)=>{
          this.loadingSearch = false;
          console.error(err);
        });
      return promise;
    }else {
      return null;
    }
  }
  onSearchSelected($item, $model, $label) {
    this.playlistsManager.selectedPlaylist = $item;
  };
}

class PlaylistSearchBoxComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'PlaylistSearchBoxCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div class="playlist_search_wrapper">
          <form role="search">
            <div id="playlist_search_div">
              <script type="text/ng-template" id="playlist-typeahead-item.html">
                <a class="typeahead-drop-item">
                  <span ng-bind-html="match.label | uibTypeaheadHighlight:query" style="white-space: normal;"></span>
                </a>
              </script>
              <i ng-show="ctrl.loadingSearch && ctrl.searchModel.length>=2" class="fa-li fa fa-spinner fa-spin"
                 style="top: 8.5px;color: black;left: 301px;font-size: 11px;"></i>
              <!--todo there is a style class for this but doesn't work on aws-->
              <input type="text" ng-model="ctrl.searchModel" placeholder="Search for a playlist"
                     uib-typeahead="item as item._source.name + ' by ' +  item._source.createdBy for item in ctrl.search($viewValue)"
                     typeahead-loading="loadingSearch"
                     typeahead-template-url="playlist-typeahead-item.html"
                     typeahead-on-select='ctrl.onSearchSelected($item, $model, $label)'
                     ><!--typeahead-show-hint="true"-->
            </div>
          </form>
        </div>`;
  }
}

register('auditionApp').directive('playlistSearchbox', PlaylistSearchBoxComponent);
register('auditionApp').controller('PlaylistSearchBoxCtrl', PlaylistSearchBoxCtrl);

