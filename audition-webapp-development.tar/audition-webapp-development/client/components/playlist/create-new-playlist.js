/**
 * Created by davide on 19/08/2016.
 */

'use strict';
class CreatePlaylistCtrl {
  constructor($rootScope, $scope, playlistService, playlistsManager, usersManager,
              messagingService) {
    this.playlistService = playlistService;
    this.playlistsManager = playlistsManager;
    this.messagingService = messagingService;
    this.userName = usersManager.user.userName;
    this.playlist = playlistsManager.selectedPlaylist;
    this.action = $scope.action;

    $scope.$on(MessagingService.searchPlaylistSelected, (event, data) => {
      if (data.searchId == this.action + "Playlist") {
        this.playlistsManager.selectedPlaylist = data.selectedItem;
        if (this.playlist && this.playlist._source.tracks) {
          this.playlistTotalLength = this.playlist._source.tracks.reduce((prev, curr) => prev + curr.length, 0);
        }
      }
    });
  }

  onCreateNewTextKeyUp($event){
    if ($event.keyCode == 13) {
      this.playlistSaving = true;
      this.playlistService.updatePlaylist({_source:{name:this.newTitle}})
        .then((response) => {
            this.playlist = response.data.result.hits.hits[0];
            this.playlistsManager.selectedPlaylist = this.playlist;
            this.playlistSaving = false;
            this.showCreateNewText = false;
          }, (response) => {
            if (response.status > 0) {
              $scope.errorMsg = response.status + ': ' + response.data;
            }
            this.playlistSaving = false;
            this.showCreateNewText = false;
          }
        );
    }
  }

}

class CreatePlaylistComponent {

  constructor() {
    this.scope = {
      action: "@"
    };
    this.replace = true;
    this.controller = 'CreatePlaylistCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `<div class="popup_content">
                  <p style="font-size: 11px;color: #de534a;margin: -31px 0px 20px 3px;">{{ctrl.error}}</p>
                <md-input-container><label><p>Please provide an unique name for the new playlist</p></label>
                <input id="txt_playlist_name" type="text" ng-model="ctrl.playlistName"
                 ng-keydown="$event.which === 13 ? confirm($event,modal) : 0" ></md-input-container>`;
  }
}

register('auditionApp').directive('createPlaylist', CreatePlaylistComponent);
register('auditionApp').controller('CreatePlaylistCtrl', CreatePlaylistCtrl);




