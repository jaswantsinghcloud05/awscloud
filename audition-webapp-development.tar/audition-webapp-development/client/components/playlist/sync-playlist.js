/**
 * Created by davide on 19/08/2016.
 */

'use strict';
class SyncPlaylistCtrl {
  constructor($rootScope, $scope, $window, playlistService, playlistsManager, usersManager,
              tracksManager, messagingService, Modal, REST_BASE_URL, AMPLIFY_URL, $mdToast){
    this.window = $window;
    this.mdToast = $mdToast;
    this.restBaseUrl = REST_BASE_URL;
    this.playlistService  = playlistService;
    this.playlistsManager = playlistsManager;
    this.tracksManager = tracksManager;
    this.usersManager = usersManager;
    this.messagingService = messagingService;
    this.userName = usersManager.user.userName;
    this.userType = usersManager.userType;
    this.modal = Modal;
    this.playlist = playlistsManager.selectedPlaylist;
    this.searchModel = null;
    this.newTitle = "";
    this.showCreateNewText = false;
    this.playlistSaving = false;
    this.working = false;
    this.playlistTotalLength = 0;
    this.progressModal;
    this.amplifyUrl = AMPLIFY_URL;

    var self = this;
    this.sortableOptions = {
      stop(e, ui){
        self.messagingService.broadcast(MessagingService.playlistItemMoved, {fromIdx: ui.item.sortable.index, toIdx: ui.item.sortable.dropindex});
      }
    };

    $scope.$on(MessagingService.playlistSelected, (event, data) => {
      this.playlist = this.playlistsManager.selectedPlaylist;
      if(usersManager.user){
        this.userName = usersManager.user.userName;
      }
      this.messagingService.broadcast(MessagingService.audioPlaying);
      if (this.playlist._source && this.playlist._source.tracks) {
        this.playlistTotalLength = this.playlist._source.tracks.reduce((prev, curr) => prev + curr.length, 0);
      }
    });

    $scope.$on(MessagingService.playlistItemMoved, (event, data) => {
      this.playlistsManager.updateCurrentPlaylist();
    });

    $scope.$on(MessagingService.filtersReset, (event, data) => {
      this.playlist = {};
      playlistsManager.selectedPlaylist = {};
    });

  }

  $onInit(){
    this.isAmplifyUser = this.usersManager.isInGroup(UsersManager.amplifyUser);
  }

  onSendToBoxClick(){
    var status;
    if (this.progress){
      this.progress.close();
      status = {data:{status:200, progress: 0, message:"Preparing copy"}};
    }else{
      status = {data:{status:200, progress: 0, message:"Authenticating to box"}};
    }
    this.progress = this.modal.confirm.showProgress(this.playlist, status);
    this.playlistService.saveToBox(this.playlist, status)
      .then((response)=>{
        this.progress = null;
      },(response) => {
        if (response.status == 401 && response.data.source == "box.com") {
          var w = 500;
          var h = 700;
          // var left = (this.window.innerWidth/2)-(w/2);
          // var top = (this.window.innerHeight/2)-(h/2);
          //TODO do redirection in nodejs
          var url = this.restBaseUrl + "/auth/box/login?action=save&token=" + this.userName;
          this.window.open(url, "Box login", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h);
          status.data = {status:500, progress: 100, message:"User authentication required"};
        }else if (response.status == 409){
          status.data = {status:500, progress: 100, message:"Unable to override existing playlist folder"}
        }else{
          status.data = {status:500, progress: 100, message:response.data.result.message}
        }
      })
  }

  onTrackRowSelect(track) {
    if (track != this.tracksManager.selectedTrack) {//TODO always false at the moment because the playlist track is never the selected track
      this.tracksManager.loadSelectedTrack(track.r2_resource_id);
      this.playlist._source.tracks.forEach(function(item){
        item.selected = false;
      });
    }
  }

  onRemoveTrackClick(track) {
    var tracks = this.playlist._source.tracks;
    var index = tracks.indexOf(track);
    this.messagingService.broadcast(MessagingService.audioPlaying);
    tracks.splice(index, 1);
    this.playlistService.updatePlaylist(this.playlist)
      .then((data) =>{
        this.playlistsManager.selectedPlaylist = data.data.result.hits.hits[0];
        this.messagingService.broadcast(MessagingService.playlistSelected);
      },(error) =>{
        this.playlist._source.tracks.push(track);
        if(error.status == "409"){
          this.playlistService.getPlaylist(this.playlist._id)
            .then((data) => {
              this.playlistsManager.selectedPlaylist  = data.data.result.hits.hits[0];
              this.onRemoveTrackClick(track);
            },(error) => {
              //TODO
            });
        }
      });
  }

  onCreateTextEmailClick() {
    if (this.playlist){
      var emailText = this.playlistsManager.createPlaylistTextEmail();
      if(emailText.length <= 1400){
        this.window.location.href = "mailto:?body=" + encodeURIComponent(this.playlistsManager.createPlaylistTextEmail());
      }else{
        this.modal.information.playlistEmailText(emailText);
      }
    }
  }

  onDuplicatePlaylistClick() {
    this.modal.confirm.createPlaylist("duplicate", this.playlist._source.name);
  }

  onRenamePlaylistClick() {
    this.modal.confirm.createPlaylist("rename", this.playlist._source.name);
  }

  onCreateNewPlaylistClick() {
    this.modal.confirm.createPlaylist("create");
  }

  onDeletePlaylistClick() {
    this.modal.confirm.delete(this.playlist);
  }

  onPlaylistSaveClick = function() {
    if ($scope.playlist && $scope.playlist.selectedForSave) {
      $scope.playlistSaving = true;
      if ($rootScope.playlists.indexOf($scope.playlist.selectedForSave) > -1) {
        Modal.confirm.merge(copyPlaylist)($scope.playlist.selectedForSave, $rootScope.playlistName, $scope.playlist.selectedForSave);
      } else {
        playlistService.copyPlaylist($rootScope.playlistName, $scope.playlist.selectedForSave)
          .then(function () {
              $rootScope.playlists.push($scope.playlist.selectedForSave);
              $scope.playlistSaving = false;
            }, function (response) {
            if (response.status > 0) {
              $scope.errorMsg = response.status + ': ' + response.data;
            }
            this.playlistSaving = false;
          });
      }
    }
  }

  onSendEmailClick = function(element) {
    this.playlistService.sendPlaylistEmail(this.playlist)
      .then(() =>{
        this.mdToast.show(
          this.mdToast.simple()
            .textContent('Done! An email will be with you shortly')
            .parent(document.querySelectorAll('#toaster'))
            .position('top left')
            .hideDelay(8000)
        );
      }
    );
  }

  onSendPlaylistToAmplify = function(element) {
    this.mdToast.show(
      this.mdToast.simple()
        .textContent('Sending tracks to Amplify...')
        .parent(document.querySelectorAll('#toaster'))
        .position('top left')
        .hideDelay(8000)
    );
    this.playlistService.sendPlaylistToAmplify(this.playlist)
      .then((result) =>{
        window.location.href = this.amplifyUrl + "/?sessionId=" + result.config.data.recordingSessionId
      }, (error) =>{
        this.modal.information.message("Amplify Service Error", "Unable to contact the Amplify service");
        console.error(error);
      })
  }
}



class SyncPlaylistComponent {

  constructor() {
    this.scope = {};
    this.replace = true;
    this.controller = 'SyncPlaylistCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `
          <div id="playlist_panel">
          
              <div id="playlist_header_info">
                <div class="playlist-details">
                  <div style="display: inline-flex; width: 100%;">
                    <button id="new_playlist_button" ng-click="ctrl.onCreateNewPlaylistClick()" class="btn btn-default"
                            title="Save new playlist">
                      <span class="fa fa-plus" style="margin: 0px 9px 5px 9px;"></span>
                    </button>
                    <div style= "margin-top:3px; width:100%">
                      <playlist-searchbox style></playlist-searchbox>
                    </div>
                  </div>
                  <br style="clear: both;"> 
                  <div style="padding: 0px 0 0 42px;">
                  <i ng-show="ctrl.playlistSaving" class="fa-li fa fa-spinner fa-spin"
                       style="style="top: 11px;color: black;l;left: 313px;font-size: 11px;""></i>
                  <p>Created by {{ctrl.playlist._source.createdBy}}</p>
                  <p>On {{ctrl.playlist._source.createdDate | date : 'dd MMM yyyy'}}</p>
                  </div>
                  <div><span id="playlist_visibility_status" class="public_playlist_status">Public</span></div>

                </div>          
              </div>
          
              <md-content>
                <md-tabs md-no-pagination="true" md-border-bottom="">
                  <md-tab>
                    <md-tab-label> <i class="fa fa-list" aria-hidden="true"></i> </md-tab-label>
                    <md-tab-body>
                      <div>
                        <div class="playlist-tracks-heading"><h3>{{ctrl.playlist._source.tracks.length}} Tracks
                        <span style="float: right;">{{ctrl.playlistTotalLength | secondsToDateTime | date:'HH:mm:ss'}}</span></h3></div>
                        <div class="playlist_scrollable">
                         <table class="table" style="margin-top: 31px; border-style: hidden;">
                          <tbody ui-sortable="ctrl.sortableOptions" ng-model="ctrl.playlist._source.tracks">
                          <tr ng-repeat='item in ctrl.playlist._source.tracks | orderBy:$index track by item.r2_resource_id'
                              class="yoyo" ng-class="(item.selected) ? 'playlist-row-selected' : ''"
                              ng-click="ctrl.onTrackRowSelect(item)"
                              style="cursor: move;">
                            <td style="padding-top: 7px;">
                              <div id="btn_30sec_playlist_{{item.r2_resource_id}}"
                                   ng-click="onStartPlayingClick(item.track)"
                                   tooltip='Play 30 sec clip'
                                   tooltip-placement="top"
                                   tooltip-trigger="mouseenter"
                                   tooltip-popup-delay='1000'
                                   style="min-width: 36px;height: 0px;margin-top: -4px; position:relative; cursor: pointer;">
                                   <knob-player html-id="playlist_knob_{{item.r2_resource_id}}" track="item" knob-max='max'
                                      knob-options="knobOptions"></knob-player>
                              </div>
                            </td>
                            <td id="td_artist_track_{{item.r2_resource_id}}">
                              <span style="font-size: 11px; vertical-align: top;" tooltip="{{item.formatted_title}}"
                                      tooltip-placement="top"
                                      tooltip-trigger="mouseenter"
                                      tooltip-popup-delay='1000'>{{item.formatted_title}} by {{item.artist_name}}</span>
                            <td id="td_playlist_track_length_{{item.r2_resource_id}}">
                            <span style="font-size: 11px; vertical-align: top;">{{item.length | secondsToDateTime | date:'HH:mm:ss'}}</span></td>
                            </td>
                            <td style="padding-right: 10px;">
                                  <span id="btn_remove_track_{{item.r2_resource_id}}" class="glyphicon glyphicon-remove" 
                                        style="color: #df6c64;vertical-align: inherit;"
                                        ng-hide="item.removing"
                                        ng-click="ctrl.onRemoveTrackClick(item);$event.stopPropagation()"></span>
                              <span class="fa fa-spinner fa-spin" ng-show="item.removing"></span>
                            </td>
                          </tr>
                          </tbody>
                        </table>
         
                        </div>              
                      </div>
                    </md-tab-body>
                  </md-tab>
                  <md-tab>
                    <md-tab-label> <i class="fa fa-cog" aria-hidden="true"></i> </md-tab-label>
                    <md-tab-body>
                      <div>
                        <div><h3>Playlist Settings</h3></div>
                        <div class="playlist-action-tab">
                            <p><a ng-class="{'disabled':!ctrl.playlist._source || ctrl.userName!=ctrl.playlist._source.createdBy || ctrl.playlist._source.box_public_url}" ng-click="ctrl.onRenamePlaylistClick();" href="#">Rename playlist</a></p>
                            <p><a ng-show="ctrl.userType==='E'" ng-class="{'disabled':!ctrl.playlist._source || ctrl.userName!=ctrl.playlist._source.createdBy}" ng-click="ctrl.onDeletePlaylistClick();" href="#">Delete playlist</a></p>
                            <p><a ng-class="{'disabled':!ctrl.playlist._source }" ng-click="ctrl.onDuplicatePlaylistClick();" href="#">Copy playlist</a></p>
                            <p><a ng-class="{'disabled':true}" ng-click="" href="#">Playlist privacy settings</a></p>
                        </div>              
                      </div>
                    </md-tab-body>
                  </md-tab>
                  <md-tab ng-disabled="true" select="refreshSlider()">
                    <md-tab-label> <i class="fa fa-info" aria-hidden="true"></i> </md-tab-label>
                    <md-tab-body>
                      <div >
                        <div><h3>Playlist Information</h3></div>
                        <div>
                          <!--<ul>
                            <li>Further details about playlist TBC</li>
                            <li>Annotations</li>
                            <li>Performance statistics</li>
                            <li>Tags</li>
                          </ul>-->
                          Coming soon ...
                        </div>
                       </div>
                    </md-tab-body>
                  </md-tab>
                  <md-tab>
                    <md-tab-label> <i class="fa fa-share" aria-hidden="true"></i> </md-tab-label>
                    <md-tab-body>
                      <div>
                        <div id="toaster"><h3>Share, Import &amp; Export</h3></div>
                        <div class="playlist-action-tab">
                            <p><a ng-class="{'disabled':!(ctrl.playlist._source && ctrl.playlist._source.tracks && ctrl.playlist._source.tracks.length >0) }" ng-click="ctrl.onSendToBoxClick();" href="#">Share playlist</a></p>
                            <p><a ng-show="ctrl.userType==='E'" ng-class="{'disabled':!(ctrl.playlist._source && ctrl.playlist._source.tracks && ctrl.playlist._source.tracks.length >0) }" ng-click="ctrl.onCreateTextEmailClick();" href="#">Re-send email</a></p>
                            <p><a ng-show="ctrl.userType==='P'" ng-class="{'disabled':!(ctrl.playlist._source && ctrl.playlist._source.tracks && ctrl.playlist._source.tracks.length >0) }" ng-click="ctrl.onSendEmailClick(this);" href="#">Re-send email</a></p>
                            <p><a ng-show="ctrl.isAmplifyUser" ng-class="{'disabled':!(ctrl.playlist._source && ctrl.playlist._source.tracks && ctrl.playlist._source.tracks.length >0) }" ng-click="ctrl.onSendPlaylistToAmplify();" href="#">Tag playlist in amplify</a></p>
                        </div>              
                      </div>
                    </md-tab-body>
                  </md-tab>
                </md-tabs>
              </md-content>
          </div>
    `;
  }
}

register('auditionApp').directive('syncPlaylist', SyncPlaylistComponent);
register('auditionApp').controller('SyncPlaylistCtrl', SyncPlaylistCtrl);




