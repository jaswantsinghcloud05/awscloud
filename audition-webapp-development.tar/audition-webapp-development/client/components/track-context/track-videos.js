
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class TrackVideosCtrl {
  constructor($scope, $rootScope, playlistsManager, trackService, tracksManager,
              keysManager, paginationManager, urlStatusManager, Modal){
    this.rootScope = $rootScope;
    this.maxInitilized = false;
    this.trackService  = trackService;
    this.keysManager = keysManager;
    this.tracksManager = tracksManager;
    this.paginationManager = paginationManager;
    this.urlStatusManager = urlStatusManager;
    this.modal = Modal;
    this.totalItems = 0;
    this.maxSize = 5;
    this.currentPage = 1;
    this.pageSize = this.trackService.searchCriteria.pageSize;
    this.itemsPerPage = this.trackService.searchCriteria.pageSize;
    this.sorting = false;

    this.videos = [];
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.tabSelected, (event) => {
      this.loadTracks();
    })
    $scope.$on(MessagingService.trackListUpdated, (event) => {
      this.tracks = this.tracksManager.currentTracks;
      this.videos.length = 0;
      this.tracks.forEach((item)=> {
        if (item._source.videos){
          this.videos = this.videos.concat(item._source.videos);
        }
      })
    })

  }

  $onInit(){
    //makes sure to lOad the data at 1st initialization if there are parameters in the url
    this.loadTracks();
  }
  loadTracks(){
    if (this.currentCriteria!==this.trackService.searchCriteria && this.urlStatusManager.urlStatus.tab=="trackVideos") {
      angular.copy(this.trackService.searchCriteria,this.currentCriteria);
      this.tracksManager.applyNewFilters();
    }
  }
  /**
   * The form data
   * @memberof simple-table.SimpleTrackTableCtrl
   * @type {Object}
   * @property {String} fieldName column name to use for sorting
   * @property {String} order 1 asc, -1 desc
   * @todo at the moment it only handles sorting by one column even if the trackService
   * supports multiple column sorting
   */
  toggleSort(fieldName, order){
    var sort = this.trackService.searchCriteria.columnSorting;
    if (order==undefined){
      order = 1;
    }
    if(sort.length>0){
      if(sort[0][fieldName] != undefined){
        sort[0][fieldName] = sort[0][fieldName] * -1;
      }else{
        this.trackService.searchCriteria.columnSorting[0] = {[fieldName]: order};
      }
    } else {
      this.trackService.searchCriteria.columnSorting.push({[fieldName]:order})
    }
    this.sortBy = this.trackService.searchCriteria.columnSorting;
    this.sorting = true;
    var skip = this.trackService.searchCriteria.pageSize*(this.paginationManager.currentPage-1);
    var tracks;
    this.tracksManager.refreshTracks(skip).finally(() => {//TODO use .then instead of .error, .finally
      this.sorting = false;
    });
  }

  /*
   *   TRACK LIST PAGINATION
   */
  onPageChanged() {
    var searchId;
    this.sorting =true;
    this.trackService.searchCriteria.id = Date.now();
    this.tracksManager.refreshTracks(this.itemsPerPage*(this.currentPage-1))
      .error(function (data, status, headers, config){//TODO use .then instead of .error, .finally
        //TODO show some sort of message
      }).finally(() =>{
      this.sorting = false;
    });
  }

  onVideoPlayClick(vevoId, youtubeId){
    var videoUrl;
    // if (vevoId){
    //   videoUrl = '<iframe width="100%" height="100%" src="http://cache.vevo.com/m/html/embed.html?video=' + vevoId +'&autoplay=1" frameborder="0" allowfullscreen></iframe>';
    // }else{
      videoUrl = '<iframe width="100%" height="100%" src="//www.youtube.com/embed/' + youtubeId + '?autoplay=1" frameborder="0" allowfullscreen></iframe>';
    // }
    this.modal.information.video(videoUrl)
  }
}

let TrackVideosComponent = {


  binding : {},
  controller : 'TrackVideosCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="tracks_list_tbl" class="table track-videos context-table">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th>VEVO</th>
                    <th><span class="column-header">Title</span></th>
                    <th><span class="column-header">Last Updated</span></th>
                    <th><span class="column-header">Private</span></th>
                    <th><span class="column-header">Views Count</span></th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr ng-repeat='item in ctrl.videos' style="height: 66px">
                    <td id="td_video_{{item.video_isrc}}_thumbnail">
                      <div style="position: relative" ng-click="ctrl.onVideoPlayClick(item.video_isrc, item.youtube_id)">
                        <i class="play-video-icon material-icons">play_circle_outline</i>
                        <img class="youtube-thumb" ng-src="http://img.youtube.com/vi/{{item.youtube_id}}/maxresdefault.jpg"
                             tooltip="{{item.title}}"
                             tooltip-placement="top"
                             tooltip-trigger="mouseenter"
                             tooltip-popup-delay='500'>
                      </div>
                    </td>
                    <td id="td_video_{{item.video_isrc}}_title">
                    <span uib-tooltip="{{item.title}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'>{{item.title}}</span></td>
                    <td id="td_video_{{item.video_isrc}}_date">{{item.updated_date | date : 'mediumDate'}}</td>
                    <td id="td_video_{{item.video_isrc}}_private">{{item.private_on_vevo}}</td>
                    <td id="td_video_{{item.video_isrc}}_views">{{item.views_count}}</td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              <div ng-show="ctrl.totalItems>0" style="position: absolute;left: 19vw;">
                <uib-pagination ng-change="ctrl.onPageChanged()"
                                total-items="ctrl.totalItems" ng-model="ctrl.currentPage" max-size="ctrl.maxSize" class="pagination-sm"
                                boundary-links="true" rotate="false" items-per-page="ctrl.itemsPerPage"></uib-pagination>
              <!--  <div style="max-width: 9vw;margin-left: 30px;" class="input-group">
                  <input type="text" ng-model="ctrl.pageSize" class="form-control" style="height: 29px;" size="5">
                  <span class="input-group-btn">
                          <button ng-click="ctrl.onPageResizeClick()" class="btn btn-default"
                                  title="Tracks per page" style="height: 29px;">
                            <span class="fa fa-retweet" style="vertical-align: top;"></span></button>
                  </span>
                </div>-->
              </div>
              <span ng-show="ctrl.totalItems>0" style="float: right;margin-top: 1vh;margin-right: 4vh;">
                Showing tracks <strong>{{ctrl.itemsPerPage * (ctrl.currentPage-1)}}</strong> to <strong>{{ctrl.itemsPerPage *
                ctrl.currentPage}}</strong> of <strong>{{ctrl.totalItems}}</strong>
              </span>
              </div>
              `
}

angular.module('auditionApp').component('trackVideos', TrackVideosComponent);
angular.module('auditionApp').controller('TrackVideosCtrl', TrackVideosCtrl);

