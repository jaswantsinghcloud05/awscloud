
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class TrackContextCtrl {
  constructor($scope, $rootScope, $stateParams, $timeout, urlStatusManager,tracksManager,messagingService, usersManager){
    this.rootScope = $rootScope;
    this.scope = $scope;
    this.tracksManager = tracksManager;
    this.urlStatusManager = urlStatusManager;
    this.messagingService = messagingService;
    this.timeout = $timeout;
    this.selectedTrack = this.tracksManager.selectedTrack;
    this.usersManager = usersManager;

    $scope.$on(MessagingService.trackListUpdated, (event) => {
      this.tracks = this.tracksManager.currentTracks;
      this.tracks.forEach((item)=>{
        if (item._source.r2_resource_id == this.urlStatusManager.status.selectedTrack){
          this.selectedTrack = item._source;
          this.selectedTrack.largeThumbnailUrl = "/api/tracks/" + this.selectedTrack.r2_resource_id + "/assets/thumbnail-large"
        }
      })
    })

    $scope.$on(MessagingService.urlChanged, (event) => {
      this.selectTab();
      this.timeout(() =>{
        //TODO need to wait the new tab is selected
        this.messagingService.broadcast(MessagingService.tabSelected);//TODO use RxJs
      }, 100);
    })
    this.selectTab();
  }

  selectTab(){
    switch (this.urlStatusManager.status.tab) {
      case "trackVersions":
        this.selectedIndex = 0;
        break;
      case "trackAlbums":
        this.selectedIndex = 1;
        break;
      case "trackPlaylists":
        this.selectedIndex = 2;
        break;
      case "trackVideos":
        this.selectedIndex = 3;
    }
  }

  onTabSelected(tabName){
    this.urlStatusManager.status.tab = tabName;
    this.urlStatusManager.updateUrl("/track-context");//TODO make this call automatic in USM when the status is update
  }

  onReturnToFullCatalogClick(){
    this.urlStatusManager.status.tab = "tracks";
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.updateUrl("/tracks-filters");//TODO make this call automatic in USM when the status is update
  }

  $onInit(){
    this.isEmployee = (this.usersManager.userType === UsersManager.employee);
    this.isAmplifyUser = this.usersManager.isInGroup(UsersManager.amplifyUser);
  }

}

let TrackContextComponent = {

    binding : {},
    controller : 'TrackContextCtrl',
    controllerAs : 'ctrl',
    //todo check why templeUrl not working after grunt build
    template : `
                <div id="track_context" style="overflow-x: hidden;position:relative;left: 25px;top:-76px">
                  <div id="context_wrapper"><img http-src="{{ctrl.selectedTrack.largeThumbnailUrl}}" id="context_image">
                    <h2 class="win-scroll">{{ctrl.selectedTrack.formatted_title}}</h2>
                    <p class="standard_text">Track by {{ctrl.selectedTrack.artist_name}}&nbsp;&nbsp;|&nbsp;&nbsp;{{ ctrl.selectedTrack.release_date | date : 'mediumDate'}}&nbsp;&nbsp;|&nbsp;&nbsp;Duration: {{ctrl.selectedTrack.length | secondsToDateTime | date:'HH:mm:ss'}}
                      <md-menu id="context_menu">
                        <md-button id="context_menu_button" ng-click="$mdMenu.open($event)" class="md-icon-button">
                            <i class="material-icons">more_vert</i>
                        </md-button>
                        <md-menu-content>
                            <md-menu-item>
                                <md-button ng-disabled="true">Instant Export</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-disabled="true">Show Filtered Tracks</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-click="ctrl.onReturnToFullCatalogClick()">Return to Full Catalogue</md-button>
                            </md-menu-item>
                        </md-menu-content>
                      </md-menu>
                    </p>
                  </div>
                  <md-content style="background-color: white;">
                    <md-tabs md-selected="ctrl.selectedIndex" md-dynamic-height="" md-no-pagination="true" md-enable-disconnect="true">
                      <md-tab ng-click='ctrl.onTabSelected("trackVersions")'>
                        <md-tab-label>
                          Versions
                        </md-tab-label>
                        <md-tab-body>
                          <track-versions></track-versions>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-click='ctrl.onTabSelected("trackAlbums")'>
                        <md-tab-label>
                          Appears on Albums
                        </md-tab-label>
                        <md-tab-body>
                          <track-albums></track-albums>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-if="ctrl.isEmployee" ng-click='ctrl.onTabSelected("trackPlaylists")'>
                        <md-tab-label>
                          Featured in Playlists
                        </md-tab-label>
                        <md-tab-body>
                          <fix-playlist-table tab-id="'trackPlaylists'"></fix-playlist-table>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-click='ctrl.onTabSelected("trackVideos")'>
                        <md-tab-label>
                          Videos
                        </md-tab-label>
                        <md-tab-body>
                          <track-videos></track-videos>
                        </md-tab-body>
                      </md-tab>
                    </md-tabs>
                  </md-content>
                </div>
              `
}

angular.module('auditionApp').component('trackContext', TrackContextComponent);
angular.module('auditionApp').controller('TrackContextCtrl', TrackContextCtrl);

