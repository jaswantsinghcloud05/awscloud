
'use strict';
/**
 * This file contains view and controller of the track-versions directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 *
 * TODO the table component could be extracted and merged with fix-tracks-table
 * */

class TrackVersionsCtrl extends FixTrackTableCtrl{
  constructor($scope, $rootScope, playlistsManager, trackService, tracksManager,
              keysManager, paginationManager, urlStatusManager, Modal, albumsManager,
              usersManager, AMPLIFY_URL){
    super($scope, $rootScope, playlistsManager, trackService, tracksManager,
      keysManager, paginationManager, urlStatusManager, Modal, albumsManager,
      usersManager, AMPLIFY_URL);
  }


  loadTracks(){
    if (this.currentCriteria!==this.trackService.searchCriteria && this.urlStatusManager.urlStatus.tab=="trackVersions") {
        angular.copy(this.trackService.searchCriteria,this.currentCriteria);
        this.tracksManager.applyNewFilters();
    }
  }

  onVideoIconClick(){
    this.urlStatusManager.status.tab = "trackVideos";
    this.urlStatusManager.updateUrl("/track-context");//TODO make this call automatic in USM when the status is update
  }

}

let TrackVersionsComponent = {


  binding : {},
  controller : 'TrackVersionsCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="tracks_list_tbl" class="table tracks-fix-column context-table">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th style="width:7.5%">
                       <div style="display:flex;margin-top: -17px;">
                       <i id="rights_tab_btn" class="fa fa-copyright ng-scope" style="margin-top: 23px; margin-right: -2px;" aria-hidden="true"></i>
                       <md-switch class="_md-thumb" ng-model="ctrl.metaData" aria-label="filter_toggle" ng-true-value="true" ng-false-value="false"
                       style="height: 0px; width:37px"> </md-switch>
                          <md-tooltip md-direction="left">{{ctrl.metaData ? "Metadata" : "Rights"}}</md-tooltip>
                       <i id="metadata_tab_btn" class="fa fa-microphone ng-scope" style="margin-top: 23px; margin-left: -2px;" aria-hidden="true"></i>
                    </div>
                    </th>
                    <th><a href="#" ng-click="ctrl.toggleSort('formatted_title.keyword')" class="column-header">Title</a></th><!--ng-click="ctrl.toggleSort('formatted_title')" -->
                    <th><a href="#" class="column-header">Artist</a></th><!--ng-click="ctrl.toggleSort('canopus_artist_name')"  -->
                    <th><a href="#" ng-click="ctrl.toggleSort('release_date')" class="column-header">Year</a></th><!-- -->
                    <th><a href="#" ng-click="ctrl.toggleSort('length')" class="column-header">Duration</a></th><!-- -->
                    <th>Label</th><!-- ng-click="ctrl.toggleSort('popularity')" -->
                    <th>UMG Genre</th>
                    <th>{{!ctrl.metaData ? "Publish" : "Ed/Ex"}}</th>
                    <th>{{!ctrl.metaData ? "Record" : "Vox/Inst"}}</th>
                    <th><span ng-show="!ctrl.metaData">Territory</span><a ng-show="ctrl.metaData" href="#" ng-click="ctrl.toggleSort('rhythm_bpm_mean')" class="column-header">Speed(BPM)</a></th>
                  </tr>
                  </thead>
                  <tbody class="table-hover noselect">
                  <tr ng-repeat='item in ctrl.tracks'
                      ng-class="(item.selected==true)?'row-selected':''"
                      ng-click="ctrl.onTrackRowSelect($index, item._source)">
                    <td style="width:7.5%">
                      <div style="display:flex; margin-left:-1px">
                        <span id="btn_add_track_to_playlist_{{item._source.r2_resource_id}}" 
                              class="glyphicon glyphicon-plus-sign"
                              style="margin-right: 3px;font-size: 15px;"
                              ng-click="ctrl.onAddToPlaylistClick(item._source);$event.stopPropagation()"></span>
                        <div ng-click="ctrl.onStartPlayingClick(item)"
                             uib-tooltip='Play 30 sec clip'
                             tooltip-placement="top"
                             tooltip-trigger="mouseenter"
                             tooltip-popup-delay='1000'>
                          <knob-player track="item._source" knob-max='max'
                                knob-options="knobOptions" html-id="track_knob_{{item._source.r2_resource_id}}"></knob-player>
                        </div>
                        <span id="track-play-icon" ng-click="ctrl.onTrackPlayClick($index, item._source)"
                           class="fa fa-play"  style="margin: 3px 3px 0px -17px;">
                         </span>
                         <img ng-click="ctrl.onVideoIconClick()" http-src="/assets/images/vevo-ico.png" ng-show="item._source.videos" 
                            style="width: 15px; height: 15px; margin: 0px 3px 0px 0px;cursor:pointer">
                         <img ng-show="ctrl.isAmplifyUser" src="assets/images/amplify_logo.svg" ng-click="ctrl.onSendToAmplifyClick(item._source)"
                          class="amplify_button" ng-class="{'amplify-spinning': item._source.imageSpinning==true}">
                      </div>
                    </td>
                    <td id="td_title_{{item._source.r2_resource_id}}">
                    <span uib-tooltip="{{item._source.formatted_title}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'>{{item._source.formatted_title}}</span></td>
                    <td id="td_artist_name_{{item._source.r2_resource_id}}">
                      <span uib-tooltip="{{item._source.artist_name}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'><a id="a_artist_{{item._source.r2_resource_id}}" ng-click="ctrl.onArtistInfoClick($index, item._source)">{{item._source.artist_name}}</a></span></td>
                    <td id="td_release_{{item._source.r2_resource_id}}">{{ item._source.release_date | date : 'yyyy'}}</td>
                    <td id="td_length_{{item._source.r2_resource_id}}">{{item._source.length | secondsToDateTime | date:'HH:mm:ss'}}</td>
                    <td id="td_label_{{item._source.r2_resource_id}}">
                      <span uib-tooltip="{{item._source.label_name}}">{{ item._source.label_name}}</span></td>
                    <td>{{ item._source.track_genre}}</td>
                    <td>
                    <span ng-show="ctrl.metaData"></span>
                    <span ng-show="!ctrl.metaData" 
                                          uib-tooltip="{{ctrl.formatPublishers(item._source)}}"
                                          tooltip-class="fontSmallClass"
                                          tooltip-placement="top"
                                          tooltip-trigger="mouseenter"
                                          tooltip-popup-delay='1000'
                                          tooltip-append-to-body="true"
                                          style="text-align: center;">{{ctrl.getRightsShare(item._source)}}</span></td>
                    <td>
                    <span ng-show="ctrl.metaData"></span>
                    <div ng-show="!ctrl.metaData" style="min-width: 68px;">
                      <right-icons track="item"></right-icons>
                    </div>
                    </td>
                    <td>
                      <div ng-show="ctrl.metaData" style="text-align: center;margin-left: -17px;">{{ item._source.rhythm_bpm_mean | number : 0}}</div>
                      <span ng-show="!ctrl.metaData" uib-tooltip="{{item._source.territorial_right}}"
                                          tooltip-placement="top"
                                          tooltip-trigger="mouseenter"
                                          tooltip-popup-delay='1000'>
                          <!-- make a filter instead of conditions -->
                        <span ng-show='(item._source.territorial_right.indexOf("World")>=0 || item._source.territorial_right.indexOf("Universe")>=0)
                        && item._source.territorial_right.indexOf("Excluding")<0'>
                        World</span>
                        <span ng-show='(item._source.territorial_right.indexOf("World")>=0 || item._source.territorial_right.indexOf("Universe")>=0)
                        && item._source.territorial_right.indexOf("Excluding")>0'>
                        World Excludes</span>
                        <span ng-show='item._source.territorial_right.indexOf("World")<0 && item._source.territorial_right.indexOf("Universe")<0'>
                        Country</span>
                      </span>
                    </td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              <div ng-show="ctrl.totalItems>0" style="position: absolute;left: 19vw;">
                <uib-pagination ng-change="ctrl.onPageChanged()"
                                total-items="ctrl.totalItems" ng-model="ctrl.currentPage" max-size="ctrl.maxSize" class="pagination-sm"
                                boundary-links="true" rotate="false" items-per-page="ctrl.itemsPerPage"></uib-pagination>
              <!--  <div style="max-width: 9vw;margin-left: 30px;" class="input-group">
                  <input type="text" ng-model="ctrl.pageSize" class="form-control" style="height: 29px;" size="5">
                  <span class="input-group-btn">
                          <button ng-click="ctrl.onPageResizeClick()" class="btn btn-default"
                                  title="Tracks per page" style="height: 29px;">
                            <span class="fa fa-retweet" style="vertical-align: top;"></span></button>
                  </span>
                </div>-->
              </div>
              <span ng-show="ctrl.totalItems>0" style="float: right;margin-top: 1vh;margin-right: 4vh;">
                Showing tracks <strong>{{ctrl.itemsPerPage * (ctrl.currentPage-1)}}</strong> to <strong>{{ctrl.itemsPerPage *
                ctrl.currentPage}}</strong> of <strong>{{ctrl.totalItems}}</strong>
              </span>
              </div>
              `
}

angular.module('auditionApp').component('trackVersions', TrackVersionsComponent);
angular.module('auditionApp').controller('TrackVersionsCtrl', TrackVersionsCtrl);

