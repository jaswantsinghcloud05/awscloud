
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class TrackAlbumsCtrl {
  constructor($scope, $rootScope, trackService, tracksManager,
              albumService, paginationManager, urlStatusManager, Modal){
    this.rootScope = $rootScope;
    this.maxInitilized = false;
    this.trackService  = trackService;
    this.albumService = albumService;
    this.tracksManager = tracksManager;
    this.paginationManager = paginationManager;
    this.urlStatusManager = urlStatusManager;
    this.modal = Modal;
    this.totalItems = 0;
    this.maxSize = 5;
    this.currentPage = 1;
    this.pageSize = this.trackService.searchCriteria.pageSize;
    this.itemsPerPage = this.trackService.searchCriteria.pageSize;
    this.sorting = false;

    this.albums = [];
    //TODO replace $scope.$on with RxJs Observer patter
    $scope.$on(MessagingService.tabSelected, (event) => {
      this.loadTracks();
    })

    $scope.$on(MessagingService.trackListUpdated, (event) => {
      this.tracks = this.tracksManager.currentTracks;
      this.albums.length = 0;
      this.tracks.forEach((item)=> {
        if (item._source.albums){
          item._source.albums.forEach((album)=> {

            this.albumService.getAlbum(album.upc)
            .then((result) => {
              var album = result.data.result;
              if(album.thumbnail_large_filename) {
                album.thumbnail_large_filename = "/api/albums/" + album.upc + "/stream?file=" + encodeURIComponent(album.thumbnail_large_filename.substring(19));
              }else{
                album.thumbnail_large_filename = "not available";
              }
              if(!this.albums.find((item) => {
                return item.upc == album.upc
              })){
                this.albums.push(album);
              }
            })
          })
        }
      })
    })
  }

  $onInit(){
    //makes sure to lOad the data at 1st initialization if there are parameters in the url
    this.loadTracks();
  }
  loadTracks(){
    if (this.currentCriteria!==this.trackService.searchCriteria && this.urlStatusManager.urlStatus.tab=="trackAlbums") {
      angular.copy(this.trackService.searchCriteria,this.currentCriteria);
      this.tracksManager.applyNewFilters();
    }
  }
  /**
   * The form data
   * @memberof simple-table.SimpleTrackTableCtrl
   * @type {Object}
   * @property {String} fieldName column name to use for sorting
   * @property {String} order 1 asc, -1 desc
   * @todo at the moment it only handles sorting by one column even if the trackService
   * supports multiple column sorting
   */
  toggleSort(fieldName, order){
    var sort = this.trackService.searchCriteria.columnSorting;
    if (order==undefined){
      order = 1;
    }
    if(sort.length>0){
      if(sort[0][fieldName] != undefined){
        sort[0][fieldName] = sort[0][fieldName] * -1;
      }else{
        this.trackService.searchCriteria.columnSorting[0] = {[fieldName]: order};
      }
    } else {
      this.trackService.searchCriteria.columnSorting.push({[fieldName]:order})
    }
    this.sortBy = this.trackService.searchCriteria.columnSorting;
    this.sorting = true;
    var skip = this.trackService.searchCriteria.pageSize*(this.paginationManager.currentPage-1);
    var tracks;
    this.tracksManager.refreshTracks(skip).finally(() => {//TODO use .then instead of .error, .finally
      this.sorting = false;
    });
  }

  /*
   *   TRACK LIST PAGINATION
   */
  onPageChanged() {
    var searchId;
    this.sorting =true;
    this.trackService.searchCriteria.id = Date.now();
    this.tracksManager.refreshTracks(this.itemsPerPage*(this.currentPage-1))
      .error(function (data, status, headers, config){//TODO use .then instead of .error, .finally
        //TODO show some sort of message
      }).finally(() =>{
      this.sorting = false;
    });
  }

  onAlbumInfoClick(idx,album) {
    this.urlStatusManager.status.tab = "albumTracks";
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.filters.match.canopus_id = undefined;
    this.urlStatusManager.status.filters.match.upc = album.upc;
    this.urlStatusManager.updateUrl("/album-context");//TODO make this call automatic in USM when the status is update
  }

}

let TrackAlbumsComponent = {


  binding : {},
  controller : 'TrackAlbumsCtrl',
  controllerAs : 'ctrl',
  //todo check why templeUrl not working after grunt build
  template : `
              <div>
              <div class="full-white-overlay" ng-show="ctrl.sorting">
                <span class="fa fa-circle-o-notch fa-spin" style="
                  font-size: 200px;
                  color: rgba(230, 230, 230, 0.7);"></span>
                <!--<img src="/assets/images/Audition_Loading_Large.gif">-->
              </div>
              <div class="sl-track-div">
                <div class="container-fluid">
                  <!-- for scrollable table look at sfiddle.net/4NB2N/11/ or use pre-scrollable -->
                  <!-- create component insted of using ng-include -->
                <table id="tracks_list_tbl" class="table track-albums-fix-column">
                  <thead>
                  <tr style="background-color: #f0f2f2">
                    <th></th>
                    <th>Album Name</th>
                    <th>Release</th>
                    <th>Label</th>
                    <th>Upc</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr ng-repeat="item in ctrl.albums | orderBy:'p_notice_year':true">
                    <td id="td_album_{{item.upc}}_thumbnail">
                      <div style="position: relative">
                        <a id="a_title_{{item.upc}}" ng-click="ctrl.onAlbumInfoClick($index, item)">
                        <img class="album-thumb" http-src="{{item.thumbnail_large_filename}}">
                        </a>
                      </div>
                    </td>
                    <td id="td_album_{{item.album_isrc}}_title">
                      <a id="a_title_{{item.upc}}" ng-click="ctrl.onAlbumInfoClick($index, item)">
                        <span uib-tooltip="{{item.formatted_title}}"
                                  tooltip-placement="top"
                                  tooltip-trigger="mouseenter"
                                  tooltip-popup-delay='1000'>{{item.formatted_title}}</span>
                      </a></td>
                    <td id="td_album_{{item.album_isrc}}_date">{{item.p_notice_year}}</td>
                    <td id="td_album_{{item.album_isrc}}_label">
                    <span uib-tooltip="{{item.label_name}}"
                              tooltip-placement="top"
                              tooltip-trigger="mouseenter"
                              tooltip-popup-delay='1000'>
                              {{item.label_name}}</span></td>
                    <td id="td_album_{{item.album_isrc}}_views">{{item.upc}}</td>
                  </tr>
                  </tbody>
                </table>
                </div>
              </div>
              <div ng-show="ctrl.totalItems>0" style="position: absolute;left: 19vw;">
                <uib-pagination ng-change="ctrl.onPageChanged()"
                                total-items="ctrl.totalItems" ng-model="ctrl.currentPage" max-size="ctrl.maxSize" class="pagination-sm"
                                boundary-links="true" rotate="false" items-per-page="ctrl.itemsPerPage"></uib-pagination>
              </div>
              <span ng-show="ctrl.totalItems>0" style="float: right;margin-top: 1vh;margin-right: 4vh;">
                Showing tracks <strong>{{ctrl.itemsPerPage * (ctrl.currentPage-1)}}</strong> to <strong>{{ctrl.itemsPerPage *
                ctrl.currentPage}}</strong> of <strong>{{ctrl.totalItems}}</strong>
              </span>
              </div>
              `
}

angular.module('auditionApp').component('trackAlbums', TrackAlbumsComponent);
angular.module('auditionApp').controller('TrackAlbumsCtrl', TrackAlbumsCtrl);

