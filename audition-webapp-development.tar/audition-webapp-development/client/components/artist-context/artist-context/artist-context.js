
'use strict';
/**
 * This file contains view and controller of the simpleTracksTable directive.
 * This directive creates a html paginated table containing the tracks found in
 * this.tracksManager.currentTracks.
 *
 * The html table is sortable and each row contains a knobPlayer directive that gives
 * users the option to play an audio clip of each track
 * */

class ArtistContextCtrl {
  constructor($scope, $rootScope, $stateParams, $timeout, urlStatusManager,tracksManager,messagingService,
              artistsManager, usersManager){
    this.rootScope = $rootScope;
    this.scope = $scope;
    this.tracksManager = tracksManager;
    this.artistsManager = artistsManager;
    this.urlStatusManager = urlStatusManager;
    this.messagingService = messagingService;
    this.timeout = $timeout;
    this.selectedArtist = this.artistsManager.selectedArtist;
    this.usersManager = usersManager;

    $scope.$on(MessagingService.urlChanged, (event) => {
      this.selectTab();
      this.timeout(() =>{
        //TODO need to wait the new tab is selected
        this.messagingService.broadcast(MessagingService.tabSelected);//TODO use RxJs
      }, 100);
    })
    this.selectTab();
  }

  selectTab(){
    switch (this.urlStatusManager.status.tab) {
      case "artistTracks":
        this.selectedIndex = 0;
        break;
      case "artistAlbums":
        this.selectedIndex = 1;
        break;
      case "artistInfo":
        this.selectedIndex = 2;
        break;
      case "artistPlaylists":
        this.selectedIndex = 3;
    }
  }

  onTabSelected(tabName){
    if(tabName != "artistInfo") {
      this.urlStatusManager.status.tab = tabName;
      this.urlStatusManager.updateUrl("/artist-context");//TODO make this call automatic in USM when the status is update
    }
  }

  onReturnToFullCatalogClick(){
    this.urlStatusManager.status.tab = "tracks";
    this.urlStatusManager.status.filters.match.resource_rollup_id = undefined;
    this.urlStatusManager.status.filters.match.canopus_id = undefined;
    this.urlStatusManager.status.filters.query = "";
    this.urlStatusManager.status.selectedTrack = undefined;
    this.urlStatusManager.updateUrl("/tracks-filters");//TODO make this call automatic in USM when the status is update
  }

  $onInit(){
    this.isEmployee = (this.usersManager.userType === UsersManager.employee);
  }

}

let ArtistContextComponent = {

    bindings : {},
    controller : 'ArtistContextCtrl',
    controllerAs : 'ctrl',
    //todo check why templeUrl not working after grunt build
    template : `
                <div id="artist_context" style="overflow-x: hidden;position:relative;left: 25px;top:-76px">
                  <div id="context_wrapper"><img ng-src="{{ctrl.artistsManager.selectedArtist.imageUrl}}" id="context_image">
                    <h2 class="win-scroll">{{ctrl.artistsManager.selectedArtist.default_name}}</h2>
                    <p class="standard_text">Years Active: {{ctrl.artistsManager.selectedArtist.begin_year}} - {{ctrl.artistsManager.selectedArtist.end_year > 0 ? ctrl.artistsManager.selectedArtist.end_year : ''}}
                      <md-menu id="context_menu">
                        <md-button id="context_menu_button" ng-click="$mdMenu.open($event)" class="md-icon-button">
                            <i class="material-icons">more_vert</i>
                        </md-button>
                        <md-menu-content>
                            <md-menu-item>
                                <md-button ng-disabled="true">Instant Export</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-disabled="true">Show Filtered Tracks</md-button>
                            </md-menu-item>
                            <md-menu-item>
                                <md-button ng-click="ctrl.onReturnToFullCatalogClick()">Return to Full Catalogue</md-button>
                            </md-menu-item>
                        </md-menu-content>
                      </md-menu>
                    </p>
                  </div>
                  <md-content style="background-color: white;">
                    <md-tabs md-selected="ctrl.selectedIndex" md-dynamic-height="" md-no-pagination="true" md-enable-disconnect="true">
                      <md-tab ng-click='ctrl.onTabSelected("artistTracks")'>
                        <md-tab-label>
                          Tracks by {{ctrl.artistsManager.selectedArtist.default_name}}
                        </md-tab-label>
                        <md-tab-body>
                          <artist-tracks></artist-tracks>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-click='ctrl.onTabSelected("artistAlbums")'>
                        <md-tab-label>
                          Albums
                        </md-tab-label>
                        <md-tab-body>
                          <fix-album-table tab-id="'artistAlbums'"></fix-album-table>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-click='ctrl.onTabSelected("artistInfo")'>
                        <md-tab-label>
                          About
                        </md-tab-label>
                        <md-tab-body>
                          <artist-info></artist-info>
                        </md-tab-body>
                      </md-tab>
                      <md-tab ng-if="ctrl.isEmployee" ng-click='ctrl.onTabSelected("artistPlaylists")'>
                        <md-tab-label>
                          Featured in Playlists
                        </md-tab-label>
                        <md-tab-body>
                          <fix-playlist-table tab-id="'artistPlaylists'"></fix-playlist-table>
                        </md-tab-body>
                      </md-tab>
                    </md-tabs>
                  </md-content>
                </div>
              `
}

angular.module('auditionApp').component('artistContext', ArtistContextComponent);
angular.module('auditionApp').controller('ArtistContextCtrl', ArtistContextCtrl);

