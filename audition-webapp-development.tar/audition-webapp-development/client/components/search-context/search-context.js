
'use strict';
/**
 * This file contains view and controller of the FixPlaylistTable directive.
 * This directive creates a html paginated table containing the playlists found in
 * this.tracksManager.currentTracks.
 *
 * */

class SearchContextCtrl {
  constructor($scope, $rootScope, $stateParams, $timeout, messagingService, urlStatusManager, usersManager){
    this.rootScope = $rootScope;
    this.urlStatusManager = urlStatusManager;
    this.timeout = $timeout;
    this.usersManager = usersManager;
    this.messagingService = messagingService;
    if($stateParams.query) {
      urlStatusManager.updateStatusFromUrl(decodeURI($stateParams.query));
    }
    $scope.$on(MessagingService.urlChanged, (event) => {
      this.selectTab();
      this.timeout(() =>{
        //TODO need to wait the new tab is selected
        this.messagingService.broadcast(MessagingService.tabSelected);//TODO use RxJs
      }, 100);
    })
    this.selectTab();
  }

  $onInit(){
    this.isEmployee = (this.usersManager.userType === UsersManager.employee);
  }

  selectTab() {
    this.selectedIndex = 0;
    switch (this.urlStatusManager.status.tab) {
      case "playlists":
        this.selectedIndex = 1;
        break;
      case "artists":
        this.selectedIndex = 2;
    }
  }

  onTabSelected(tabName){
    this.urlStatusManager.status.tab = tabName;
    this.urlStatusManager.updateUrl("/tracks-filters");//TODO make this call automatic in USM when the status is update
  }

}

let SearchContextComponent = {

    binding : {},
    controller : 'SearchContextCtrl',
    controllerAs : 'ctrl',
    //todo check why templeUrl not working after grunt build
    template : `
  <div id="track-results" style="overflow-x: hidden;position:relative;left: 25px;top:-75px">
    <md-content style="background-color: white;">
      <md-tabs md-selected="ctrl.selectedIndex" md-dynamic-height="" md-no-pagination="true" md-enable-disconnect="true">
        <md-tab ng-click='ctrl.onTabSelected("tracks")'>
          <md-tab-label>
            Track Result
          </md-tab-label>
          <md-tab-body>
            <fix-track-table tab-id="'tracks'"></fix-track-table>
          </md-tab-body>
        </md-tab>
        <md-tab ng-if="ctrl.isEmployee" ng-click='ctrl.onTabSelected("playlists")'>
          <md-tab-label>
            Playlist Result
          </md-tab-label>
          <md-tab-body>
            <fix-playlist-table tab-id="'playlists'"></fix-playlist-table>
          </md-tab-body>
        </md-tab>
      </md-tabs>
    </md-content>
  </div>
`
}

angular.module('auditionApp').component('searchContext', SearchContextComponent);
angular.module('auditionApp').controller('SearchContextCtrl', SearchContextCtrl);

