'use strict';


class RecordingRightIconsCtrl{

  constructor($rootScope, $scope) {
    if ($scope.item._source.lost_rights){
      this.syncColor = "#DF6C64";
      this.streamingColor = "#DF6C64";
      this.downloadColor = "#DF6C64";
    }else{
      this.syncColor =  $scope.item._source.sync ? '#363F45' : 'lightgrey';
      this.streamingColor =  $scope.item._source.stream_restrict ? 'lightgrey' : '#363F45';
      this.downloadColor =  $scope.item._source.download_restrict ? 'lightgrey' : '#363F45';

    }
  }
}

class RecordingRightIconsComponent {

  constructor() {
    this.scope = {
      item: "=track"
    };
    this.replace = true;
    this.controller = 'RecordingRightIconsCtrl';
    this.controllerAs = 'ctrl';
    //TODO check why templateUrl not working after grunt build
    this.template = `
        <div>
          <span uib-tooltip="Download right"
                tooltip-placement="top"
                tooltip-trigger="mouseenter"
                tooltip-popup-delay='1000'
                ng-show="item._source.download_restrict!=null"
                ng-style="{ color: ctrl.downloadColor }"
                ng-class="{'fa fa-download icon-info-red':item._source.lost_rights,
                          'fa fa-download icon-info-default':!item._source.lost_rights}"></span>
          <span uib-tooltip="Streaming right"
                tooltip-placement="top"
                tooltip-trigger="mouseenter"
                tooltip-popup-delay='1000'
                ng-show="item._source.stream_restrict!=null"
                ng-style="{ color: ctrl.streamingColor }"
                ng-class="{'fa fa-youtube-play icon-info-red':item._source.lost_rights,
                'fa fa-youtube-play icon-info-default':!item._source.lost_rights}"></span>
          <span uib-tooltip="Synch right"
                tooltip-placement="top"
                tooltip-trigger="mouseenter"
                tooltip-popup-delay='1000'
                ng-show="item._source.sync!=null"
                ng-style="{ color: ctrl.syncColor }"
                ng-class="{'glyphicon glyphicon-transfer icon-info-red':item._source.lost_rights,
                'glyphicon glyphicon-transfer icon-info-default':!item._source.lost_rights}"></span>
        </div>`;
  }
}

register('auditionApp').directive('rightIcons', RecordingRightIconsComponent);
register('auditionApp').controller('RecordingRightIconsCtrl', RecordingRightIconsCtrl);

